/*
kotlinc KotlinOperatorOverloading.kt -include-runtime -d operatoroverloading.jar
java -jar operatoroverloading.jar
*/

package learnKotlin

import java.math.BigDecimal

// _____________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Point(var x: Int, var y: Int) {
	operator fun plus(other: Point ) : Point {
		// Adding X Cooridnates Values
		val xx = x + other.x
		// Adding Y Cooridnates Values
		val yy = y + other.y

		return Point(xx, yy)
	}

	operator fun minus(other: Point ) : Point {
		// Subtracting X Cooridnates Values
		val xx = x - other.x
		// Subtracting Y Cooridnates Values		
		val yy = y - other.y

		return Point(xx, yy)
	}
}


fun playWithPointAdditionAndSubstraction() {
	val point1 = Point(10, 20)
	println(point1)

	val point2 = Point(100, 200)
	println(point2)

	// val xx = point1.x + point2.x
	// val yy = point1.y + point2.y

	// val point3 = Point( xx, yy)
	// println(point3)

	val point33 = point1 + point2 // Will Get Converted To point1.plus( point2 )
	println(point33)

	val point44 = point1 - point2 // Will Get Converted To point1.minus( point2 )
	println(point44)
}

// _____________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Implementing times Extention Function On Point Class
operator fun Point.times(scale: Double) : Point {
	val xx = (x * scale).toInt()
	val yy = (y * scale).toInt()

	// Creating and Returning New Point with Calculated X and Y Coordinates Values
	return Point( xx, yy )
}

operator fun Char.times(count: Int) : String {
	return toString().repeat(count)
}

fun playWithTimesOperator() {
	val point1 = Point(10, 20)
	val point2 = Point(30, 40)

	var point4 = point2 * 4.0 	// Compiler Will Convert It To point2.times( 4.0 )
	var point5 = point1 * 2.0  	// Compiler Will Convert It To point1.times( 2.0 )
	var point6 = point4 * 3.0 	// Compiler Will Convert It To point4.times( 3.0 )

	println( point4 )
	println( point5 )
	println( point6 )	

	var character = 'A'
	var result = character * 10
	println(result)

	result = character * 20
	println(result)

	character = '_'
	result = character * 80
	println(result)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

operator fun Point.unaryMinus() : Point {
	return Point(-x, -y)
}

fun playWithUniaryMinusOperator() {
	val point1 = Point(10, 20)
	val point2 = Point(30, 40)

	var point4 = - point2 // Compiler Will Convert It To point2.unaryMinus()
	var point5 = - point1 // Compiler Will Convert It To point1.unaryMinus()

	println( point4 )
	println( point5 )
}

// import java.math.BigDecimal

operator fun BigDecimal.inc() = this + BigDecimal.ONE

fun playWithBigDecimalIncrementOperator() {
	var bigNumber = BigDecimal.ZERO

	println(bigNumber)
	bigNumber++			// Compiler Will Convert It To bigNumber.inc()
	println(bigNumber)
	bigNumber++			// Compiler Will Convert It To bigNumber.inc()
	println(bigNumber)
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


class Person(val firstName: String, val lastName: String, val age: Int): Comparable<Person> {
	override fun compareTo(other: Person) : Int {
		return compareValuesBy(this, other, Person::firstName, Person::lastName)
	}
}

fun playWithPersonComparison() {
	val person1 = Person("Alice", "Carols", 20)
	val person2 = Person("Alice", "Carolina", 29)
	var person3 = Person("Ramesh", "Kumar", 30)

	println( person1 < person2 ) // person1.compareTo(person2)
	println( person2 > person3 ) // person2.compareTo(person3)
	println( person1 < person3 ) // person1.compareTo(person3)
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// data class Point(var x: Int, var y: Int)
operator fun Point.get(index: Int) : Int {
	return when(index) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Invalid Index : $index")
	}
}

operator fun Point.set(index: Int, value: Int) {
	return when(index) {
		0 -> x = value
		1 -> y = value
		else -> throw IndexOutOfBoundsException("Invalid Index : $index")
	}
}

fun playWithIndexingOperator() {
	val point = Point(10, 20)
	// [] is Indexing Operator Used To Get Value At Index
	var xCoordinateValue = point[0] // Compiler Will Convert point[0] To point.get(0)
	println(xCoordinateValue)
	// [] is Indexing Operator Used To Get Value At Index
	var yCoordinateValue = point[1] // Compiler Will Convert point[1] To point.get(1)
	println(yCoordinateValue)
	// [] is Indexing Operator Used To Set Value At Index
	point[0] = 100 // Compiler Will Convert point[0] = 100 To point.set(0, 100)
	point[1] = 200 // Compiler Will Convert It To point.set(1, 200)
	println(point) 

	val point1 = Point(88, 99)
	// [] is Indexing Operator Used To Get Value At Index
	xCoordinateValue = point1[0] 	// Compiler Will Convert It To point1.get(0)
	println(xCoordinateValue)
	// [] is Indexing Operator Used To Get Value At Index
	yCoordinateValue = point1[1]
	println(yCoordinateValue) 		// Compiler Will Convert It To point1.get(1)
	// [] is Indexing Operator Used To Set Value At Index
	point1[0] = 888 // Compiler Will Convert It To point1.set(0, 888)
	point1[1] = 999 // Compiler Will Convert It To point1.set(0, 999)
	println(point1) 
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// data class Point(var x: Int, var y: Int)

data class Rectangle(val upperLeft: Point, val lowerRight: Point )

operator fun Rectangle.contains(point: Point) : Boolean {
	val xCoordinateInsideRectanleXs = point.x in upperLeft.x until lowerRight.x
	val yCoordinateInsideRectanleYs = point.y in upperLeft.y until lowerRight.y
	
	return  xCoordinateInsideRectanleXs && yCoordinateInsideRectanleYs	   
}


fun playWithInOperator() {
	val rectangle = Rectangle( Point(10, 20), Point(50, 80))
	
	var point = Point(40, 40)
	// Checking Point Is Inside A Rectangle or Not?
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(100, 100)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(30, 40)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(0, 0)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)
}

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {
	println("\nFunction : playWithPointAddition")
	playWithPointAddition()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
