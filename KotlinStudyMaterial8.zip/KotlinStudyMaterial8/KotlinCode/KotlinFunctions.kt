
package learnKotlin


// Function
// 		Doesn't take any argument
//		and Returns Unit Value of Unit Type
//		By Default Return Type Is Unit
fun helloWorld()  {
	println("Hello World!!!")
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Function
// 		Takes Two Int Type Arguments
//		and Returns Int Type Value

fun max( a: Int, b: Int ) : Int {
	return if (a > b) a else b
}

// Expression Can Be Assigned As Function Body
fun maximum(a: Int, b: Int ) = if (a > b) a else b

fun playWithMaximum() {
	var result: Int
	result = max(100, 200)
	println("Max Result : $result")

	result = max( -900, 300 )
	println("Max Result : $result")

	result = maximum(100, 200)
	println("Maximum Result : $result")

	result = maximum( -900, 300 )
	println("Maximum Result : $result")
}



// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Function Taking 1 Argument And Returning Unit
fun printMultipleOfFive(value: Int) {
	val fiveMultiple = value * 5
	println(" $value * 5 = $fiveMultiple" )
}

// Function Taking 2 Argument And Returning Unit
fun printMultipleOf(value: Int, multiplier: Int) {
	val result = value * multiplier

	println(" $value * $multiplier = $result ")
}

// Function Taking 2 Argument And Returning Unit
// 		and 2nd Argument multiplier Have Default Value
fun printMultipleOfDefaultValue( value: Int, multiplier: Int = 1 ) {
	val result = value * multiplier

	println(" $value * $multiplier = $result ")
}

fun playWithFunctionArguments() {
	printMultipleOfFive(10)

	printMultipleOf(value = 10, multiplier = 8)

	printMultipleOfDefaultValue(value = 10, multiplier = 8)
	printMultipleOfDefaultValue(value = 10)
}

// Function : playWithFunctionArguments
//  10 * 5 = 50
//  10 * 8 = 80 
//  10 * 8 = 80 
//  10 * 1 = 10 


// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Following Functions multiply and multiplyInferred are same
fun multiply(number: Int, multiplier: Int): Int {
    return number * multiplier
}

// Return Type of Following Function Is Inferred From RHS Expression Type
// number and mutliplier is Int Type and product will also be of Int Type
// Hence return type of function will be Int
fun multiplyInferred0(number: Int, multiplier: Int) = number * multiplier

// Explicitly Specified Return Type Int
fun multiplyInferred1(number: Int, multiplier: Int): Int = number * multiplier

fun multiplyAndDivide(number: Int, factor: Int) : Pair<Int, Int> {
    return Pair(number * factor, number / factor)
}

fun playWithFunctionReturnValues() {
	var result: Int

	result = multiply(4, 2)
	println(result)

	result = multiplyInferred0(4, 2)
	println(result)
	result = multiplyInferred1(4, 2)
	println(result)

	val resultAgain = multiplyAndDivide(9, 2)
	println("Result : $resultAgain")

	val (product, quotient) = multiplyAndDivide(14, 3)
	println("Product : $product, Quotient: $quotient")
}


// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// By Default Function Arguments Are val i.e. Immutable 
fun incrementValue(value: Int) : Int {
	//value = value + 1 // error: val cannot be reassigned
	
	val newValue = value + 1
	return newValue
}

fun playWithIncrementValueFunction() {
	var value = 80
	
	println(value)
	value = incrementValue( value )
	println(value)
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// FUNCTION OVERLOADING
//		Functions With Same Name
//		Having Different Arguments Type and/or Different Numbers Of Arguments

// Overloaded Based On Type Of Arguments
fun getValue(value: Int) : Int {
	return value + 1
}

fun getValue(value: String) : String {
	return "You Said " + value
}

fun playWithOverloadedGetValueFunctions() {
	val valueInt : Int 		 = getValue(900)
	val valueString : String = getValue("Good Morning!")

	println(valueInt)
	println(valueString)
}

// Overloaded Based On Number Of Arguments
fun add(a: Int, b: Int) : Int {
	return a + b
}

fun add(a: Int, b: Int, c: Int) : Int {
	return a + b + c
}

fun playWithOverloadedSumFunctions() {
	var result : Int

	result = add(100, 200)
	println("Sum : $result")

	result = add(100, 200, 400)
	println("Sum : $result")
}


// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

fun addFunction(a: Int, b: Int) : Int {
	return a + b
}

fun subFunction(a: Int, b: Int) : Int {
	return a - b
}

fun playWithFunctionReferences() {
	val xx: Int = 100
	val yy: Int = 200

	var result: Int

	result = addFunction(xx, yy)
	println("Result : $result")

	result = subFunction(xx, yy)
	println("Result : $result")

	// :: Used For Getting Function Reference/Address
	// ::addFunction Is Reference/Address Of addFunction
	var operation = ::addFunction 
	result = operation(xx, yy)
	println("Result : $result")

	// ::subFunction Is Reference/Address Of subFunction
	operation = ::subFunction
	result = operation(xx, yy)
	println("Result : $result")
}

// Function : playWithFunctionReferences
// Result : 300
// Result : -100
// Result : 300
// Result : -100

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function Type : (Int, Int) -> Int
fun addition(a: Int, b: Int) : Int { return a + b }

// Function Type : (Int, Int, Int) -> Int
fun addition3(a: Int, b: Int, c: Int) : Int { return a + b + c }

// Function Type : (Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int { return a - b }

// Function Type : (Int, Int) -> Int
fun multiplication(a: Int, b: Int) : Int { return a * b }

// calculator Takes Three Arguments
//		First Two Arguments Are Of Int Type
//		Last Argument Is Of Function Type 
//			Which Takes Two Int Arguments And Return Int
fun calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithCalculator() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	// Passing Function To  Function
	// Passing addition Function To calculator Function
	result = calculator(xx, yy, ::addition)
	println("Result : $result")

	// Passing substraction Function To calculator Function
	result = calculator(xx, yy, ::substraction)
	println("Result : $result")

	// Passing multiplication Function To calculator Function
	result = calculator(xx, yy, ::multiplication)
	println("Result : $result")

	//error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> 
	// but (Int, Int) -> Int was expected
	// result = calculator(xx, yy, ::addition3)
	// println("Result : $result")	
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()
	
	println("\nFunction : playWithMaximum")
	playWithMaximum()

	println("\nFunction : playWithFunctionArguments")
	playWithFunctionArguments()

	println("\nFunction : playWithIncrementValueFunction")
	playWithIncrementValueFunction()

	println("\nFunction : playWithOverloadedGetValueFunctions")
	playWithOverloadedGetValueFunctions()

	println("\nFunction : playWithOverloadedSumFunctions")
	playWithOverloadedSumFunctions()

	println("\nFunction : playWithFunctionReferences")
	playWithFunctionReferences()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

