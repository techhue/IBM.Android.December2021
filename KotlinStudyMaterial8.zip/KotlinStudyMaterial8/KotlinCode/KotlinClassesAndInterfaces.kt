/*
kotlinc KotlinClassesAndInterfaces.kt -include-runtime -d interfaces.jar
java -jar interfaces.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Interface Members Are By Default Open
interface Clickable {
	fun click() // click() Function Declaration 
}

// Button Class Implements Clickable Interface
//		Must Provide Implemnation In Class Of Methods Declared In Interface
class Button : Clickable {
	override fun click() { // click() Function Definition
		println("I Am Clicked!!!")
	}
}

fun playWithInterface() {
	val button = Button()
	button.click()
}


// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

interface Clickable1 {
	fun click()

	fun showOff() { // Defintion 1 Of showOff() Method
		println("Clickable1 : I Am showOff!...")		
	}
}

// In Interfaces You Can Also Create Functions With Definition
interface Focusable1 {
	fun setFocus() {  // Function With Definition
		println("Focusable1 : I Am On Focus!...")
	}

	fun showOff() { // Defintion 2 Of showOff() Method
		println("Focusable1 : I Am showOff!...")		
	}
}

class Button1 : Clickable1, Focusable1 { // Implemnting Multiple Interfaces
	override fun click() { // click() Function Definition
		println("Button1 : I Am Clicked!!!")
	}
	
	// Must Override When More Than One Definitions Exists For Same Function
	override fun showOff() { 
		println("Button1 : I Am showOff!!!")
		super<Clickable1>.showOff() // Called Based On Need Or Your Logic
		super<Focusable1>.showOff() // Called Based On Need Or Your Logic
	}
}

fun playWithInterfaceClickableAndFocusable() {
	val button = Button1()
	button.setFocus()
	button.click()
	button.showOff()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// In Kotlin By Default Classes And Member Functions Are Final
// 		i.e. You CANN'T Override Them In Child Class
//		To Override Functions in Child Class You Should Explciitly Make It Open

// In Java By Default Classes And Member Functions Are Open
// 		i.e. You CAN Override Them In Child Class
//		To NOT TO Override Functions in Child Class You Should Explciitly Make It Final

open class View2 {	// Parent Class
	open fun click() {  println("View2 Got Clicked!") }
	open fun descibeMe() { println("View2 Description...") }
}
// Inheritance : Button2 Inheriting From View2
//		View2 Is Parent Class
//		Button2 Is Child Class
open class Button2 : View2() { // Creating Child Class Button2
	override fun click() { println("Button2 Got Clicked!")	}

	open fun magic() { println("Button2 Doing Magic...") }

	fun disable() = println("Disabling Button2")
}

class RichButton2 : Button2() {
	override fun descibeMe() = println("Very Rich Button... Become Rich!!!")
	override fun magic() 	= println("RichButton1 Doing Magic...")
}

fun playWithInheritance() {
	val view = View2()
	view.click() 
	view.descibeMe()

	val button = Button2()
	button.click()
	button.descibeMe()
	button.magic()
	button.disable()

	val richButton = RichButton2()
	richButton.click()
	richButton.descibeMe()
	richButton.magic()
	richButton.disable()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

open class View3 { 			// Parent Class
	open fun click() { println("View3 Got Clicked!...") }
}

// Button3 Inheriting From View3 Class
class Button3 : View3() { 	// Child Class
	override fun click() { println("Button3 Got Clicked!...") } 
}

// Extension Method On View3 Type
fun View3.doMagic() = println("View3 doMagic Called!...")

// Extension Method On Button3 Type
fun Button3.doMagic() = println("Button3 doMagic Called!...")


// Extenstion Functions Doesn't Participante In Inheritance
//		i.e. Child Class Cann't Override Extension Functions
fun playWithInheritanceAndExtensionFunctions() {
	val view = View3()
	view.click()
	view.doMagic()

	val button = Button3()
	button.click()
	button.doMagic()

	val viewTypeReference: View3 = Button3()

	// Will Invoke Button3 click Method
	viewTypeReference.click()

	// Will Invoke View3 doMagic Method
	viewTypeReference.doMagic()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

interface Expression

class Num(val value: Int) : Expression
class Sum(val left:  Expression, val right: Expression) : Expression

fun eval(expression : Expression) : Int {
	// Smart Type Check
	// First Type Check Happens, If Successful Then Type Conversion
	// Here Type of expression is Expression
	//		Then Type Check With (expression is Num)
	//		expression is Num == true Than It Will Type Cast expression To Num Type 
	if ( expression is Num ) { 
		// Now Here Type of Expression is Num
		return expression.value 
	}

	// Here Type of expression is Expression
	//		Then Type Check With (expression is Sum)
	//		expression is Sum == true Than It Will Type Cast expression To Sum Type 
	if (expression is Sum) { // Type Check
		// Now Here Type of Expression is Sum
		return eval(expression.right) + eval(expression.left)
	}

	throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvalFunction() {
	var result : Int 

	// 100 + 200
	result = eval( Sum( Num(100), Num(200) ))
	println("Result : $result")
	
	// ( 100 + 200 ) + 500
	result = eval( Sum( Sum( Num(100), Num(200) ), Num(500)) ) 
	println("Result : $result")
}


// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {
	println("\nFunction : playWithInterface")
	playWithInterface()

	println("\nFunction : playWithInterfaceClickableAndFocusable")
	playWithInterfaceClickableAndFocusable()

	println("\nFunction : playWithInheritanceAndExtensionFunctions")
	playWithInheritanceAndExtensionFunctions()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
