/*
kotlinc 04KotlinMoreClassesAndInterfaces.kt -include-runtime -d interfaces.jar
java -jar interfaces.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________


fun main() {
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
