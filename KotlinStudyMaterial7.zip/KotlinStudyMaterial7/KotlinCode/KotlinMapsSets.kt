/*
kotlinc KotlinMapsSets.kt -include-runtime -d mapset.jar
java -jar mapset.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithMaps() {

    // Creating Map Having 4 Elements
    //      Collection Of (Key, Value) Pairs And
    //      Having Key Type String and Value Type Int
    //      e.g. ("Anna", 1990), ("Brian, 1991") 
    //      Here "Anna" is Key Having Value 1990 
    var yearOfBirth = mapOf("Anna" to 1990, "Brian" to 1991, "Craig" to 1992, "Donna" to 1993)
    println( yearOfBirth ) // {Anna=1990, Brian=1991, Craig=1992, Donna=1993}


    var namesAndScores = mutableMapOf("Anna" to 2, "Brian" to 2, "Craig" to 8, "Donna" to 6)
    println(namesAndScores) // {Anna=2, Brian=2, Craig=8, Donna=6}

    // Creating Empty Mutable Map Having 0 Elements
    namesAndScores = mutableMapOf()
    println( namesAndScores )

    // Creating Empty HashMap Having 0 Elements And
    //     Key Type Is String and Value Type Is Int
    var pairs = HashMap<String, Int>()
    println( pairs )
    println( pairs.isEmpty() )

    // Creating Empty HashMap Having 0 Elements And Initial Capacity 20 Elements
    //     Key Type Is String and Value Type Is Int
    pairs = HashMap<String, Int>(20)
    println( pairs )
    println( pairs.size )
    println( pairs.isEmpty() )

    // Creating Map Having 4 Elements
    namesAndScores = mutableMapOf("Anna" to 2, "Brian" to 2, "Craig" to 8, "Donna" to 6)

    // Accessing Values Using Index Operator
    println(namesAndScores["Anna"])     // 2
    println(namesAndScores["Donna"])    // 6

    val gregValue = namesAndScores["Greg"]
    println( gregValue ) // null

    // Using Member Properties and Methods HashMap

    println( namesAndScores.get("Anna") )     // 2
    println( namesAndScores.get("Donna") )    // 6
    println( namesAndScores.get("Craig") )    // 8

    val gregValue1 = namesAndScores.get("Greg") 
    println( gregValue1 ) // null

    println( namesAndScores.isEmpty() )// false
    println( namesAndScores.size ) // 4

    // Modifying Mutable Maps

    // Adding Pairs

    // Creating Map Having 3 Elements With Key Of Type String and Value Of Type String
    val bobData = mutableMapOf("name" to "Bob", "profession" to "CardPlayer", "country" to "USA")
    
    println( bobData )

    // Adding Element Using put() Function Having Key "state" and Value "CA"
    bobData.put("state", "CA")
    println( bobData )

    // Adding Element Using Indexing [] Operator Having Key "state" and Value "CA"    
    bobData["city"] = "San Francisco"
    println( bobData )
    // // // Updating values

    // Updating Exiting Element Using put() Function
    bobData.put("name", "Bobby") // Bob
    println( bobData )

    // Updating Exiting Element Using Indexing [] Operator
    bobData["profession"] = "Mailman"
    println( bobData )

    val pair = "nickname" to "Bobby D"

    // Concatenating New (Key, Value) Pair To Map
    bobData += pair
    println( bobData )
    // {name=Bobby, profession=Mailman, country=USA, state=CA, city=San Francisco, nickname=Bobby D}

    // Removing Pairs
    bobData.remove("city")
    bobData.remove("state", "CA")
    println( bobData ) // {name=Bobby, profession=Mailman, country=USA, nickname=Bobby D}
}


// _____________________________________________________
// _____________________________________________________


fun playWithIteratingOverMaps() {
    // Iterating Through Maps

    var namesAndScores = mutableMapOf("Anna" to 2, "Brian" to 2, "Craig" to 8, "Donna" to 6)
    println(namesAndScores) // {Anna=2, Brian=2, Craig=8, Donna=6}

    for ( (player, score) in namesAndScores ) {
        println("$player - $score")
    }
    // Output Will Be
    // Anna - 2
    // Brian - 2
    // Craig - 8
    // Donna - 6

    for (player in namesAndScores.keys) {
        print("$player, ") // no newline
    }
    println() // print a newline
    // Output Will Be
    // Anna, Brian, Craig, Donna,
}

fun playWithSets() {
    // Mathematically Set Is Collection Of Unique Objects
    //      Order Of Object Doesn't Matter And Cann't Store Duplicates

    // Creating Set Of 5 Unique Elements Of Type Strings
    val names = setOf("Anna", "Brian", "Craig", "Anna", "Ramya", "Alice")
    println(names) // [Anna, Brian, Craig, Ramya, Alice]

    // Creating HasSet Of 0 Elements Of Type Int
    val hashSet = HashSet<Int>()
    println( hashSet )
    println( hashSet.isEmpty() )

    val someArray = arrayOf(1, 2, 3, 1)

    // Creating Mutable Set From The Elements Of someArray
    // * Used To Unpack/Declutter Array Elements To Arguments List of mutableSetOf
    var someSet = mutableSetOf( *someArray )
    println(someSet) //  [1, 2, 3]

    // Accessing Elements
    println(someSet.contains(1)) // true
    println( 1 in someSet )  // true
    println( 20 in someSet ) // false
    println(4 in someSet)    // false

    println(someSet.first())
    println(someSet.last())

    // Adding and Removing Elements

    someSet.add(5)
    println(someSet)  // [1, 2, 3, 5]

    val removedOne = someSet.remove(1)
    println( removedOne ) // true
    println(someSet)  // [2, 3, 5]
}


// _____________________________________________________
// _____________________________________________________
// _____________________________________________________


fun main( ) {
    println("\nFunction : playWithMaps")
    playWithMaps()

    println("\nFunction : playWithIteratingOverMaps")
    playWithIteratingOverMaps()

    println("\nFunction : playWithSets")
    playWithSets()

    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
}

