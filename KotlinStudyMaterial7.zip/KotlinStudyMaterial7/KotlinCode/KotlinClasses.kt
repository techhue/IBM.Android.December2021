
/*
kotlinc 07KotlinStartClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

import java.util.Comparator
import java.io.File

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Definining Person Class/Type
//	Compiler Will Generate Following Things
//		1. Constructor Which Takes Two Arguments 
//				viz. firstName And lastName
//		2. Getters and Setters For 2 Properties
//				viz. firstName And lastName
//		3. Will Generate 3 Backing Field/Member Variables For All Three Properties
//				To Store The Data

class Person(var firstName: String, var lastName: String) {
	var fullName: String = "" // Assigning Default Value
		get() { // Definining Getter Function For fullName Property
			println("fullName Getter Called...")
			return "$firstName $lastName"
		}

		set(value) { // Definining Setter Function For fullName Property
			println("fullName Setter Called...")
			// field Is Called Backing Field or Member Variable Where Data Is Stored
			field = value 
		}
}

fun playWithPerson() {
	// Calling Person Class Constructor
	// Creating person Object/Instance
	val person = Person(firstName = "Alice", lastName = "Carols")
	
	// Accessing Instance Members
	println( person.firstName )  // It Will Call alice.getFirstName() Getter Function
	println( person.lastName )   // It Will Call alice.getLastName() Getter Function	

	person.firstName = "Alina"   // It Will Call alice.setFirstName("Alina") Setter Function
	person.lastName = "Fernades" // It Will Call alice.setLastName("Fernades") Setter Function
	
	println( person.firstName )  // It Will Call alice.getFirstName() Getter Function
	println( person.lastName )   // It Will Call alice.getLastName() Getter Function 

	println( person.fullName ) // It Will Call alice.getFullName() Getter Function
	person.fullName = "Alina Fernades" // It Will Call alice.setFullName() Setter Function
	println( person.fullName ) // It Will Call alice.getFullName() Getter Function
}

// _____________________________________________________

// PREDICT WHAT WILL BE OUTPUT OF FOLLOWING CODE???

class SimplePerson(var name: String) {
	// Implement equals Method To Compare Object Properties

	override fun equals(other: Any?) : Boolean {
		println("equals Method Called...")
		if (other == null || other !is SimplePerson) return false
		return name == other.name
	}

	override fun hashCode() : Int {
		var result: Int
		result = name.hashCode()
		return (result % 10000)
	}

	override fun toString() : String {
		return "SimplePerson(name = $name)"
	}

	fun copy( name : String = this.name ) : SimplePerson {
		return SimplePerson( name )
	}
}

fun playWithObjectReferences() {
	val simplePerson = SimplePerson(name = "John")
	println(simplePerson.name)

	// It's Shallow Copy
	//		It's Not Copy Of Full Object
	// By Default It's Reference/Address Assignment/Copy
	val simplePersonAgain = simplePerson

	simplePersonAgain.name = "John Mcmillan"

	println( simplePersonAgain.name ) 	
	println( simplePerson.name ) 		
}

// Expected Output
// Function : playWithObjectEquality
// John
// John Mcmillan
// John

// Actual Output
// Function : playWithObjectEquality
// John
// John Mcmillan
// John Mcmillan

//_________________________________

// PREDICT WHAT WILL BE OUTPUT OF FOLLOWING CODE???

fun playWithObjectEquality() {
	val simplePerson0 = SimplePerson(name = "John")
	println(simplePerson0.name)

	val simplePerson1 = SimplePerson(name = "John")
	println(simplePerson1.name)

	val simplePerson2 = SimplePerson(name = "Gabbar")
	println(simplePerson2.name)

	// By Default It's Comparing References/Addresses
	//		Not Actual Object Properties Comparison
	println( simplePerson0 == simplePerson1 ) // simplePerson0.equals( simplePerson1 )
	println( simplePerson0 == simplePerson2 ) // simplePerson0.equals( simplePerson2 )
	println( simplePerson1 == simplePerson2 ) // simplePerson1.equals( simplePerson2 )
}

// Expected Output
// Function : playWithObjectEquality
// true
// false
// false

// Actual Output Before Implementing equals Method
// Function : playWithObjectEquality
// false
// false
// false

// Actual Output After Implementing equals Method
// Function : playWithObjectEquality
// equals Method Called...
// true
// equals Method Called...
// false
// equals Method Called...
// false


// _____________________________________________________

fun playWithPrintingObject() {
	val simplePerson0 = SimplePerson(name = "John")
	// println Will Call toString Method If It Is Implemented
	println(simplePerson0)  // simplePerson0.toString()

	val simplePerson1 = SimplePerson(name = "John")
	println(simplePerson1) // simplePerson1.toString()

	val simplePerson2 = SimplePerson(name = "Gabbar")
	println(simplePerson2) // simplePerson2.toString()
}

// Actual Output Before Implementing toString Method
// Function : playWithPrintingObject
// learnKotlin.SimplePerson@28a418fc
// learnKotlin.SimplePerson@5305068a
// learnKotlin.SimplePerson@1f32e575

// Actual Output After Implementing toString Method
// Function : playWithPrintingObject
// SimplePerson(name = John)
// SimplePerson(name = John)
// SimplePerson(name = Gabbar)

// _____________________________________________________

fun playWithObjectCopy() {
	val simplePerson = SimplePerson(name = "John")
	println(simplePerson.name)

	// It's Deep Copy
	//		It's Copy Of Full Object In New Memory Location
	val simplePersonAgain = simplePerson.copy()

	simplePersonAgain.name = "John Mcmillan"

	println( simplePersonAgain.name ) 	
	println( simplePerson.name ) 		
}

// Actual Output Before Implementing copy Method
// Function : playWithObjectCopy
// John
// John Mcmillan
// John Mcmillan

// Actual Output After Implementing copy Method
// Function : playWithObjectCopy
// John
// John Mcmillan
// John

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Student1(var firstName: String, var lastName: String, var id: Int) {	
	// By Default equals compares Only References
	// Don't Want To Compare Object References
	// Want To Compare Objects With There Members
	//		Override equals Method and Write Your Equality Logic
	override fun equals(other: Any?): Boolean {
		println("Method Called... : equals")
		if (other == null || other !is Student1 ) return false
		// return (firstName == other.firstName && lastName == other.lastName)
		return (firstName == other.firstName && lastName == other.lastName && id == other.id)
	}

	// Override hashCode Function Also Along With equals Method
	// Another Simpler Implemenation of hashCode
	override fun hashCode() : Int {
		var result: Int

		result = firstName.hashCode()
		result = result + id
		result = result + lastName.hashCode()
		
		return (result % 10000)
	}

	override fun toString() : String {
		println("Student 1 Method Called... : toString")
		return "Student1(firstName=$firstName, lastName=$lastName, id=$id)"
	}

	// Member Of Student1 Class
	fun copy(firstName: String = this.firstName, 
		lastName: String = this.lastName, 
		id: Int = this.id) : Student1 {
		return Student1(firstName, lastName, id)
	}
}

fun playWithStudent1Copying() {
	val alice1 = Student1(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = alice1

	// Creates Deep Copy i.e. Creates Full Copy Of The Object
	val alice3 = alice1.copy()

	val someone = alice1.copy( lastName = "Someone", id = 200)
	val someoneElse = alice1.copy( lastName = "SomeoneElse", id = 300)
	val someoneElseAgain = alice1.copy( firstName = "Alisha", lastName = "SomeoneElseAgain", id = 400)

	alice2.firstName = "Alonza"
	
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(alice3) // Compiler Will Convert To println( alice3.toString() )

	println(someone)
	println(someoneElse)
	println(someoneElseAgain)

	// For Expression alice1 == alice2
	println( alice1 == alice2 ) // Compiler Will Geneate alice1.equals( alice2 )  
	println( alice1 === alice2 ) // Equality of References 
	
	println( alice1 == alice3 ) // Compiler Will Geneate alice1.equals( alice3 ) 
	println( alice1 === alice3 ) // Equality of References

	println( alice1 == someone ) // Compiler Will Geneate alice1.equals( someone ) 
	println( alice1 === someone ) // Equality of References
	
	println( alice1 == someoneElse ) // alice1.equals( someoneElse )
	println( alice1 === someoneElse ) // Equality of References
}

fun playWithStudent1Equality() {
	val alice1 = Student1(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = Student1(firstName = "Alice", lastName = "Carols", id = 100)

	val johnny = Student1(firstName = "Jonny", lastName = "Jaamil", id = 999)

	// println(alice1.firstName)
	// println(alice1.lastName)
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(johnny) // Compiler Will Convert To println( johnny.toString() )

	// Compiler Will Geneate alice1.equals( alice2 ) For Expression alice1 == alice2
	println( alice1 == alice2 ) 
	// Compiler Will Geneate alice1.equals( johnny ) For Expression alice1 == johnny
	println( alice1 == johnny )
	// Compiler Will Geneate alice2.equals( johnny ) For Expression alice2 == johnny
	println( alice2 == johnny )
}

// _____________________________________________________

// Data Classes
//	Compiler Will Generate Following Methods
//		1. Will Generate toString Method Code
//		2. Will Generate equals Method Code
//		3. Will Generate hashCode Method Code
//		4. Will Generate copy Method Code Also For Immutable Properties

data class SimplePersonAgain(var name: String)

fun playWithPrintingSimplePersonAgainObject() {
	val simplePerson0 = SimplePersonAgain(name = "John")
	// println Will Call toString Method If It Is Implemented
	println(simplePerson0)  // simplePerson0.toString()

	val simplePerson1 = SimplePersonAgain(name = "John")
	println(simplePerson1) // simplePerson1.toString()

	val simplePerson2 = SimplePersonAgain(name = "Gabbar")
	println(simplePerson2) // simplePerson2.toString()
}

// Actual Output Before Making Class As data Class
// Function : playWithPrintingSimplePersonAgainObject
// learnKotlin.SimplePersonAgain@5caf905d
// learnKotlin.SimplePersonAgain@27716f4
// learnKotlin.SimplePersonAgain@8efb846

// Actual Output After Making Class As data Class
// Function : playWithPrintingSimplePersonAgainObject
// SimplePersonAgain(name=John)
// SimplePersonAgain(name=John)
// SimplePersonAgain(name=Gabbar)

fun playWithSimplePersonAgainObjectEquality() {
	val simplePerson0 = SimplePersonAgain(name = "John")
	println(simplePerson0.name)

	val simplePerson1 = SimplePersonAgain(name = "John")
	println(simplePerson1.name)

	val simplePerson2 = SimplePersonAgain(name = "Gabbar")
	println(simplePerson2.name)

	// By Default It's Comparing References/Addresses
	//		Not Actual Object Properties Comparison
	println( simplePerson0 == simplePerson1 ) // simplePerson0.equals( simplePerson1 )
	println( simplePerson0 == simplePerson2 ) // simplePerson0.equals( simplePerson2 )
	println( simplePerson1 == simplePerson2 ) // simplePerson1.equals( simplePerson2 )
}

// Actual Output Before Making Class As data Class
// Function : playWithSimplePersonAgainObjectEquality
// false
// false
// false

// Actual Output After Making Class As data Class
// Function : playWithSimplePersonAgainObjectEquality
// true
// false
// false

// _____________________________________________________


// Data Classes
// Compiler Will Generate Following Methods
//		1. Will Generate toString Method With All The Properties In Contructor
//		2. Will Generate equals Method, Comparing All The Properties In Constructor
//		3. Will Generate hashCode Method Also
//		4. Will Generate copy Method To Coyy All The Properties In Constructor

data class Student2(var firstName: String, var lastName: String, var id: Int) {
	// var fullName: String
	// 		get() {
	// 			return "$lastName, $firstName"
	// 		}

	// Following Is Getter Body After Assignment Statement
	// And It's Equivalent To Above Code
	val fullName = "$lastName, $firstName"

	// Overriding toString Method, Hence will be Not Be Generated
	override fun toString() : String {
		println("Student 2 Method Called... : toString")
		return "Student1(firstName=$firstName, lastName=$lastName, id=$id)"
	}
}

fun playWithStudent2Equality() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = Student2(firstName = "Alice", lastName = "Carols", id = 100)

	val johnny = Student2(firstName = "Jonny", lastName = "Jaamil", id = 999)

	println(alice1.fullName)
	println(alice1.toString() ) 
	println(alice2.fullName)
	println(alice2.toString() ) 
	println(johnny.fullName)
	println(johnny.toString()) 

	println( alice1 === alice2 ) 
	println( alice1 == alice2 ) 
	println( alice1 == johnny )
	println( alice2 == johnny )	

}

fun playWithStudent2Copying() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = alice1

	val alice3 = alice1.copy()

	val someone = alice1.copy( lastName = "Someone", id = 200)
	val someoneElse = alice1.copy( lastName = "SomeoneElse", id = 300)
	val someoneElseAgain = alice1.copy( firstName = "Alisha", lastName = "SomeoneElseAgain", id = 400)

	alice2.firstName = "Alonza"
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(alice3)
	println(someone)
	println(someoneElse)
	println(someoneElseAgain)

	println( alice1 == alice2 )  
	println( alice1 === alice2 ) // Equality of References 
	println( alice1 == alice3 ) 
	println( alice1 === alice3 ) // Equality of References
	println( alice1 == someone )
	println( alice1 === someone ) // Equality of References
	println( alice1 == someoneElse ) // alice1.equals( someoneElse )
	println( alice1 === someoneElse ) // Equality of References
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Object Classes
// 		Singleton Classes
// 			Singleton Class Having Only One Instance
//		object Classes Are Singleton Classes In Kotlin
// 			Will Define Singleton Named Class
//			Create One Unique Instance of It.
//			You Can Access Unique Instance With Class Name.

object Singleton {
	var member: String = "Unknown Value"
}


object X {
	var x = 0
}


fun playWithObjectClasses() {
	var value: String = Singleton.member

	println("Value Stored In Singleton : $value")
	println( X.x )

	Singleton.member = "Kotlin Is Great Language!"
	X.x = 9000

	value = Singleton.member
	println("Value Stored In Singleton : $value")
	println( X.x )

}

// _____________________________________________________
// Implement India Singleton Class In Kotlin

// Singleton Class With Unique Object and Object Is Accessed Using Class Name

object India {
	var name : String = "India"

	fun getStates() : List<String> {
		return listOf("Karnatka", "Jammu & Kashmir", "Punjab", "Gujrat", "Tamilnadu",
			"Bihar", "Uttar Pradesh", "Maharastra", "Kerala")		
	}

	fun decoratedName() : String {
		return "Country Name : $name"
	}
}

fun playWithIndia() {
	println(India.name)
	
	India.name = "Bharat"
	println(India.name)

	India.name = "Hindustan!"
	println(India.name)

	println(India.getStates())
	println(India.decoratedName())	
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Student3(val id: Int, val firstName: String, val lastName: String) {
	val fullName = "$lastName, $firstName"
}

// Singleton Class
object StudentRegistry {
	val allStudents = mutableListOf<Student3>()

	fun addStudent(student: Student3) {
		allStudents.add(student)
	}

	fun removeStudent(student: Student3) {
		allStudents.remove(student)
	}

	fun listAllStudents() {
		allStudents.forEach( { println(it.fullName) } )
	}
}

fun playWithStudentRegistry() {
	val marie = Student3(100, "Marie", "Curie")
	val albert = Student3(101, "Albert", "Einsein")
	val alice = Student3(102, "Alice", "Carol")

	StudentRegistry.addStudent(marie)
	StudentRegistry.addStudent(albert)
	StudentRegistry.addStudent(alice)

	StudentRegistry.listAllStudents()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Creating Class/Type Members In Kotlin

// Companions Objects
//		Companions Objects Members Are Class Members
//			i.e. Can Be Accessed Using Enclosing Class/Type

class TypeMember1 {
	// Companion Object Class Name Optional
	//		Companion Will Be Default Class For Companion Object
	companion object {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

class TypeMember2 {
	// Companion Object Class Name Mentioned
	companion object Magician {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

fun playWithCompanionObjects() {

	// Following Two Lines Of Code Are Equivalent
	TypeMember1.doMagic()
	TypeMember1.Companion.doMagic()

	// Following Two Lines Of Code Are Equivalent
	TypeMember2.doMagic()
	// TypeMember2.Companion.doMagic()
	TypeMember2.Magician.doMagic()
}

	
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________


fun main( ) {	
	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithObjectReferences")
	playWithObjectReferences()

	println("\nFunction : playWithObjectEquality")
	playWithObjectEquality()

	println("\nFunction : playWithPrintingObject")
	playWithPrintingObject()

	println("\nFunction : playWithObjectCopy")
	playWithObjectCopy()

	println("\nFunction : playWithStudent1Copying")
	playWithStudent1Copying()

	println("\nFunction : playWithStudent1Equality")
	playWithStudent1Equality()

	println("\nFunction : playWithPrintingSimplePersonAgainObject")
	playWithPrintingSimplePersonAgainObject()

	println("\nFunction : playWithSimplePersonAgainObjectEquality")
	playWithSimplePersonAgainObjectEquality()

	println("\nFunction : playWithStudent2Equality")
	playWithStudent2Equality()

	println("\nFunction : playWithStudent2Copying")
	playWithStudent2Copying()

	println("\nFunction : playWithObjectClasses")
	playWithObjectClasses()

	println("\nFunction : playWithIndia")
	playWithIndia()

	println("\nFunction : playWithStudentRegistry")
	playWithStudentRegistry()

	println("\nFunction : playWithCompanionObjects")
	playWithCompanionObjects()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
