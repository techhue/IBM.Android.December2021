
/*
kotlinc 04KotlinMoreClassesAndInterfaces.kt -include-runtime -d interfaces.jar
java -jar interfaces.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// error: this type is final, so it cannot be inherited from
// In Kotlin Classes Are Final By Default
//      It Means You CANN"T Inherit From Them
//      Do You Want To Do Inheritance In Kotlin?
//          Than Make Class Open In Kotlin Using open Keyword
//          Use : To Inherit From Parent Class
// In Kotlin Members Are Also Final By Default
//      Explicitly Open Using open Keyword

// In Java Classes Are Open By Default
//      It Means You CAN Inherit From Java Classes
//          Use extend Keyword To Inherit From Parent Class
//      You DONOT Want To Do Inheritance In Java?
//          Than Make Class Final In Java Using java Keyword
// In Kotlin Members Are open By Default

// Definining Person Primary Constructor Taking 2 Arguments
//      Here constructor Keyword Is Optional
//          open class Person(var firstName: String, var lastName: String)

data class Subject(val name: String, val grade: Char, val points: Double, 
    val credits: Double)

data class Game(val name: String, val grade: Char, val points: Double)

                //  Primary Constructor
open class Person constructor(var firstName: String, var lastName: String) {
    fun fullName() : String { 
        return "$firstName $lastName"
    }
}

// Doing Inheritance
    // Parent Class Capabilities Will Comes To Child Class Also
    //      i.e. Members Of Parent Class Also Child Class Members
    //           Can Be Accessed In Child Class Objects
    // Person Class Will Be Parent Class Of Student Class
    // Student Class Will be Child Class Of Person Class

// Definining Student Primary Constructor Taking 2 Arguments
open class Student(firstName: String, lastName: String) : Person(firstName, lastName) {
    val passedSubjects: MutableList<Subject>   = mutableListOf<Subject>()
    val failedSubjects : MutableList<Subject>  = mutableListOf<Subject>()
    
    fun recordGrade( subject: Subject ) {
        if ( subject.grade == 'F') {
            failedSubjects.add( subject )
        } else {
            passedSubjects.add( subject )
        }
    }

    open fun printGrades() {
        for ( subject in passedSubjects ) {
            println("   $subject")
        }

        for ( subject in failedSubjects ) {
            println("   $subject")
        }        
    }

    open fun isPassed() : Boolean {
        return failedSubjects.size <= 2
    }
}

fun playWithClassInheritance() {
    val personObject = Person("Alice", "Carols")
    println( personObject.firstName )
    println( personObject.lastName )
    println( personObject.fullName() )

    val studentObject = Student("Gabbar", "Singh")
    println( studentObject.firstName )
    println( studentObject.lastName )
    println( studentObject.fullName() )
}


fun playWithStudentGrades() {
    val gabbar = Student("Gabbar", "Singh")
    val gabbarGradeDecoit = Subject(name = "Decoit", grade = 'D', points = 5.0, credits = 3.0 )
    val gabbarGradeSc = Subject(name = "Science", grade = 'F', points = 0.0, credits = 0.0 )
    val gabbarGradeShooting = Subject(name = "Shooting", grade = 'A', points = 9.0, credits = 4.0 )

    gabbar.recordGrade(gabbarGradeDecoit)
    gabbar.recordGrade(gabbarGradeSc)
    gabbar.recordGrade(gabbarGradeShooting)

    println( gabbar.fullName() )
    gabbar.printGrades()

    val alina = Student("Alina", "Mark")
    var alinaGradeEnglish = Subject(name = "English", grade = 'A', points = 9.0, credits = 4.0 )
    val alinaGradeSc = Subject(name = "Science", grade = 'D', points = 5.0, credits = 3.0 )
    val alinaGradeHistory = Subject(name = "History", grade = 'A', points = 9.0, credits = 3.0 )

    alina.recordGrade(alinaGradeEnglish)
    alina.recordGrade(alinaGradeSc)
    alina.recordGrade(alinaGradeHistory)

    println( alina.fullName() )
    alina.printGrades()
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class StudentAthlete(firstName: String, lastName: String) : Student(firstName, lastName) {
    val gamesPlayed = mutableListOf<Game>()

    fun recordGame(game: Game) {
        gamesPlayed.add(game)
    }

    override fun printGrades() {
        super.printGrades()

        for ( game in gamesPlayed ) {
            println("   $game")   
        }
    }

    // error: 'isPassed' hides member of supertype 'Student' and 
    // needs 'override' modifier
    override fun isPassed() : Boolean {
        return failedSubjects.size <= 1 && gamesPlayed.size >= 1
    }
}


fun playWithStudentAthlete() {
    val gabbar = StudentAthlete("Gabbar", "Singh")
    val gabbarGradeDecoit = Subject(name = "Decoit", grade = 'D', points = 5.0, credits = 3.0 )
    val gabbarGradeSc = Subject(name = "Science", grade = 'F', points = 0.0, credits = 0.0 )
    val gabbarGameShooting      = Game(name = "Shooting", grade = 'A', points = 9.0)
    val gabbarGameRunning       = Game(name = "Running", grade = 'B', points = 8.0 )
    val gabbarGameHorseRiding   = Game(name = "Horse Riding", grade = 'A', points = 9.0 )

    gabbar.recordGrade(gabbarGradeDecoit)
    gabbar.recordGrade(gabbarGradeSc)

    gabbar.recordGame(gabbarGameShooting)
    gabbar.recordGame(gabbarGameRunning)
    gabbar.recordGame(gabbarGameHorseRiding)

    println( gabbar.fullName() )
    gabbar.printGrades()
    println( gabbar.isPassed() )

    val alina = StudentAthlete("Alina", "Mark")
    var alinaGradeEnglish = Subject(name = "English", grade = 'A', points = 9.0, credits = 4.0 )
    val alinaGradeSc = Subject(name = "Science", grade = 'F', points = 0.0, credits = 0.0 )
    val alinaGradeMath = Subject(name = "Mathematics", grade = 'F', points = 0.0, credits = 0.0 )

    val alinaGradeHistory = Subject(name = "History", grade = 'A', points = 9.0, credits = 3.0 )
    val alinaGameTennis   = Game(name = "Tennis", grade = 'A', points = 9.0 )

    alina.recordGrade(alinaGradeEnglish)
    alina.recordGrade(alinaGradeSc)
    alina.recordGrade(alinaGradeMath)
    alina.recordGrade(alinaGradeHistory)
    alina.recordGame(alinaGameTennis )

    println( alina.fullName() )
    alina.printGrades()
    println( alina.isPassed() )

    val alice = Student("Alice", "Carols")
    var aliceGradeEnglish = Subject(name = "English", grade = 'A', points = 9.0, credits = 4.0 )
    val aliceGradeSc = Subject(name = "Science", grade = 'F', points = 0.0, credits = 0.0 )
    val aliceGradeMath = Subject(name = "Mathematics", grade = 'F', points = 0.0, credits = 0.0 )

    val aliceGradeHistory = Subject(name = "History", grade = 'A', points = 9.0, credits = 3.0 )

    alice.recordGrade(aliceGradeEnglish)
    alice.recordGrade(aliceGradeSc)
    alice.recordGrade(aliceGradeMath)
    alice.recordGrade(aliceGradeHistory)

    println( alice.fullName() )
    alice.printGrades()
    println ( alice.isPassed() ) 
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// School Have Music Band Consisting Of Band Members
//      Band Members Are Students
//      Music Band Have A Lot Many Types Of Music Players
//      e.g Guitar Player, Flute Player etc...

// Created BandMember Class
//      Band Member Is Also A Student

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    open val minimumPracticeTime: Int 
        get() { return 2 }
}

// Created Guitar Player Class
//      Guitar Player Is Also A Band Member
class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    override val minimumPracticeTime: Int
        get() { return 3 }
}

// Created Flute Player Class
//      Flute Player Is Also A Band Member
class FlutePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    override val minimumPracticeTime: Int
        get() { return 4 }
}

fun playWithRuntimeTypeCheck() {
    // error: type mismatch: inferred type is GuitarPlayer but String was expected
    val guitarPlayer: GuitarPlayer = GuitarPlayer("Shankar", "Ehsan")
    println( guitarPlayer )

    // You Can Assign Child Class Object To References Of Parent Type
        // GuitarPlayer Parent Is BandMember
        // BandMember Parent Is Student
        // Student Parent Is Person
    // Checking Type Of reference1
    println( guitarPlayer is GuitarPlayer )
    println( guitarPlayer is BandMember )
    println( guitarPlayer is Student )
    println( guitarPlayer is Person )

    val reference1 = guitarPlayer
    val reference2 : GuitarPlayer   = guitarPlayer
    // You Can Assign Child Class Object To References Of Parent Type
        // GuitarPlayer Parent Is BandMember
        // BandMember Parent Is Student
        // Student Parent Is Person
        // Hence GuitarPlayer Object Can Be Assigned To Any Of Parent Types References
    val reference3 : BandMember     = guitarPlayer
    val reference4 : Student        = guitarPlayer
    val reference5 : Person         = guitarPlayer

    // Checking Type Of reference1
    println( "Checking Type Of reference1")  
    println( reference1 is GuitarPlayer )
    println( reference1 is BandMember )
    println( reference1 is Student )
    println( reference1 is Person )

    val lata = BandMember("Lata", "Mageshkar")

    println( "Checking Type Of lata Object")
    println( lata is GuitarPlayer )
    println( lata is BandMember )
    println( lata is Student )
    println( lata is Person )

    val  milkha = Student("Milkha", "Singh")

    println( "Checking Type Of milkha Object")
    println( milkha is GuitarPlayer )
    println( milkha is BandMember )
    println( milkha is Student )
    println( milkha is Person )
}

// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Abstract Classes
//      Tells What It Will Do
//      Contains Function Declaractions i.e. Abstract Member Functions
//      CANNOT Create Objects/Instances of Abstract Class
abstract class Mammal(val birthDate: String) {
    abstract fun consumeFood() // Abstract Methodes Are Function Declarations
}

// Concerete/Child Classes MUST Implements Abstract Classes
//      Will Implement How, When, Where, Which Way It Will Do
//      Contains Function Implementation
//      Contains Properties
//      CANNOT Create Objects/Instances of Abstract Class

class Human(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() { // Function Definition/Implemnetation     
        println("Human Consuming Food!!!...")
    }
    
    fun createBirthCertificate() {
        println("Birth Certificate With DoB: $birthDate")
    }
}

fun playWithHumanAndMammal() {
    // Error: Cannot create an instance of an abstract class
    // val mammal = Mammal("1/1/2000") 

    val human = Human("1/1/2000")
    human.consumeFood()
    human.createBirthCertificate()
}


// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Sealed Classes
//     
//      Sealed Classes Are Abstract Class
//      You Can Create Child Classes With There Own Construtors
//      Sealed Classes Are Similar To enum Classes

sealed class Geometry {
    // Circle, Square Clases Are Created By Calling Different Constructor
    class Circle(val radius: Int) : Geometry()
    class Square(val sideLength: Int) : Geometry()
}

// Working With Sealed classes
//      Sealed Classes Works Like Enums With More Flexibility
//      Child Classes Can Have Different Construtors
fun sizeOfGeometery(geometry: Geometry): Int {
    return when (geometry) {
        is Geometry.Circle -> geometry.radius
        is Geometry.Square -> geometry.sideLength
        // Doesn't Require else block...
    }
}

fun playWithGeometries() {
    val circle1 = Geometry.Circle(4)
    val circle2 = Geometry.Circle(2)
    val square1 = Geometry.Square(4)
    val square2 = Geometry.Square(2)

    println(circle1.radius)
    println(circle2.radius)
    println(square1.sideLength)
    println(square2.sideLength)
}

// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

open class Shape {
    var boundaryColor: String
    var fillColor: String

    // Secondary Constructors
    constructor( boundaryColor : String ) {
        this.boundaryColor = boundaryColor
        this.fillColor = "Unknown"
    }

    // Secondary Constructors
    constructor( boundaryColor: String, fillColor: String ) {
        this.boundaryColor = boundaryColor
        this.fillColor = fillColor
    }

    open fun printData() {
        println("Shape Boundary Color: $boundaryColor and Fill Color: $fillColor")
    }
}

class Circle : Shape {
    var radius : Int

    // Secondary Constructors
    constructor( boundaryColor : String ) : super(boundaryColor) {
        this.boundaryColor = boundaryColor
        this.fillColor = "Unknown"
        this.radius = 0
    }

    // Secondary Constructors
    constructor( boundaryColor: String, fillColor: String ) : super(boundaryColor, fillColor){
        this.boundaryColor = boundaryColor
        this.fillColor = fillColor
        this.radius = 0
    }

    // Secondary Constructors
    constructor( boundaryColor: String, fillColor: String, radius: Int ) : super(boundaryColor, fillColor) {
        this.boundaryColor = boundaryColor
        this.fillColor = fillColor
        this.radius = radius
    }

    override fun printData() {
        println("Circle Boundary Color: $boundaryColor, Fill Color: $fillColor, Radius=$radius")
    }
}


fun playWithSecondaryConstructors() {
    val shape1 = Shape(boundaryColor = "Blue") 
    val shape2 = Shape(boundaryColor = "Blue", fillColor = "Red")

    shape1.printData()
    shape2.printData() 

    val circle1 = Circle(boundaryColor = "Blue") 
    val circle2 = Circle(boundaryColor = "Blue", fillColor = "Red")
    val circle3 = Circle(boundaryColor = "Blue", fillColor = "Red", radius = 22)
     
    circle1.printData()
    circle2.printData() 
    circle3.printData() 
}

// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// LOCAL CLASSES AND LOCAL FUNCTIONS
//      Local Classes Defined Inside Function
//      Local Functions Defined Inside Function
//      Local Functions and Classes Are Not Accessible 
//          Outside Enclosing Function

fun playWithLocalClassesAndFunctions() { // Enclosing Function
    
    // Person Is Local Class
    //      Because It's Defined Inside A Function
    class Person(val firstName: String, val lastName: String)

    val person = Person("Alice", "Carols")
    println( person.firstName )
    println( person.lastName )

    //_______________________________

    // doSomething() Is Local Function
    //      Because It's Defined Inside A Function
    fun doSomething() {
        println("Local Function Defined Insider Another Function")
    }

    doSomething()
}


// _____________________________________________________

// Experiment Following Code, Moment Done >>> RAISE HAND!


data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"

        return "Name : $firstName $lastName, Age: $age"
    }
}
fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}


// ______________________________________________________

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

// Nested Classes
//      Define Class Inside A Class
//          By Default Inside Class Is Nested Class
//      CANNOT Assess Outer Class Context In Inside Inner Class
class Car1(val carName: String) { // Outer Class
    val steering: Int = 0
     // Car1 Have Twp Property carName And steeing
     // and It's Defined In Outer Class Car1

    // Nested Class
    //      Definining Class Inside Class     
     class Engine(val engineName: String) { // Nested Class 
        // Engine Have One Property engineName and 
        // It's Defined In Engine Nested Class/Context 
        // Properties/Functions Defined Inside Class Can Be Accessed With In The Class
        // Nested Class CANNOT Access Properties Defined In Outer Class/Context   
        override fun toString(): String {
            // Can't Access Data From Outer Class
            // error: unresolved reference: carName
            // error: unresolved reference: steering
            // return "$engineName in a $carName have Steering Value: $steering"
            return "$engineName"
        }
    }
}

// Inner Classes
//      Define Class Inside A Class
//          By Default Inside Class Is Inner Class
//      CAN Assess Outer Class Members In Inside Inner Class
class Car2(val carName: String) { // Outer Class
    val steering: Int = 0
     // Car1 Have Twp Property carName And steeing
     // and It's Defined In Outer Class Car1

    // Inner Class
    //      Definining Class Inside Class     
     inner class Engine(val engineName: String) { // Inner Class 
        // Engine Have One Property engineName and 
        // It's Defined In Engine Inner Class/Context 
        // Properties/Functions Defined Inside Class Can Be Accessed With In The Class
        // Inner Class CAN Access Properties Defined In Outer Class/Context   
        override fun toString(): String {
            // CAN Access Data From Outer Class
            return "$engineName in a $carName have Steering Value: $steering"
        }
    }
}

fun playWithNestedAndInnerClasses() {
    val mazda1 = Car1("mazda")
    // To Access Nested Class Use Outer Class with Dot Operator
    val mazdaEngine1 = Car1.Engine("rotary")
    println(mazdaEngine1) // > rotary engine in a mazda

    val mazda = Car2("mazda")
    // To Access Innser Class Use Outer Class Object with Dot Operator
    val mazdaEngine = mazda.Engine("rotary")
    println(mazdaEngine) // > rotary engine in a mazda
}



// ______________________________________________________
// ______________________________________________________
// ______________________________________________________
// ______________________________________________________

// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {
    println("\nFunction : playWithClassInheritance")
    playWithClassInheritance()

    println("\nFunction : playWithStudentGrades")
    playWithStudentGrades()

    println("\nFunction : playWithStudentAthlete")
    playWithStudentAthlete()

    println("\nFunction : playWithRuntimeTypeCheck")
    playWithRuntimeTypeCheck()

    println("\nFunction : playWithHumanAndMammal")
    playWithHumanAndMammal()

    println("\nFunction : playWithSecondaryConstructors")
    playWithSecondaryConstructors()

    println("\nFunction : playWithLocalClassesAndFunctions")
    playWithLocalClassesAndFunctions()

    println("\nFunction : playWithPrivilegedUser")
    playWithPrivilegedUser()

    println("\nFunction : playWithNestedAndInnerClasses")
    playWithNestedAndInnerClasses()
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
}


