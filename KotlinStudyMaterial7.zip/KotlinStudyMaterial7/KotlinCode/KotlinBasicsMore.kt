/* Commands For Compiling And Running Code

kotlinc KotlinBasicsMore.kt -include-runtime -d basicsMore.jar
java -jar basicsMore.jar

*/

package learnKotlin

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Creating Person Class/Type Having Two Properties viz. name And isMarried
//		name Is Variable 	i.e. Mutable Property
//		isMarried Is Value 	i.e. Immutable Property

class Person(var name: String, val isMarried: Boolean) 

fun playWithPersonProperties() {

	// Creating person Object Of Person Type
	val person = Person("Alice", false)
	
	// Getting Properties Values
	println(person.name)       
	println(person.isMarried)

	// Setting Property Value
	person.name = "Alice Carols"
	// person.isMarried = true // error: val cannot be reassigned
	
	println(person.name)
	println(person.isMarried)

	// Creating person1 Object Of Person Type
	val person1 = Person("Sachin", true)
	println(person1.name)
	println(person1.isMarried)

	person1.name = "Sachin Tendulkar"
	// person1.isMarried = false // error: val cannot be reassigned

	println(person1.name)
	println(person1.isMarried)
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Creating Rectangle Class/Type Having Three Properties
//		height, width and isSquare Properties
//		All Three Properties Are Value i.e. Immtuable Properties
class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		get() {
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle(100, 200)
	println(rectangle1.height)
	println(rectangle1.width)
	println(rectangle1.isSquare)

	// rectangle1.width 	= 1000 // error: val cannot be reassigned
	// rectangle1.height 	= 1000 // error: val cannot be reassigned
	// rectangle1.isSquare  = true  // error: val cannot be reassigned

	val rectangle2 = Rectangle(200, 200)
	println(rectangle2.height)
	println(rectangle2.width)
	println(rectangle2.isSquare)	

	// rectangle2.width 	= 2000 // error: val cannot be reassigned
	// rectangle2.height 	= 4000 // error: val cannot be reassigned
	// rectangle2.isSquare  = false // error: val cannot be reassigned
}

// Creating RectangleAgain Class/Type Having Three Properties
//		height, width and isSquare Properties
//		Two Properties width and heigth Are Variable i.e. Mutuable Properties
//		One Property isSquare Is Value i.e. IMMutuable Property

class RectangleAgain(var height: Int, var width: Int) {
	val isSquare: Boolean
		get() {
			return height == width
		}
}

fun playWithRectangleAgain() {
	val rectangle1 = RectangleAgain(100, 200)
	println(rectangle1.height)
	println(rectangle1.width)
	println(rectangle1.isSquare) // Calling get() Getter Method For Property isSquare
	
	rectangle1.width = 1000
	rectangle1.height = 1000
	// rectangle1.isSquare = true // error: val cannot be reassigned

	println(rectangle1.height)
	println(rectangle1.width)
	println(rectangle1.isSquare)

	val rectangle2 = RectangleAgain(200, 200)
	println(rectangle2.height)
	println(rectangle2.width)
	println(rectangle2.isSquare) // Calling get() Getter Method For Property isSquare	
	
	rectangle2.width = 2000
	rectangle2.height = 4000
	// rectangle2.isSquare = false  // error: val cannot be reassigned

	println(rectangle2.height)
	println(rectangle2.width)
	println(rectangle2.isSquare)	
}


// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Creating Color Enum Type Having Values RED, GREEN And BLUE
enum class Color {
	RED, GREEN, BLUE
}

fun getStringForColor(color: Color) : String {
	return when(color) {
		Color.RED 	-> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE 	-> "Blue Color"
	}
}

fun playWithColors() {
	println( Color.RED )   // Accessing Color RED Value
	println( Color.GREEN ) // Accessing Color GREEN Value
	println( Color.BLUE )  // Accessing Color BLUE Value

	println( getStringForColor( Color.RED ) )
	println( getStringForColor( Color.GREEN ) )
	println( getStringForColor( Color.BLUE ) )
}



// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

enum class Colour(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255), ORANGE(200, 200, 200) ;

	fun rgb() = ( r * 255 + g ) * 255 + b 
}

fun playWithColorsAgain() {

	println( Colour.RED )   // Accessing Colour RED Value
	println( Colour.RED.r )   // Accessing Colour r Property Of RED Value
	println( Colour.RED.g )   // Accessing Colour g Property Of RED Value
	println( Colour.RED.b )   // Accessing Colour b Property Of RED Value
	println( Colour.RED.rgb() )   // Calling rgb() Function For Colour RED Value

	println( Colour.GREEN ) // Accessing Colour GREEN Value
	println( Colour.GREEN.r ) // Accessing Colour r Property Of GREEN Value
	println( Colour.GREEN.g ) // Accessing Colour g Property Of GREEN Value
	println( Colour.GREEN.b ) // Accessing Colour b Property Of GREEN Value
	println( Colour.GREEN.rgb() ) // Calling rgb() Function For Colour GREEN Value

	println( Colour.BLUE )  // Accessing Colour BLUE Value
	println( Colour.BLUE.r )  
	println( Colour.BLUE.g )  
	println( Colour.BLUE.b )  
	println( Colour.BLUE.rgb() )  
}


// _______________________________________________
// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithPersonProperties")
	playWithPersonProperties()
	
	println("\nFunction : playWithRectangle")
	playWithRectangle()

	println("\nFunction : playWithRectangleAgain")
	playWithRectangleAgain()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithColorsAgain")
	playWithColorsAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

