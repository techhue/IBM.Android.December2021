/*
1. Save File As KotlinBasics.kt In KotlinCode Directory

2. Compile Code With Following Command
		kotlinc KotlinBasics.kt -include-runtime -d basics.jar

3. Run Code With Following Command 
		java -jar basics.jar
*/

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

package learnKotlin

// Function
// 		Doesn't take any argument
//		and Returns Unit Value of Unit Type
//		By Default Return Type Is Unit
fun helloWorld()  {
	println("Hello World!!!")
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function
// 		Doesn't Take Two Int Type Arguments
//		and Returns Int Type Value

fun max( a: Int, b: Int ) : Int {
	return if (a > b) a else b
}

fun playWithMax() {
	var result = max(100, 200)
	println("Result : $result")

	result = max( -900, 300 )
	println("Result : $result")
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>>.RAISE HAND!

fun playWithVariableAndConstants() {
	// val Creates Constant Values i.e. Immutable Identifiers
	val number: Int = 100
	val pi: Double = 3.14159

	println(number)
	println(pi)

	// Uncomment and Compile Following 2 Lines 
	// number = 8888 		s// error: val cannot be reassigned
	// println(number)

	// var Creates Variable Values i.e. Mutable Values
	var variableNumber: Int = 100
	println(variableNumber)
	variableNumber = 999
	println(variableNumber)

	// _ Used To Improve Reading Will Be Removed By Compiler
	variableNumber = 1_000_000 
	println(variableNumber)
	
	var counter: Int = 1
	counter += 1
	counter += 1
	println(counter)
	
	counter = 10
	counter *= 3
	counter /= 2
	println(counter)	
}

// Function : playWithVariableAndConstants
// 100
// 3.14159
// 100
// 999
// 1000000
// 3
// 15

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypes() {
	// Annotating Variable With Type Explicitly
	var integerValue: Int = 100 	// It's Of Int Type 
	println(integerValue)

	var decimalValue: Double = 12.5 // It's Of Double Type
	println(decimalValue)

	// Converting Double Type Value to Int Type Value
	integerValue = decimalValue.toInt() // Truncation After Point 
	println(integerValue)

	// Annotating Variable With Type Explicitly
	val hourlyRate: Double = 20.20
	val hoursWorked: Int = 10
	val totalCost: Double = hourlyRate * hoursWorked 
	println(totalCost)

	// Type Is Implicitly Imferred From RHS Value And Binded With LHS

	// Expressions Is
	// LHS Identifier = RHS Value
	// 1. Compiler Will Inference Type From RHS Value
	// 2. Inferenced Type Will Be Binded With LHS Indentifier
	
	// Compiler Interred Type of 42 Value Is Int
	// Inferred Type Int Will Be Binded With something Identifier
	// Hence something Identifier Type Will Become Int 
	
	val something = 42 
	println(something)

	// Compiler Interred Type of 3.14159 Value Is Double
	// Inferred Type Double Will Be Binded With somethingAgain Identifier
	// Hence SomethingAgain Identifier Type Will Become Double 
	
	val somethingAgain = 3.14159
	println(somethingAgain)

	val someValue = 3 // 3 of Type Int, Hence someValue will Be Int Type	
	println(someValue)

	// Coverting Int Type Value To Double Value
	val doubleValue = someValue.toDouble()
	println(doubleValue)
}

// Function : playWithDataTypes
// 100
// 12.5
// 12
// 202.0
// 42
// 3.14159
// 3
// 3.0


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithCharAndStringDataTypes() {
	
	// Char and Kotlin.Char are same and both are Character Data Type
	val upperA: Char = 'A' // Inside Single Quotes is Kotlin Character
	val lowerA: kotlin.Char = 'a'

	println(upperA)
	println(lowerA)

	// Data Type of stringValue Indenfier will be String
	// Following 2 lines of code same
	// Explicit Type Annotation
	val stringValue0: String = "Hello World!!!" // Double "" String Value
	println(stringValue0)
	
	// What Is The Data Type Of Identifier stringValue1 ????

	// Implicitly Type Is Inferred and Inferred Type Is String
	// Inside Double Quotes "" String Value

	// error: type mismatch: inferred type is String but Int was expected
	// inferred type is String Means
	//		From RHS Value Type Inferred Is String
	//but Int was expected
	//		But On LHS Identifier Defined Of Int Type
	// error: type mismatch
		// Hence RHS Type Not Equal To LHS Type
	// val stringValue1: Int = "Hello World!!!" 

	/// Following Two Lines Of Code Are Doing Same Thing
	// val stringValue1: String = "Hello World!!!" 
	val stringValue1 = "Hello World!!!" 
	
	println(stringValue1)

	// What Is The Data Type Of Identifier messaage And name ???

	var message = "Hello, " + "My name is "
	val name = "Alice Carol"
	message += name // String Concatenation
	println(message)

	val exclamationMark: Char = '!'
	message += exclamationMark // Can also Concatinate Char With String
	println(message)

	// String Interpolation
	//		Sustituting Values Of Identifiers Inside String
	//		and Forming New String After Substition
	// Identifier name Value Is Substituted
	// To Access Value of Identifier Inside "" Double Quotes Use $
	val interpolatedString = "Hello, my name is $name!!!"
	println(interpolatedString)

	// Following Two Lines Are Same
	val oneThird: Double = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	
	// What Is The Type Of oneThirdAgain???
	// 		oneThirdAgain Binded To Double Type Inferred From RHS
	val oneThirdAgain = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	
	println(oneThird)
	println(oneThirdAgain)

	// Explicitly Annoating With Float Type
	//  error: type mismatch: inferred type is Double 
	//  	but Float was expected
	// 1.0 and 3.0 Type is Double and Double / Double is Double
	// RHS Value is Double and LHS Indentifier is Float
	// Hence Error...
	// val oneThirdOnceAgain: Float = 1.0 / 3.0 // Error

	val oneThirdOnceAgain: Float = (1.0 / 3.0).toFloat()
	println(oneThirdOnceAgain)

	// String Interpolation
	//		Substituting Identifier oneThird Value
	val oneThirdString = "One third is $oneThird is Double Type"	 
	println(oneThirdString)

	// String Interpolation
	//		Substituting Expression 1.0 / 3.0 Value After Evaluation
	val oneThirdStringAgain = "One third is ${ 1.0/ 3.0 } is Double Type"	 
	println(oneThirdStringAgain)

	// Multiple Lines String i.e. Paragraph
	//		Are Stored Inside Triple Quotes """ """
	val bigString = """
			|You can have a stringValue
			|that contains multiple
			|lines
			|using triple quotes
	"""

	println(bigString)

	// Remvoing White Space Characters From Before and After
	println(bigString.trimMargin())
}


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithTupleDataTypes() {
	// Following Three Lines Of Code Are Same

	// Making Tuple Using Pair Type
	//		Tuple Is Ordered Data

	// Explicitly Annotating LHS with Type	
	val coordinates: Pair<Int, Int> = Pair(2, 3)
	
	// Implicitly Inferrred Type From RHS
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>
	val coordinatesInferred = Pair(2, 3)

	// Implicitly Inferrred Type From RHS
	// Shortcut Syntax Using Infix Notation
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>	
	val coordinatesWithTo = 2 to 3

	// What Is Type Of x1 and y1???
	// 		x1 And y1 Type Inferred From RHS 
	// 		i.e. From coordinates.first And coordinate.second
	// 		coordinates.first And coordinate.second Both Of Type Int
	val x1 = coordinates.first
	val y1 = coordinates.second
	println(x1)
	println(y1)

	val x2 = coordinatesWithTo.first
	val y2 = coordinatesWithTo.second
	println(x2)
	println(y2)

	// Unpacking or Decluttering 
	val (x3, y3) = coordinates
	println(x3)
	println(y3)
	// val (x3, y3) Line Of Code WIll Be Similar To Following
	// val x3 = coordinates.first
	// val y3 = coordinates.second

	println(coordinatesInferred.first)
	println(coordinatesInferred.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Double>
	val coordinatesDoubles = Pair(2.22, 3.30)
	println(coordinatesDoubles.first)
	println(coordinatesDoubles.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Int>
	val coordinatesMixed = Pair(2.22, 33)
	println(coordinatesMixed.first)
	println(coordinatesMixed.second)

	// error: type mismatch: inferred type is Triple<Int, Int, Int> but Int was expected
	// val coordinates3D: Int = Triple(2, 3, 1)

	// LHS Type WIll Be Inferrenced From RHS i.e. Triple<Int, Int, Int>
	val coordinates3D = Triple(2, 3, 1)
	println(coordinates3D.first)
	println(coordinates3D.second)
	println(coordinates3D.third)

	// Unpacking or Decluttering 
	val (x4, y4, z4) = coordinates3D
	println(x4)
	println(y4)
	println(z4)

	val (x5, y5, _) = coordinates3D
	println(x5)
	println(y5)

	val (x6, _, y6) = coordinates3D
	println(x6)
	println(y6)
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypesAgain() {
	// Implicitly Inferred Type From RHS
	//		12 Have Default Type Int
	val aa  = 12 
	println(aa)

	val a: Short = 12
	val b: Byte = 120
	val c: Int = -100000

	val d = 999 // By Default Type Will Be Int
	println(d)

	// LHS Type Will Be Inferred From RHS Expression/Value
	// Typecast to Upper Type i.e. Short and Byte Will Become Int
	// 		a + b + c result will become Int
	//		Hence LHS answer Type Will Be Int
	val answer = a + b + c 
	println(answer)

	// Any Type Can Store Any Type Of Data
	//	Storing Int Type Data In Any Type
	val anyNumber: Any = 42
	println(anyNumber)

	//	Storing String Type Data In Any Type
	val anyString: Any = "Any String Value..."
	println(anyString)	
	
	//	Storing Double Type Data In Any Type	
	val anyDouble: Any = 46.90
	println(anyDouble)

	// error: type mismatch: inferred type is String but Int was expected
	// val something0: Int = "Any String Value..."
	// val something1: String = 42
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithKotlinExpressions() {	
	// error: the boolean literal does not conform to the expected type String
    // val yes: String = true

	// What Data Type Of yes And no???
	//		It's Boolean Type
    val yes = true
    println(yes)

    val no: Boolean = false
    println(no)


    // doesOneEqualTwo and doesOneNotEqualTwo Will Be Boolean Type
    val doesOneEqualTwo = (1 == 2)  // Equality Operator
    println(doesOneEqualTwo)

    val doesOneNotEqualTwo = (1 != 2) // Non-Equality Operator
    println(doesOneNotEqualTwo)

   	// alsoTrue Will Be Of Boolean Type
    val alsoTrue = !(1 == 2)
    println(alsoTrue)

   	// isOneGreaterThanTwo Will Be Of Boolean Type
    val isOneGreaterThanTwo = (1 > 2) // Relational Operator
    println(isOneGreaterThanTwo)

   	// isOneLessThanTwo Will Be Of Boolean Type
    val isOneLessThanTwo = (1 < 2) // Relational Operator
    println(isOneLessThanTwo)

   	// and Will Be Of Boolean Type
    val and = true && true // Logical AND
    println(and)

   	// or Will Be Of Boolean Type
    val or = true || false // Logical OR
    println(or)

   	// andTrue Will Be Of Boolean Type
    val andTrue = 1 < 2 && 4 > 3 // Relational And Logical AND Operator
    println(andTrue)

   	// andFalse Will Be Of Boolean Type
    val andFalse = 1 < 2 && 3 > 4 // Relational And Logical AND Operator
    println(andFalse)

   	// orTrue Will Be Of Boolean Type
    val orTrue = 1 < 2 || 3 > 4 // Relational And Logical OR Operator
    println(orTrue)

   	// orFalse Will Be Of Boolean Type
    val orFalse = 1 == 2 || 3 == 4 // Equality And Logical OR Operator
    println(orFalse)

   	// andOr Will Be Of Boolean Type
    val andOr = (1 < 2 && 3 > 4) || 1 < 4	// Relational And Logical OR + AND Operator
    println(andOr)

    // What Is The Data Type Of guess???
    //		It's String Type
    val guess = "dog"
    println(guess)

    // What Is The DataType Of dogEqualsCat???
    //		It's Boolean
    val dogEqualsCat = guess == "cat"
    println(dogEqualsCat)

    // What Is The DataType Of order???
    // 		It's Boolean
    val order = "cat" < "dog"
    println("ORDER = " + order)
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithIfElseConstructs() {
	// if ( Expression ) 
	// Expression Can Be Any Logical Expression 
	//		i.e. Evaluates Into true/false Value
    
    if (2 > 1) {
        println("Yes, 2 is greater than 1.")
    } else {
        println("No, 2 is Not greater than 1.")    	
    }

    val animal = "Fox"
    if (animal == "Cat" || animal == "Dog") {
        println("Animal is a house pet.")
    } else {
        println("Animal is not a house pet.")
    }

    val a = 5
    val b = 10

    // Terneary Operator
    // if ( LogicalExpression ) Expr1 else Expr2
    // 		If Expression is true Then if-else Expression Value Will Be Expr1
    //		otherwise it will be Expr2
  
    // if-else Construct is Expression In Kotlin
    // Expression Have Always Return Value

    val min = if (a < b) a else b
    val max = if (a > b) a else b
    println(min)
    println(max)

    val hourOfDay = 12
    val timeOfDay = if (hourOfDay < 6) {
        "Early morning"
    } else if (hourOfDay < 12) {
        "Morning"
    } else if (hourOfDay < 17) {
        "Afternoon"
    } else if (hourOfDay < 20) {
        "Evening"
    } else if (hourOfDay < 24) {
        "Late evening"
    } else {
        "INVALID HOUR!"
    }
    println(timeOfDay)

//_______________________________________________

    val name = "Dicken Lucas"

    if (1 > 2 && name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }

    if (1 < 2 || name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }

    if (1 < 2 || name == "Ticken Tucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }

// _____________________________________________________
    
    // Predict The Output Of Following Code...
    
    var hoursWorked = 45
    var price = 0
    if (hoursWorked > 40) {
    	// hoursOver40 Scope Is Inside if-else Block
        val hoursOver40 = hoursWorked - 40
        price += hoursOver40 * 50
        hoursWorked -= hoursOver40
    }
    price += hoursWorked * 25
   	println(hoursWorked)
    println(price)

    // println(hoursOver40) // error: unresolved reference: hoursOver40
}


// _____________________________________________________



// Predict The Output Of Following Code...

fun playWithLoops() {
    var sum = 1
    while (sum < 1000) {
        sum = sum + (sum + 1)
    }
    println(sum)

    sum = 1
    do {
        sum = sum + (sum + 1)
    } while (sum < 1000)
    println(sum)

    sum = 1
    while (true) {
        sum = sum + (sum + 1)
        if (sum >= 1000) {
            break
        }
    }
    println(sum)



//____________________________________________


// Predict The Output Of Following Code...

    sum = 1
    while (true) {
    	if ( sum % 2 == 0 ) {
     	   	sum = sum + (sum + 2)
    	} else {
    		sum = sum + (sum + 1)
    	}

        if (sum >= 100) {
            break
        }
    }
    println(sum)

//__________________________________________

}



// _____________________________________________________






fun playWithForLoop() {

//______________________________________________________________

// Predict The Output Of Following Code...

	// .. is Range Operator
	// Closed Interval [0, 5] i.e. Both 0 and 5 inclusive
    val closedRange = 0..5 
	println(closedRange)
    for (i in closedRange) {
        print(" $i ")
    }
    println()

	// Half Open [0, 5) i.e. 0 inclusive and 5 excluded
    val halfOpenRange = 0 until 5 // i.e. 0..4
	println(halfOpenRange)
    for (i in halfOpenRange) {
        print(" $i ")
    }
	println()

	// Closed Interval [5, 0] i.e. 5 and 0 Both Inclusive
    val decreasingRange = 5 downTo 0 
	println(decreasingRange)
    for (i in decreasingRange) {
        print(" $i ")
    }
    println()

// Output Of Above Code
// 0..5
//  0  1  2  3  4  5 
// 0..4
//  0  1  2  3  4 
// 5 downTo 0 step 1
//  5  4  3  2  1  0 

//______________________________________________________________

// Predict The Output Of Following Code...

    val count = 10
    var sum = 0
    // i Values : 1, 2, 3, 4,...
    for (i in 1..count) { // Default step or increment/decrement is by 1
        sum += i
    }
    println(sum)


    sum = 1
    var lastSum = 0
    repeat(10) {
        val temp = sum
        sum += lastSum
        lastSum = temp
    }
    println(sum)

//______________________________________________________________

// Predict The Output Of Following Code...

    sum = 0
    // i Values : 1, 3, 5....
    for (i in 1..count step 2) {
        sum += i
    }
    println(sum)

    sum = 0
    for (i in count downTo 1 step 2) {
        sum += i
    }
    println(sum)


//______________________________________________________________

// Predict The Output Of Following Code...

    sum = 0
    for (row in 0 until 8) {
        if (row % 2 == 0) {
            continue
        }

        for (column in 0 until 8) {
            sum += row * column
        }
    }
    println(sum)


    sum = 0
    // Labels
    rowLoop@ for (row in 0 until 8) {
        columnLoop@ for (column in 0 until 8) {
            if (row == column) {
                continue@rowLoop
            }
            sum += row * column
        }
    }
    println(sum)

}

// _______________________________________________


fun playWithWhenExpression() {
	
	val number = 20

	// when Expression Similar To switch In C/C++/Java
	when(number) {
		0  		->  println("Zero Value")
		10 		->  println("Ten Value")
		else 	->  println("Non-zero Value") // else Means Default Option
	}

	val numberName = when(number) {
		2 		-> "Two"
		4 		-> "Four"
		6 		-> "Six"
		8 		-> "Eight"
		10 		-> "Ten"
		else 	-> { 
			println("Reached Default Block...")
			"Unknown"  // This Will Be Return Value Of Else Block
		} // Last Expression Evaluated Will Be Return Value Of Else Block
	}

	println("Number Name : $numberName") 


	val animal = "Dog"
 
	val animalDetail = when(animal) {
		"Cat", "Dog" 			  ->  "Animal Can Be House Pet"
		"Cow", "Buffelo", "Goat"  ->  "Animal Can Give Milk"
		else  					  ->  "Animal Either Not Pet Or Give Milk"
	}

	println("For $animal : $animalDetail")


	val hourOfDay = 12
	var timeOfDay: String

	timeOfDay = when(hourOfDay) {
		0, 1, 2, 3, 4, 5    -> "Early Morning"
		6, 7, 8, 9, 10, 11  -> "Morning"
		12, 13, 14, 15, 16	-> "Afternoon"
		17, 18, 19 			-> "Evening"
		20, 21, 22, 23 		-> "Late Evening"
		else 				-> "Invalid Hours"
	}

	println("Time Of The Day : $timeOfDay")

	timeOfDay = when(hourOfDay) {
		in 0..5    	-> "Early Morning"
		in 6..11  	-> "Morning"
		in 12..16	-> "Afternoon"
		in 17..19 	-> "Evening"
		in 20..23 	-> "Late Evening"
		else 		-> "Invalid Hours"
	}

	println("Time Of The Day : $timeOfDay")

}

	

// _______________________________________________
// _______________________________________________


fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithVariableAndConstants")
	playWithVariableAndConstants()
	
	println("\nFunction : playWithDataTypes")
	playWithDataTypes()
	
	println("\nFunction : playWithCharAndStringDataTypes")
	playWithCharAndStringDataTypes()

	println("\nFunction : playWithTupleDataTypes")
	playWithTupleDataTypes()

	println("\nFunction : playWithDataTypesAgain")
	playWithDataTypesAgain()

	println("\nFunction : playWithKotlinExpressions")
	playWithKotlinExpressions()

	println("\nFunction : playWithIfElseConstructs")
	playWithIfElseConstructs()

	println("\nFunction : playWithLoops")
	playWithLoops()

	println("\nFunction : playWithForLoop")
	playWithForLoop()

	println("\nFunction : playWithWhenExpression")
	playWithWhenExpression()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

