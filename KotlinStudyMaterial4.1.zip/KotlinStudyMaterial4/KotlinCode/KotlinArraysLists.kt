/*
kotlinc KotlinArraysLists.kt -include-runtime -d arrayslists.jar
java -jar arrayslists.jar
*/

package learnKotlin

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done RAISE HAND!

fun playWithArrays( ) {
    
    // Creating Array of 4 Elememnts Of Type Int
    val evenNumbers = arrayOf(2, 4, 6, 8)
    // joinToString will Return String Of 
    //      Joined Elements Of Array As Comma Seperated List
    println(evenNumbers.joinToString()) // 2, 4, 6, 8

    // Creating Array With 5 Elements Having Each Value Of 5
    val fiveFives = Array( 5, { 5 } ) // 5, 5, 5, 5, 5
    println(fiveFives.joinToString())

    // Creating Array With 5 Elements Having Each Value Of 5
    val fiveTens = Array( 5, { 10 } ) // 10, 10, 10, 10, 10
    println( fiveTens.joinToString() )


    val vowels = arrayOf("a", "e", "i", "o", "u")
    println(vowels.joinToString()) // a, e, i, o, u

    // array of int primitive types
    val oddNumbers = intArrayOf(1, 3, 5, 7)  // int Is Primimitive imt
    println(oddNumbers.joinToString()) // 1, 3, 5, 7
     
     // Converting To Array of Primitive int To Array Of Int Type
    val otherOddNumbers = arrayOf(1, 3, 5, 7).toIntArray() 
    println(otherOddNumbers.joinToString()) // 1, 3, 5, 7
    
    // Creating Array of 4 Elements Each Having Double Value 0.0
    val zeros = DoubleArray(4) 
    println(zeros.joinToString()) // 0.0, 0.0, 0.0, 0.0
	
    // Creating List of 4 Elements Each Of Type String
	val innerPlanets = listOf("Mercury", "Venus", "Earth", "Mars")
	println(innerPlanets.joinToString())

    // Creating Array List of 4 Elements Each Of Type String
    val innerPlanetsArrayList = arrayListOf("Mercury", "Venus", "Earth", "Mars")
    println(innerPlanetsArrayList.joinToString())

    // Creating Empty List Of String Type Elements
    val subscribers: List<String> = listOf() // Empty List with No Members
    println(subscribers.joinToString())
}


// _____________________________________________________


fun playWithArraysAgain() {
   // Creating Mutable List Of 4 Elements Of String Type
    val outerPlanets = mutableListOf("Jupiter", "Saturn", "Uranus", "Neptune")
    println(outerPlanets)

    // Creating Mutable List Of 0 Elements Of String Type
    val exoPlanets = mutableListOf<String>() // Empty Mutable List of String
    println( exoPlanets )
    println( exoPlanets.isEmpty() ) // true

    // Accessing Member Elements Of MutableList

    // Creating Mutable List Of 5 Elements Of String Type
    val players = mutableListOf("Bob", "Alice", "Cindy", "Dan", "Zodiac", "Ramya")
    println( players )
    // Using isEmpty() Member Methods Of MutableList
    println( players.isEmpty() ) // false

    // Using size Member Property Of MutableList
    if (players.size < 2) {
        println("We need at least two players!")
    } else {
        println("Let's start!")
    } // > Let's start!


    // Creating Empty Array Of 0 Elements Of Type Int
    val arr = arrayOf<Int>()
     println( arr )
    // Accessing first() Member Function Will Give Runtime Error
    //      Exception in thread "main" java.util.NoSuchElementException: Array is empty.
    // println( arr.first() ) // NoSuchElementException

    var currentPlayer = players.first()
    println(currentPlayer)  // > Alice
    println( players.last() ) // > Ramya
    println( players )

    // minOrNull() Means Return Minimum Value (Alphabetical Order) Or Null
    // And Return Minimum Element If Exists Otherwise Return null
    val minPlayer = players.minOrNull()
    println( minPlayer )
    if (minPlayer != null) {
        println("$minPlayer will start") // > Alice will start
    }

    // maxOrNull() Means Return Maximum Value (Alphabetical Order) Or Null
    // And Return Maximum If Exists Otherwise Return null
    val maxPlayer = players.maxOrNull()
    if (maxPlayer != null) {
        println("$maxPlayer is the MAX") // > Zodiac is the MAX
    }
    
    val numbers = arrayOf(20, 30, 90,10)
    println( numbers.first() )// > 20

    // minOrNull() Means Return Minimum Value Or Null
    // And Return Minimum Element If Exists Otherwise Return null
    println( numbers.minOrNull() ) // > 10

    // maxOrNull() Means Return Maximum Value Or Null
    // And Return Maximum Element If Exists Otherwise Return null
    println( numbers.maxOrNull() ) // > 90


    // Accessing Elements Of List Using Indexing [] Operator Or get() Function
    val firstPlayer = players[0]
    println("First player is $firstPlayer") // First player is Alice
    val firstPlayer1 = players.get(0)
    println("First player is $firstPlayer1") // First player is Alice

    val secondPlayer = players[1]
    println("Second player is $secondPlayer") // First player is Alice
    val secondPlayer1 = players.get(1)
    println("Second player is $secondPlayer1") // First player is Alice

    // Runtime Error
    // Exception in thread "main" java.lang.IndexOutOfBoundsException: 
    // Index 6 out of bounds for length 6

    // Because Index Ranges From 0 To Length - 1 
    // val player = players[6] //  IndexOutOfBoundsException

    // Using Ranges To Get Slice
    val upcomingPlayersSlice = players.slice(1..2).toMutableList()
    println(players)
    println(upcomingPlayersSlice)
    val upcomingPlayersSlice1 = players.slice(2..5).toMutableList()
    println(upcomingPlayersSlice1)

    val upcomingPlayersArray = players.slice(1..3).toTypedArray()
    println(upcomingPlayersArray.joinToString()) // > Bob, Cindy

    // Checking for An Element Exists Or Not In Players List
    fun isEliminated(player: String): Boolean {
        return player !in players
    }

    println( isEliminated("Bob"))   // > false
    println( isEliminated("Modi"))  // > true

    val playersSelected = players.slice(1..3).toMutableList()
    println( playersSelected ) // [Alice, Cindy, Dan]
    // Checking for Alice Exists Or Not In Selected Players List
    println( "Alice" in playersSelected )           // true
    println( playersSelected.contains("Alice") )    // true

    val playersSelected1 = players.slice(2..5).toMutableList()
    println( playersSelected1 ) // [Cindy, Dan, Zodiac, Ramya]
    // Checking for Alice Exists Or Not In Selected Players List
    println( "Alice" in playersSelected1 )           // false
    println( playersSelected1.contains("Alice") )    // false

    // Modifying Lists

    // Adding Elements In Mutable List
    println(players) // [Bob, Alice, Cindy, Dan, Zodiac, Ramya]
    players.add("Eli")
    println(players) // [Bob, Alice, Cindy, Dan, Zodiac, Ramya, Eli]
    
    println(players.joinToString()) // > "Alice", "Bob", "Cindy", "Dan", "Eli"

    players += "Gina"
    println(players) // [Bob, Alice, Cindy, Dan, Zodiac, Ramya, Eli, Gina]

    println(players.joinToString()) // > "Alice", "Bob", "Cindy", "Dan", "Eli", "Gina"

    players.add(5, "Frank") // Add Frank At 5th Index
    println(players) // [Bob, Alice, Cindy, Dan, Zodiac, Frank, Ramya, Eli, Gina]
    println(players.joinToString()) // Bob, Alice, Cindy, Dan, Zodiac, Frank, Ramya, Eli, Gina

    // arrayOf Creates Mutable Array
    var array = arrayOf(1, 2, 3)
    println(array.joinToString()) // > 1, 2, 3
    array += 4
    println(array.joinToString()) // > 1, 2, 3, 4

    // Removing Elements From Mutable List
    println( players )
    val wasPlayerRemoved = players.remove("Gina")
    println("It is $wasPlayerRemoved removed")
    println( players )

    val removedPlayer = players.removeAt(2)
    println("$removedPlayer was removed") 
    println( players )

    // Updating Elements In Mutable List
    players[4] = "Franklin"
    println( players )

    players[3] = "Anna"
    println( players )

    players.sort() // Will Sort In Ascending Order
    println( players )

    // Updating Element In Mutable Array
    val arrayOfInts = arrayOf(1, 2, 3)
    println(arrayOfInts.joinToString()) // > 4, 2, 3    
    arrayOfInts[0] = 4
    println(arrayOfInts.joinToString()) // > 4, 2, 3
}

fun playWithIteratingOverCollections() {

    // Iterating Through A List
    val scores = listOf(2, 2, 8, 6, 1)
    for (score in scores) {
        println(score)
    }

    // Creating Mutable List Of 5 Elements Of String Type
    val players = mutableListOf("Bob", "Alice", "Cindy", "Dan", "Zodiac", "Ramya")

    for (player in players) {
        println(player)
    }
    // Output Will Be
    // Bob
    // Alice
    // Cindy
    // Dan
    // Zodiac
    // Ramya

    for ((index, player) in players.withIndex()) {
        println("${index + 1}. $player")
    }
    // Output Will Be
    // 1. Bob
    // 2. Alice
    // 3. Cindy
    // 4. Dan
    // 5. Zodiac
    // 6. Ramya

    fun sumOfElements(list: List<Int>): Int {
        var sum = 0
        for (number in list) {
            sum += number
        }
        return sum
    }

    println( sumOfElements(scores) ) // > 19
}



// _____________________________________________________


fun playWithMainFunctionArguments( arguments: Array<String> ) { 
    for (argument in arguments) {
        println(argument)
    }
}

// java -jar arrayslists.jar
// Function : playWithMainFunctionArguments

// java -jar arrayslists.jar Ding Dong
// Function : playWithMainFunctionArguments
// Ding
// Dong 

// java -jar arrayslists.jar Ding Dong Ting Tong
// Function : playWithMainFunctionArguments
// Ding
// Dong 
// Ting
// Tong

// java -jar arrayslists.jar Ding Dong Ting Tong 10000 20000
// Function : playWithMainFunctionArguments
// Ding
// Dong 
// Ting
// Tong
// 10000
// 20000

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________

// fun main() {

fun main( arguments: Array<String> ) {

	println("\nFunction : playWithArrays")
	playWithArrays()

	println("\nFunction : playWithArraysAgain")
	playWithArraysAgain()

	println("\nFunction : playWithIteratingOverCollections")
    playWithIteratingOverCollections()

	println("\nFunction : playWithMainFunctionArguments")
    playWithMainFunctionArguments( arguments )

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
