

package learnKotlin;

fun main() {
	println("Hello World!!!")
}

