khoj@Universe:~/Documents/KotlinCode$ kotlin
Welcome to Kotlin version 1.6.0 (JRE 11.0.11+9-LTS-194)
Type :help for help, :quit for quit
>>> 
>>> val coordinates: Pair<Int, Int> = Pair(2, 3)
>>> 
>>> println(coordinates)
(2, 3)
>>> 
>>> val coordinatesInferred = Pair(2, 3)
>>> 
>>> println(coordinatesInferred)
(2, 3)
>>> 
>>> val coordinatesWithTo = 2 to 3
>>> 
>>> println(coordinatesWithTo)
(2, 3)
>>> 
>>>     val x1 = coordinates.first
>>>     val y1 = coordinates.second
>>> 
>>> x1
res16: kotlin.Int = 2
>>> y1
res17: kotlin.Int = 3
>>> 
>>> coordinates
res19: kotlin.Pair<kotlin.Int, kotlin.Int> = (2, 3)
>>> coordinatesInferred
res20: kotlin.Pair<kotlin.Int, kotlin.Int> = (2, 3)
>>> coordinatesWithTo
res21: kotlin.Pair<kotlin.Int, kotlin.Int> = (2, 3)
>>> 
>>>     val x2 = coordinatesWithTo.first
>>>     val y2 = coordinatesWithTo.second
>>> 
>>> x2
res26: kotlin.Int = 2
>>> y2
res27: kotlin.Int = 3
>>> 
>>> val (x3, y3) = coordinates
>>> 
>>> x3
res31: kotlin.Int = 2
>>> y3
res32: kotlin.Int = 3
>>> 
>>> coordinates.first
res34: kotlin.Int = 2
>>> coordinates.secobd

error: unresolved reference: secobd
coordinates.secobd
            ^

>>> 
>>> coordinates.second
res37: kotlin.Int = 3
>>> 
>>> val coordinatesDoubles = Pair(2.22, 3.30)
>>> 
>>> coordinatesDoubles
res41: kotlin.Pair<kotlin.Double, kotlin.Double> = (2.22, 3.3)
>>> 
>>> coordinatesDoubles.first
res43: kotlin.Double = 2.22
>>> coordinatesDoubles.second
res44: kotlin.Double = 3.3
>>> 
>>>     val coordinatesMixed = Pair(2.22, 33)
>>> 
>>> coordinatesMixed
res48: kotlin.Pair<kotlin.Double, kotlin.Int> = (2.22, 33)
>>> 
>>> coordinatesMixed.first
res50: kotlin.Double = 2.22
>>> 
>>> coordinatesMixed.second
res52: kotlin.Int = 33
>>> 
>>> val coordinates3D = Triple(2, 3, 1)
>>> 
>>> coordinates3D.first
res56: kotlin.Int = 2
>>> coordinates3D.second
res57: kotlin.Int = 3
>>> coordinates3D.third
res58: kotlin.Int = 1
>>> 
>>> coordinates3D
res60: kotlin.Triple<kotlin.Int, kotlin.Int, kotlin.Int> = (2, 3, 1)
>>> 
>>> val (x4, y4, z4) = coordinates3D
>>> 
>>> x4
res64: kotlin.Int = 2
>>> y4
res65: kotlin.Int = 3
>>> z4
res66: kotlin.Int = 1
>>> 
>>> val (x5, y5, _) = coordinates3D
>>> 
>>> x5
res70: kotlin.Int = 2
>>> y5
res71: kotlin.Int = 3
>>> 
>>> _
error: names _, __, ___, ... can be used only in back-ticks (`_`, `__`, `___`, ...)
_
^

>>> val (x5, y5) = coordinates3D
>>> 
>>> xy
error: unresolved reference: xy
xy
^

>>> y5
res77: kotlin.Int = 3
>>> x5
res78: kotlin.Int = 2
>>> y5
res79: kotlin.Int = 3
>>> 
>>> 
>>>     val (x6, _, y6) = coordinates3D
>>> 
>>> x6
res84: kotlin.Int = 2
>>> y6
res85: kotlin.Int = 1
>>> 
>>> 


