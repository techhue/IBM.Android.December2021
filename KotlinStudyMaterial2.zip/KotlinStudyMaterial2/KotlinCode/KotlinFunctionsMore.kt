
/* Commands For Compiling And Running Code

kotlinc KotlinFunctionsMore.kt -include-runtime -d functionsMore.jar
java -jar functionsMore.jar

*/

package learnKotlin

// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Kotlin Collections Are Actually Internally Java Collections
fun playWithCollectionsInKotlin() {

	val hashSet = hashSetOf(10, 70, 100)
	val list = listOf(10, 20, 30, 40, 50)
	var arrayList = arrayListOf(10, 70, 900)
	val map = hashMapOf(1 to "One", 7 to "Seven", 10 to "Ten")
	
	println(hashSet)
	println(hashSet.javaClass)

	println(list)
	println(list.javaClass)

	println(arrayList)
	println(arrayList.javaClass)

	println(map)
	println(map.javaClass)

	val strings = listOf("First", "Second", "Third", "Five")
	println(strings)
	println(strings.last())
	println(strings.javaClass)

	val numbers = setOf(10, 20, 30, 40, 10)
	println(numbers)
	println( numbers.maxOrNull() )
	println( numbers.javaClass )
}


// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Created Human Class/Type with Three Instance Properties
//		firstName, lastName and fullName Are Instance Properties Are Values i.e. Immutable
class Human(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"

	// Instance Member Function
	fun doMagic() = println("Human Doing Magic...")

	// Instance Member Function
	fun doSinging() {
		println("Human Doing Singing...")
	} 
}

// Extension Function On Type Human
fun Human.doSomething() {
	println("doSomething Extension Function On Type Human")
}

// Extension Function On Type Human
fun Human.doDance() {
	println("doDance Extension Function On Type Human")
}

fun playWithHuman() {
	// Created human Object Of Human Type
	val human = Human("Alice", "Carols")

	// Accessing Properties i.e. Properties Getters Getting Called
	println(human.firstName) 
	println(human.lastName)
	println(human.fullName)

	// Invoking Instance Member Function
	human.doMagic()
	human.doSinging()

	// Invoking Extension Functions Like Instance Member Function
	human.doSomething()
	human.doDance()
}

// _______________________________________________


// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


// Function To Get Last Character Of The String
//		It Takes One Argument of String Type and Return Last Character of Char Type
fun lastCharacter( string: String ) : Char {
	return string.get( string.length - 1 )
}

// Using Extension Function Adding Functionlity To Existing String Type
fun String.lastCharacterExtension( ) : Char {
	return this.get( this.length - 1 )
}

fun playWithLastCharacter() {
	var greeting = "Hello World!"
	println( lastCharacter( greeting ))
	
	// Invoking Extension Function Like Member Function Of String Type
	println( greeting.lastCharacterExtension() )

	greeting = "Life is Awesome"
	println( lastCharacter( greeting ))

	// Invoking Extension Function Like Member Function Of String Type
	println( greeting.lastCharacterExtension() )
}


// _______________________________________________

// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Generic Function
//		<T> Means Here T Is Type Placeholder

fun <T> jointToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
): String {

	var result = StringBuilder( prefix )

	for ( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append(separator)

		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}


fun playWithJoinToStringFunction() {
	val list = listOf( 10, 20, 30, 40, 90 )
	println ( jointToString( list, " ; ", " ( ", " ) " ))
	println ( jointToString( list, " : ", " [ ", " ] " ))

	val names = listOf( "Alice", "Macmillan", "Gabbar", "Sachin", "Ramya" )
	println ( jointToString( names, " ; ", " ( ", " ) " ))
	println ( jointToString( names, " : ", " [ ", " ] " ))
	println ( jointToString( names, " : ", " <> ", " <> " ))
	println ( jointToString( names, " ### ", " >>>>> ", " <<<<< " ))
}

// _______________________________________________
// _______________________________________________
// _______________________________________________
// _______________________________________________
// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithCollectionsInKotlin")
	playWithCollectionsInKotlin()

	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringFunction")
	playWithJoinToStringFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

