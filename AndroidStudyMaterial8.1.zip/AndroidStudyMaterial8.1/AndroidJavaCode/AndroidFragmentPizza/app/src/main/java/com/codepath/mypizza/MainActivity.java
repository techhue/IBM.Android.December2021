package com.codepath.mypizza;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.codepath.mypizza.fragments.PizzaDetailFragment;
import com.codepath.mypizza.fragments.PizzaMenuFragment;

public class MainActivity extends AppCompatActivity  implements
        PizzaMenuFragment.OnItemSelectedListener {
  private final String TAG = "MainActivity";
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.d(TAG, "IBMCode Called onCreate");

    int deviceOrientation = getResources().getConfiguration().orientation;
    Log.d(TAG, "IBMCode Orientation : " + deviceOrientation);

    // R.layout.activity_main
    //    Will Load Different activity_main.xml File Based On Phone Orientation
    //    If Orientation Is Portrait Mode :
    //      Will Point To activity_main.xml File In res/layout Directory
    //    If OrientationIs Landscape Mode :
    //      Will Point To activity_main.xml File In res/layout-land Directory
    setContentView(R.layout.activity_main);

    // When Apps Runs First Type
    // saveInstanceState Will Be mull
    // LANDSCAPE OR PORTRAIT MODE
    if (savedInstanceState == null) {
      // Add Fragment to FrameLayout (flContainer), using FragmentManager
      FragmentManager fragmentManager = getSupportFragmentManager();
      FragmentTransaction transaction = fragmentManager.beginTransaction();

      Log.d(TAG, "IBMCode Adding PizzaMenuFragment");

      // Instance of first fragment
      PizzaMenuFragment pizzaMenuFragment = new PizzaMenuFragment();
      transaction.add(R.id.flContainer1, pizzaMenuFragment);                                // add    Fragment
      transaction.commit();                                                            // commit FragmentTransaction
    }

    if( deviceOrientation == Configuration.ORIENTATION_LANDSCAPE ){
      Bundle args = new Bundle();
      args.putInt("position", 0);

      Log.d(TAG, "IBMCode Adding PizzaDetailFragment");
      PizzaDetailFragment pizzaDetailFragment = new PizzaDetailFragment();
      // (1) Communicate with Fragment using Bundle
      pizzaDetailFragment.setArguments(args);

      FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();// begin  FragmentTransaction
      transaction.add(R.id.flContainer2, pizzaDetailFragment);                               // add    Fragment
      transaction.commit();                                                            // commit FragmentTransaction
    }
  }

  @Override
  public void onPizzaItemSelected(int position) {
    Log.d(TAG, "IBMCode Called onPizzaItemSelected With Position: " + position );

    Toast toastMessage = Toast.makeText(this,
            "IBMCode Fragment A Position : " + position, Toast.LENGTH_LONG);
    toastMessage.show();

    // Load Pizza Detail Fragment
    PizzaDetailFragment pizzaDetailFragment = new PizzaDetailFragment();

    Bundle args = new Bundle();
    args.putInt("position", position);
  // (1) Communicate with Fragment using Bundle
    pizzaDetailFragment.setArguments(args);

    int deviceOrientation = getResources().getConfiguration().orientation;

    Log.d(TAG, "IBMCode Replacing PizzaDetailFragment");
    if( deviceOrientation == Configuration.ORIENTATION_LANDSCAPE ) {
      getSupportFragmentManager()
          .beginTransaction()
          .replace(R.id.flContainer2, pizzaDetailFragment) // replace flContainer
          //.addToBackStack(null)
          .commit();
    } else { // PORTRAIT Orientation
      getSupportFragmentManager()
          .beginTransaction()
          .replace(R.id.flContainer1, pizzaDetailFragment) // replace flContainer
          .addToBackStack(null)
          .commit();
    }
  }
}
