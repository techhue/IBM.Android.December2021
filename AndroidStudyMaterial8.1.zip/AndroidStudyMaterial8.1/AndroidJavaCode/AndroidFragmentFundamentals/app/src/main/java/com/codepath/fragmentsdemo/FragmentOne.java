package com.codepath.fragmentsdemo;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;

public class FragmentOne extends Fragment {
    private final String TAG = "FragmentOne";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "IBMCode Called onCreateView");
        //  Inflate Will Create Views and View Tree/Hierarchy
        //      Will Create Views and View Tree/Hierarchy
        return inflater.inflate(R.layout.fragment_one, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "IBMCode Called onViewCreated");

        Button myButton = (Button) view.findViewById(R.id.submitButton);
        final EditText enteredEditText = (EditText) view.findViewById(R.id.enterEditText);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textEntered = enteredEditText.getText().toString();

                Toast messageToast = Toast.makeText(v.getContext(),
                        "Text Entered: " + textEntered, Toast.LENGTH_SHORT);
                messageToast.show();

                Log.d(TAG, "Text Typed : " + textEntered );
            }
        });
    }
}
