package com.techhue.layouts;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class LinearLayoutActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("LinearLayoutActivity", "Function Called : onCreate");

        setContentView(R.layout.linear_layout);
    }

    // Called at the end of the active lifetime.
    @Override
    public void onPause() {
        super.onPause();
        Log.d("LinearLayoutActivity", "Function Called : onPause");
    }

    // Called at the end of the visible lifetime.
    @Override
    public void onStop() {
        super.onStop();
        Log.d("LinearLayoutActivity", "Function Called : onStop");
    }

    // Sometimes called at the end of the full lifetime.
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("LinearLayoutActivity", "Function Called : onDestroy");
    }

}