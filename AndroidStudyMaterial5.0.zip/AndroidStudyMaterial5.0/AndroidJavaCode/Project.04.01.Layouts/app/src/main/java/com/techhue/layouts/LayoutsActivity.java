package com.techhue.layouts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class LayoutsActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("LayoutsActivity", "Function Called : onCreate");

        // Create UI Nodes/Objects e.g. Buttons, TextView etc..
        // Create View Hierarchy i.e. View Tree
        // Initialise UI
        // Set The ContentView To Initialised UI
        // It Will Connect View Hierarchy or View Tree Declared in main.xml
        //      with ContentView Node
        setContentView(R.layout.main); 

        // findViewById Will Search View In View Hierarchy i.e. View Tree
        Button linearButton = (Button) findViewById(R.id.linearButton);
        Button relativeButton = (Button) findViewById(R.id.relativeButton);
        Button gridButton = (Button) findViewById(R.id.gridbutton);

//        public interface OnClickListener {
//            void onClick(View v);
//        }

        linearButton.setOnClickListener( new OnClickListener() {
            public void onClick(View v) {
                // Creating Intent Object
                // Intent is Message
                //      From    : LayoutActivity 
                //      To      : LinearLayoutActivity
                // startActivity Method Will Send Intent
                Intent intent = new Intent(LayoutsActivity.this,
                        LinearLayoutActivity.class);
                startActivity(intent);
            }
        });

        /* // Java Compiler Will Generate Following Code
           // For Above Anonymous Class
            class TemporaryClass extend onClickLister {
                public void onClick(View v) {
                    startActivity(new Intent(LayoutsActivity.this,
                         LinearLayoutActivity.class));
                }
            }
            TemporaryClass temporaryObject = new TemporaryClass();
        */

        relativeButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Creating Intent Object
                // Intent is Message
                //      From    : LayoutActivity
                //      To      : RelativeLayoutActivity
                // startActivity Method Will Send Intent
                Intent intent = new Intent(LayoutsActivity.this,
                        RelativeLayoutActivity.class)
                startActivity(intent);
            }
        });

        gridButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Creating Intent Object
                // Intent is Message
                //      From    : LayoutActivity
                //      To      : GridLayoutActivity
                // startActivity Method Will Send Intent
                Intent intent = new Intent(LayoutsActivity.this,
                        GridLayoutActivity.class)
                startActivity(intent);
            }
        });
    }
    // Called at the end of the active lifetime.
    @Override
    public void onPause() {
        super.onPause();
        Log.d("LayoutsActivity", "Function Called :onPause");
    }

    // Called at the end of the visible lifetime.
    @Override
    public void onStop() {
        super.onStop();
        Log.d("LayoutsActivity", "Function Called :onStop");
    }

    // Sometimes called at the end of the full lifetime.
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("LayoutsActivity", "Function Called :onDestroy");
    }
}