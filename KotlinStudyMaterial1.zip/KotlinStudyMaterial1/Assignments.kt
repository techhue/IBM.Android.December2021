
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial0
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   `-- KotlinBasicsExperiment.kt

	A1.2 Kotlin Study Notes [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A1.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

DAY 02
____________________________________________________________


	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial1
		    |-- KotlinCode
		        |-- Hello.kt
		        |-- KotlinBasics.kt
		        |-- KotlinBasicsExperiment.kt
		        `-- KotlinFunctions.kt

	A2.2 Kotlin Study Notes REVISE IT [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.4 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.5 Study Java And Experiment [ MUST ]
		Java The Complete Reference, 11th Edition
		Chapter 02 : An Overview Of Java
		Chapter 03 : Data Types, Variables And Arrays


DAY 03
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
