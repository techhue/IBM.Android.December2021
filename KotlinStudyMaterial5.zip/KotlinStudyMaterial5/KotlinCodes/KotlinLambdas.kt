
/*
kotlinc KotlinLambdas.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar
*/

package learnKotlin

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function Type : (Int, Int) -> Int
fun addition(a: Int, b: Int) : Int { return a + b }

// Function Type : (Int, Int) -> Int
fun substraction(a: Int, b: Int) : Int { return a - b }

// Function Type : (Int, Int) -> Int
fun multiplication(a: Int, b: Int) : Int { return a * b }

// calculator Takes Three Arguments
//		First Two Arguments Are Of Int Type
//		Last Argument Is Of Function Type 
//			Which Takes Two Int Arguments And Return Int
fun calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithCalculator() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	// Passing Function To  Function
	// Passing addition Function To calculator Function
	result = calculator(xx, yy, ::addition)
	println("Result : $result")

	// Passing substraction Function To calculator Function
	result = calculator(xx, yy, ::substraction)
	println("Result : $result")

	// Passing multiplication Function To calculator Function
	result = calculator(xx, yy, ::multiplication)
	println("Result : $result")

}


// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function Type : (Int, Int) -> Int
fun addition1(a: Int, b: Int) = a + b 

// Function Type : (Int, Int) -> Int
fun substraction1(a: Int, b: Int) = a - b 

// Function Type : (Int, Int) -> Int
fun multiplication1(a: Int, b: Int) = a * b 

fun playWithCalculatorAgain() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int

	// Passing Function To  Function
	// Passing addition Function To calculator Function
	result = calculator(xx, yy, ::addition1)
	println("Result : $result")

	// Passing substraction Function To calculator Function
	result = calculator(xx, yy, ::substraction1)
	println("Result : $result")

	// Passing multiplication Function To calculator Function
	result = calculator(xx, yy, ::multiplication1)
	println("Result : $result")
}



// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function Type : (Int, Int) -> Int
fun addition2(a: Int, b: Int) = a + b 

// Function Type : (Int, Int) -> Int
fun substraction2(a: Int, b: Int) = a - b 

fun playWithCalculatorOnceAgain() {
	val xx: Int = 100
	val yy: Int = 200
	var result: Int
	
	//fun addition1(a: Int, b: Int) = a + b
	// Anonmous Function i.e. Functions Without Name
	// Lambda Expression		// Arguments Followed By(->) Is Body
	// 		Have Function Type (Int, Int) -> Int
	val additionLambda : (Int, Int) -> Int 		 = { a: Int, b: Int ->  a + b }
	val substractionLambda : (Int, Int) -> Int	 = { a: Int, b: Int ->  a - b }
	
	// Inferred Type Will Be (Int, Int) -> Int
	val multiplicationLambda = { a: Int, b: Int ->  a * b }

	result = calculator(xx, yy, additionLambda)
	println("Result : $result")	

	result = calculator(xx, yy, substractionLambda)
	println("Result : $result")	

	result = calculator(xx, yy, multiplicationLambda)
	println("Result : $result")	
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithLambdas() {
	// Creating Variable multiplyLambda Of Function Type (Int, Int) -> Int
    var multiplyLambda: (Int, Int) -> Int
    var lambdaResult: Int

    val multiplyLambda0 = { a: Int, b: Int -> a * b }
    lambdaResult = multiplyLambda0(4, 2) // 8
    println(lambdaResult)

    // Defining Lambda Expression Which Takes 2 Int Arguments And Return Int
    multiplyLambda = { a: Int, b: Int -> Int
        a * b
    }

    // Invoking Lambda Expression multiplyLambda
    lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)


    // Defining Lambda Expression Which Takes 2 Int Arguments And Return Int
    //		Arguments and Return Types Can Be Skipped
    //		Implicitly Deduced/Inferrenced
    multiplyLambda = { a, b ->
        a * b
    }

    // Invoking Lambda Expression multiplyLambda
	lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)
    
    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Implicitly Inferred Type Of doubleLambda Will Be (Int) -> Int
    val doubleLambda = { a: Int -> 2 * a }
	lambdaResult = doubleLambda(4) 
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword
    val doubleLambdaAgain: (Int) -> Int = { it * 2 }
	lambdaResult = doubleLambdaAgain(4) // 8
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword 
    val square: (Int) -> Int = { number: Int -> number * number }
	lambdaResult = square(4) // 8
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
  	//	Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword 
    val squareAgain: (Int) -> Int = { it * it }
	lambdaResult = squareAgain(4) // 8
    println(lambdaResult)
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun playWithLambdasAgain() {
    var resultReturned : Int 

    // Local Function
    // Defining Function Inside A Function
    fun operateOnNumbers(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
        val result = operation(a, b) // Invoking Lambda And Passing Parameters
        return result
    }

    // Defining A Lamba Expression
    //		Having Function Type : (Int, Int) -> Int
    val addLambda = { a: Int, b: Int -> a + b }
    resultReturned = operateOnNumbers(4, 2, operation = addLambda)
    println(resultReturned)

    // Creating Function Of Type (Int, Int) -> Int
    fun addFunction(a: Int, b: Int) = a + b

    //							Passing Last Argument As Function Reference
    resultReturned = operateOnNumbers(4, 2, operation = ::addFunction)
    println(resultReturned)

    resultReturned = operateOnNumbers( 4, 2, { a: Int, b: Int -> a + b } )
    println(resultReturned)

    // Another Way To Structure Above 2 Lines Of Code
    resultReturned = operateOnNumbers( 4, 2,
        operation = { a: Int, b: Int ->
            a + b
        }
    )
    println(resultReturned)

	// Skipping Arguments Type In Lamdba Expression
	//		It Will Automatically Inference/Deduce From operateOnNumbers Definition
    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } )
    println(resultReturned)

   
    // Operator :: Will Get Reference
    //		Int::plus Reference To plus Function Defined For Int Type

    resultReturned = operateOnNumbers(4, 2, operation = Int::plus)
    println(resultReturned)

    // Following Lambdas Definitions Are Equivalent
    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } ) 
    println(resultReturned)
    
    // Trailing Lambda
    // 		Lambda Is Last Argument In Function
    // 		Than It Can Be Written Outide of Paranthesis ()
    resultReturned = operateOnNumbers(4, 2) { a, b -> a + b }
    println(resultReturned)
    
    // Restructured Above Code Can Be Written As Follows With Trailing Lambda
    resultReturned = operateOnNumbers(4, 2) { 
    	a, b -> a + b 
    }
    println(resultReturned)
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!


fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithCalculatorAgain")
	playWithCalculatorAgain()

	println("\nFunction :playWithCalculatorOnceAgain")
	playWithCalculatorOnceAgain()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdasAgain")
	playWithLambdasAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

