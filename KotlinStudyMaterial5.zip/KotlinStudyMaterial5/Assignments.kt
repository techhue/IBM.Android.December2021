
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial0
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   `-- KotlinBasicsExperiment.kt

	A1.2 Kotlin Study Notes [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A1.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

DAY 02
____________________________________________________________


	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial1
		    |-- KotlinCode
		        |-- Hello.kt
		        |-- KotlinBasics.kt
		        |-- KotlinBasicsExperiment.kt
		        `-- KotlinFunctions.kt

	A2.2 Kotlin Study Notes REVISE IT [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.4 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.5 Study Java And Experiment [ MUST ]
		Java The Complete Reference, 11th Edition
		Chapter 02 : An Overview Of Java
		Chapter 03 : Data Types, Variables And Arrays


DAY 03
____________________________________________________________


	A3.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial2
	    |-- KotlinCode
	    |   |-- Hello.kt
	    |   |-- KotlinBasics.kt
	    |   |-- KotlinBasicsExperiment.kt
	    |   |-- KotlinBasicsMore.kt
	    |   |-- KotlinFunctions.kt
	    |   `-- KotlinFunctionsMore.kt


	A3.2 Read And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial2
		    |-- KotlinNotes
		        |-- KotlinNotes7.Shared.pdf
		        |-- KotlinNotes8.Shared.pdf
		        `-- KotlinNotes9.Shared.pdf

	A3.3 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial2
		    |-- KotlinNotes
		        |-- KotlinNotes7.Shared.pdf
		        |-- KotlinNotes8.Shared.pdf
		        `-- KotlinNotes9.Shared.pdf

	A3.4 Study Java And Experiment [ MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 04 : Operators


	A3.5 Kotlin Study Notes REVISE IT

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf
    

DAY 04
____________________________________________________________


	A4.1 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial3
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   |-- KotlinBasicsExperiment.kt
		    |   |-- KotlinBasicsMore.kt
		    |   |-- KotlinFunctions.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinArraysLists.kt
		    |   |-- KotlinMapsSets.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt
		    |   |-- KotlinClasses.kt

	A4.2 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf
		        |-- KotlinNotes11.Shared.pdf

		        |-- KotlinNotes12.Shared.pdf

		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf


	A4.3 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf

		        |-- KotlinNotes11.Shared.pdf

		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf

	A4.4 Study Java And Experiment [ MUST MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 05 : Control Statements
		Chapter 19 : java.util Part 1: The Collections Framework


	A4.5 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial0
		    	|-- KotlinNotes
		        	|-- KotlinNotes2-6.Shared.pdf
			|-- KotlinStudyMaterial2
			    |-- KotlinNotes
			        |-- KotlinNotes7.Shared.pdf
			        |-- KotlinNotes8.Shared.pdf
			        `-- KotlinNotes9.Shared.pdf

		JAVA CHAPTERS STUDY AND CODE PRACTICE REVISION

			Java The Complete Reference, 11th Edition
			Chapter 02 : An Overview Of Java
			Chapter 03 : Data Types, Variables And Arrays
			Chapter 04 : Operators

____________________________________________________________

DAY 05
____________________________________________________________


	A5.1 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial3
		    |-- KotlinCode
		    |   |-- KotlinFunctions.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt
		    |   |-- KotlinClasses.kt

	A5.2 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf


	A5.3 Study Java And Experiment [ MUST MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 19 : java.util Part 1: The Collections Framework


	A5.4 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial2
			    |-- KotlinNotes
			        |-- KotlinNotes02-06.Shared.pdf
			        |-- KotlinNotes07.Shared.pdf
			        |-- KotlinNotes08.Shared.pdf
			        |-- KotlinNotes09.Shared.pdf
			        |-- KotlinNotes10.Shared.pdf

			|-- KotlinStudyMaterial3
			    |-- KotlinCode
			    |   |-- Hello.kt
			    |   |-- KotlinBasics.kt
			    |   |-- KotlinBasicsExperiment.kt
			    |   |-- KotlinBasicsMore.kt
			    |   |-- KotlinFunctions.kt
			    |   |-- KotlinFunctionsMore.kt
			    |   |-- KotlinArraysLists.kt
			    |   |-- KotlinMapsSets.kt

____________________________________________________________

DAY 06
____________________________________________________________


	A6.1 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial5
		    |-- KotlinNotes
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A6.2 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial5
		    |-- KotlinCodes
		    |   |-- KotlinClasses.kt
		    |   |-- KotlinClassesAndInterfaces.kt
		    |   |-- KotlinClassesMore.kt

		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinLambdas.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt


	A6.3 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial5
			    |-- KotlinNotes
			        |-- KotlinNotes11.Shared.pdf
			        |-- KotlinNotes12.Shared.pdf
			        |-- KotlinNotes13.Shared.pdf
			        `-- KotlinNotes14.Shared.pdf

			|-- KotlinStudyMaterial5
			    |-- KotlinCodes
			    |   |-- Hello.kt
			    |   |-- KotlinArraysLists.kt
			    |   |-- KotlinBasics.kt
			    |   |-- KotlinBasicsExperiment.kt
			    |   |-- KotlinBasicsMore.kt
			    |   |-- KotlinFunctions.kt
			    |   |-- KotlinFunctionsMore.kt
			    |   |-- KotlinLambdas.kt
			    |   |-- KotlinMapsSets.kt
			    |   |-- KotlinNullability.kt
			    |   |-- KotlinNullabilityMore.kt


	A6.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
		
		Chapter 19 : java.util Part 1: The Collections Framework

____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________

