package com.techhue.intents;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.AdapterView;

import java.util.ArrayList;

public class SelectHorseActivity extends Activity
{
    private String selectedHorse = "No Horse";
    protected static final String TAG = "SelectHorseActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "IBMCode Called : onCreate");

        Intent intentFromMyActivity = getIntent();
        String messageFromMyActivity = intentFromMyActivity.getStringExtra("ShowHorses");
        Log.d(TAG, "IBMCode Message Received : " + messageFromMyActivity);

        setContentView(R.layout.selector_layout);

        final ListView horsesListView = (ListView) findViewById(R.id.listView1);
        int horseLayoutFile = android.R.layout.simple_list_item_1;
        // Data Source
        ArrayList<String> horses = new ArrayList<String>();
        // Controller or Middle Man
        // Registering Layout and Data Source With Adapter
        ArrayAdapter<String> horsesAdapter;
        horsesAdapter =
                new ArrayAdapter<String>(this, horseLayoutFile, horses);
        // Registering Adapter With ListView
        horsesListView.setAdapter(horsesAdapter);

        // Adding Data To Data Source
        horses.add("Black Forest Horse ");
        horses.add("Arabian Horse");
        horses.add("Baluchi Horse");
        horses.add("Curly Horse");
        horses.add("Heck horse");
        horses.add("Indian Country Horse");
        horses.add("Karachai Horse");
        horses.add("American Horse");
        horses.add("Beliam Horse");
        horses.add("Afgani Horse");
        horses.add("Malai Horse");
        horses.add("Asian Horse");
        horses.add("English Horse");
        horses.add("African Horse");
        horses.add("Icelandic Horse");

        horsesListView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                selectedHorse = (String) horsesListView.getItemAtPosition(position);
//                Toast.makeText(this, "Selected Horse : " + selectedHorse, Toast.LENGTH_LONG).show();
                Toast messageToast = Toast.makeText(SelectHorseActivity.this,
                        "IBMCode Selected Horse : " + selectedHorse, Toast.LENGTH_LONG);
                Log.d(TAG, "\nIBMCode Selected Horse : " + selectedHorse);

                messageToast.show();
            }
        });

        /**
         * Listing 5-5: Returning a result from a sub-Activity
         */
        Button okButton = (Button) findViewById(R.id.ok_button);

        okButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d(TAG, "IBMCode Called : okButton onClick");
                // Communication Message/Intent From B To A
                Intent returnResultIntent = new Intent();
                // Added Payload To Message To Be Sent From B To A
                returnResultIntent.putExtra("SelectedHorse", selectedHorse);
                // setResult Will Send Intent/Message From B To A
                //      i.e. It Will Send From SelectHorseActivity To MyActivity
                setResult(Activity.RESULT_OK, returnResultIntent);
                finish(); // WIll Kill SelectHorseActivity i.e. B Activity
            }
        });

        Button cancelButton = (Button) findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d(TAG, "IBMCode Called : cancelButton onClick");
                selectedHorse = "Discarding Horse Selection!";
                Intent returnIntent = new Intent();
                returnIntent.putExtra("SelectedHorse", selectedHorse);
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
            }
        });
    }
}