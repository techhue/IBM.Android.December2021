package com.techhue.intents;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SelectGunActivity extends Activity {
    private  static final String TAG = "SelectGunActivity";
    private String selectedGun = "NO Gun";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selector_layout);

        Intent intentFromMyActivity = getIntent();
        String messageFromMyActivity = intentFromMyActivity.getStringExtra("ShowGuns");
        Log.d(TAG, "IBMCode Message Received : " + messageFromMyActivity);

        final ListView gunsListView = (ListView) findViewById(R.id.listView1);
        int gunsLayoutFile = android.R.layout.simple_list_item_1;
        // Data Source
        ArrayList<String> guns = new ArrayList<String>();
        // Controller or Middle Man
        // Registering Layout and Data Source With Adapter
        ArrayAdapter<String> gunsAdapter;
        gunsAdapter =
                new ArrayAdapter<String>(this, gunsLayoutFile, guns);
        // Registering Adapter With ListView
        gunsListView.setAdapter(gunsAdapter);

        // Adding Data To Data Source
        guns.add("AK-47");
        guns.add("AK-74");
        guns.add("AK-105");
        guns.add("Daewoo K6");
        guns.add("Daewoo K11");
        guns.add("Insas Rifle");
        guns.add("Deer Gun");
        guns.add("Machine Gun");
        guns.add("American Rifle");
        guns.add("British Rifle");
        guns.add("Indian Rifle");
        guns.add("Chinese Rifle");
        guns.add("Fast Rifle");

        gunsListView.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedGun = (String) gunsListView.getItemAtPosition(position);
//                Toast.makeText(this, "Selected Horse : " + selectedHorse, Toast.LENGTH_LONG).show();
                Toast messageToast = Toast.makeText(SelectGunActivity.this,
                        "IBMCode Selected Gun : " + selectedGun, Toast.LENGTH_LONG);
                Log.d(TAG, "\nIBMCode Selected Gun : " + selectedGun);

                messageToast.show();
            }
        });

        Button okButton = (Button) findViewById(R.id.ok_button);

        okButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d(TAG, "IBMCode Called : okButton onClick");
                // Communication Message/Intent From B To A
                Intent returnResultIntent = new Intent();
                // Added Payload To Message To Be Sent From B To A
                returnResultIntent.putExtra("SelectedGun", selectedGun);
                // setResult Will Send Intent/Message From B To A
                //      i.e. It Will Send From SelectHorseActivity To MyActivity
                setResult(Activity.RESULT_OK, returnResultIntent);
                finish(); // WIll Kill SelectHorseActivity i.e. B Activity
            }
        });

        Button cancelButton = (Button) findViewById(R.id.cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d(TAG, "IBMCode Called : cancelButton onClick");
                selectedGun = "Discarding Horse Selection!";
                Intent returnIntent = new Intent();
                returnIntent.putExtra("SelectedGun", selectedGun);
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
            }
        });
    }
}