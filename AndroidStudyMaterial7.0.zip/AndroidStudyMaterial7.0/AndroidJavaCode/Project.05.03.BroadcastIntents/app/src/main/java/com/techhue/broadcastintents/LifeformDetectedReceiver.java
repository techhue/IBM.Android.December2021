package com.techhue.broadcastintents;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.util.Log;

/**
 * Listing 5-11: Implementing a Broadcast Receiver
 */
public class LifeformDetectedReceiver extends BroadcastReceiver {
    public final static String TAG = "LifeformDetectedReceiver";

    public final static String EXTRA_LIFEFORM_NAME
            = "EXTRA_LIFEFORM_NAME";
    public final static String EXTRA_LATITUDE = "EXTRA_LATITUDE";
    public final static String EXTRA_LONGITUDE = "EXTRA_LONGITUDE";

    public static final String
            ACTION_SAVE_DATA = "com.techhue.alien.action.ACTION_SAVE_DATA";

    public static final String
            ACTION_SANITISE = "com.techhue.alien.action.ACTION_SANITISE";

    public static final String
            NEW_LIFEFORM = "com.techhue.alien.action.NEW_LIFEFORM";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Get the Lifeform details from the intent.
        Log.d(TAG, "IBMCode Called onReceive");

        Uri data = intent.getData();

        String newLifeFormName = intent.getStringExtra(EXTRA_LIFEFORM_NAME);
        double lat = intent.getDoubleExtra(EXTRA_LATITUDE, 0);
        double lng = intent.getDoubleExtra(EXTRA_LONGITUDE, 0);

        Log.d(TAG, "IBMCode Received Data : " + newLifeFormName);

        // Your Own Logic

        // Checking Location On Map
        Location loc = new Location("gps");
        loc.setLatitude(lat);
        loc.setLongitude(lng);
        // Set Location Map : Logic To Written

        // Your Own Logic
        if (newLifeFormName.equals("Alien")) {
            Intent saveDataIntent = new Intent(ACTION_SAVE_DATA, data);
            saveDataIntent.putExtra(EXTRA_LATITUDE, lat);
            saveDataIntent.putExtra(EXTRA_LONGITUDE, lng);

            Log.d(TAG, "IBMCode Saving Data Service Starting... ");
            // context.startService(saveDataIntent);

        } else if (newLifeFormName.equals("Virus")) {
            Intent sanitiseIntent = new Intent(ACTION_SANITISE, data);
            sanitiseIntent.putExtra(EXTRA_LATITUDE, lat);
            sanitiseIntent.putExtra(EXTRA_LONGITUDE, lng);
            // context.startService(sanitiseIntent);

            Log.d(TAG, "IBMCode Sanitisation Service Starting... ");
        }
    }
}
