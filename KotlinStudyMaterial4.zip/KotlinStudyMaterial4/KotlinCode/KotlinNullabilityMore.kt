/*
kotlinc KotlinNullabilityMore.kt -include-runtime -d nullability.jar
java -jar nullability.jar
*/

package learnKotlin


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun playWithCollectionNullability() {
    // Nullability and Collection Types

	// Nullable List Can Store Int Type Data
	// Can't Store null Inside Collection
    var nullableList: List<Int>? = listOf(1, 2, 3, 4)
    println( nullableList?.get(0) )
    nullableList = null
    println(nullableList)

	// Nullable List Can Store Int Type Data
	// Can't Store null Inside Collection
    // var nullableList1: List<Int>? = listOf(1, 2, 3, 4, null, 5)
    // nullableList1 = null
    // println(nullableList1)

    // Non-Nullable List Can Store Int? Type Data 
    // i.e Can Store null Inside Collection
    var listOfNullables: List<Int?> = listOf(1, 2, null, 4)
    // listOfNullables = null // Error: Null can not be a value of a non-null type
    println(listOfNullables)

	// Nullable List Can Store Int? Type Data
    // i.e Can Store null Inside Collection
    var nullableListOfNullables: List<Int?>? = listOf(1, 2, null, 4)
    println( nullableListOfNullables?.get(0) )
    nullableListOfNullables = null
    println(nullableListOfNullables)
}




// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// Employee Class Having Two Properties
//		name Property Is of String Type And Non Nullable
//		manager Property Is of Employee Type And Nullable

class Employee(val name: String, val manager: Employee?)


fun getManagerName(employee: Employee) : String? {
	//  error: only safe (?.) or non-null asserted (!!.) 
	//  calls are allowed on a nullable receiver of type Employee?
	// return employee.manager.name 
	
 	// error: type mismatch: inferred type is String? but String was expected
	
	// If Any Part In Expression Become null Then Whole Expression Becomes null
	// You Cann't Return null From Function, If Return Type Is Non Nullable
	// 		Make Return Type Of Function Nullable, To Return null From Function 
	return employee.manager?.name 
}

fun plaWithEmployeeManager() {
	val ceo 		= Employee("Da Boss", null)
	val ashwaraya 	= Employee("Ashwaraya", ceo)

	println( getManagerName(ashwaraya) )
	println( getManagerName(ceo) )
}



// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// Address Class Have 4 Non Nullable Properties
class Address(
	val streetName: String,
	val zipCode: Int,
	val city: String,
	val country: String
)

// Conpany Class Have 2 Properties
//		name Is NON Nullable Property
//		address Is Nullable Property
class Company( val name: String, val address: Address? )

// Person Class Have 2 Properties
class Person( val name: String, val company: Company? )
//		name Is NON Nullable Property
//		company Is Nullable Property

fun getCountryNameOfPersonCompany(person: Person) : String  {
	// In RHS Expression, If Anything Becomes null 
	// Than Whole RHS Expression Will Becomes Of null Value 

	// error: type mismatch: inferred type is String? but String was expected
	// val country: String = person.company?.address?.country
	val country: String? = person.company?.address?.country

	return if (country != null) country else "Unknown"
}

fun playWithPersonCountry() {
	val alice = Person("Alice", null) 		// company is null
	println( getCountryNameOfPersonCompany(alice) )

	val bobCompany = Company("IBM", null) 	// Company's address is null
	val bob = Person("Bob", bobCompany)
	println( getCountryNameOfPersonCompany(bob) )

	val intelAddress = Address("Outer Ring Road", 560103, "Bangalore", "India")
	val rameshCompany = Company("Intel", intelAddress)
	val rammesh = Person("Bob", rameshCompany)
	println( getCountryNameOfPersonCompany(rammesh) )
}


// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {

	println("Function : playWithCollectionNullability")
	playWithCollectionNullability()
	
	println("Function : plaWithEmployeeManager")
	plaWithEmployeeManager()

	println("Function : playWithPersonCountry")
	playWithPersonCountry()
	
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
