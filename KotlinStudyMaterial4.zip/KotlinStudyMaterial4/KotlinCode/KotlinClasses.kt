
/*
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Defining Person Class With Three Properties firstName, lastName and fullName
//		All Three Properties Are Mutable

// Compiler Will Generate Following Things
// 1. Generate Memberwise Constructor Person(firstName, lastName)
// 2. Generate 3 Member Variables To Store Data
//		Corresponding To firstName, lastName, fullName Properties
// 3. Generate Getters and Setters
//		firstName and lastName Properties Both Getters and Setters Will Generated
//	    fullName Property Only Getter is Define


class Person(var firstName: String, var lastName: String) {
	var fullName: String = ""
		get() {  			// Custom Getter Function
			println("fullName Getter Called...")
			return "$firstName $lastName"
		}
		set(value) {  		// Custom Setter Function
			println("fullName Setter Called...")
			field = value
		}
}	

fun playWithPerson() {
	val alice = Person(firstName = "Alice", lastName = "Carols")
	println( alice.firstName )  	// alice.getFirstName()
	println( alice.lastName )   	// alice.getLastName()
	println( alice.fullName )		// alice.getFullName()

	alice.firstName = "Alisa"		// alice.setFirstName("Alisa")
	alice.lastName = "Carolina"		// alice.setLastName("Carolina")
	alice.fullName = "Alisa Carolina" // error: val cannot be reassigned

	println( alice.firstName )
	println( alice.lastName )
	println( alice.fullName )
}

// Function : playWithPerson
// Alice
// Carols
// fullName Getter Called...
// Alice Carols
// fullName Setter Called...
// Alisa
// Carolina
// fullName Getter Called...
// Alisa Carolina


// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________


fun main( ) {
	println("Function : playWithPerson")
	playWithPerson()
	
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")

}
