
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial0
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   `-- KotlinBasicsExperiment.kt

	A1.2 Kotlin Study Notes [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A1.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

DAY 02
____________________________________________________________


	A2.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial1
		    |-- KotlinCode
		        |-- Hello.kt
		        |-- KotlinBasics.kt
		        |-- KotlinBasicsExperiment.kt
		        `-- KotlinFunctions.kt

	A2.2 Kotlin Study Notes REVISE IT [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.4 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A2.5 Study Java And Experiment [ MUST ]
		Java The Complete Reference, 11th Edition
		Chapter 02 : An Overview Of Java
		Chapter 03 : Data Types, Variables And Arrays


DAY 03
____________________________________________________________


	A3.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Now

		|-- KotlinStudyMaterial2
	    |-- KotlinCode
	    |   |-- Hello.kt
	    |   |-- KotlinBasics.kt
	    |   |-- KotlinBasicsExperiment.kt
	    |   |-- KotlinBasicsMore.kt
	    |   |-- KotlinFunctions.kt
	    |   `-- KotlinFunctionsMore.kt


	A3.2 Read And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial2
		    |-- KotlinNotes
		        |-- KotlinNotes7.Shared.pdf
		        |-- KotlinNotes8.Shared.pdf
		        `-- KotlinNotes9.Shared.pdf

	A3.3 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial2
		    |-- KotlinNotes
		        |-- KotlinNotes7.Shared.pdf
		        |-- KotlinNotes8.Shared.pdf
		        `-- KotlinNotes9.Shared.pdf

	A3.4 Study Java And Experiment [ MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 04 : Operators


	A3.5 Kotlin Study Notes REVISE IT

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf
    

DAY 04
____________________________________________________________


	A4.1 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial3
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   |-- KotlinBasicsExperiment.kt
		    |   |-- KotlinBasicsMore.kt
		    |   |-- KotlinFunctions.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinArraysLists.kt
		    |   |-- KotlinMapsSets.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt
		    |   |-- KotlinClasses.kt

	A4.2 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf


	A4.3 Solve All Excercise And Challenges In Every Chapter [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf
cd		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf

	A4.4 Study Java And Experiment [ MUST MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 05 : Control Statements
		Chapter 19 : java.util Part 1: The Collections Framework


	A4.5 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial0
		    	|-- KotlinNotes
		        	|-- KotlinNotes2-6.Shared.pdf
			|-- KotlinStudyMaterial2
			    |-- KotlinNotes
			        |-- KotlinNotes7.Shared.pdf
			        |-- KotlinNotes8.Shared.pdf
			        `-- KotlinNotes9.Shared.pdf

		JAVA CHAPTERS STUDY AND CODE PRACTICE REVISION

			Java The Complete Reference, 11th Edition
			Chapter 02 : An Overview Of Java
			Chapter 03 : Data Types, Variables And Arrays
			Chapter 04 : Operators

____________________________________________________________

DAY 05
____________________________________________________________


	A5.1 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial3
		    |-- KotlinCode
		    |   |-- KotlinFunctions.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt
		    |   |-- KotlinClasses.kt

	A5.2 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial3
		    |-- KotlinNotes
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        `-- KotlinNotes14.Shared.pdf


	A5.3 Study Java And Experiment [ MUST MUST ]
		Java The Complete Reference, 11th Edition
		
		Chapter 19 : java.util Part 1: The Collections Framework


	A5.4 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial2
			    |-- KotlinNotes
			        |-- KotlinNotes02-06.Shared.pdf
			        |-- KotlinNotes07.Shared.pdf
			        |-- KotlinNotes08.Shared.pdf
			        |-- KotlinNotes09.Shared.pdf
			        |-- KotlinNotes10.Shared.pdf

			|-- KotlinStudyMaterial3
			    |-- KotlinCode
			    |   |-- Hello.kt
			    |   |-- KotlinBasics.kt
			    |   |-- KotlinBasicsExperiment.kt
			    |   |-- KotlinBasicsMore.kt
			    |   |-- KotlinFunctions.kt
			    |   |-- KotlinFunctionsMore.kt
			    |   |-- KotlinArraysLists.kt
			    |   |-- KotlinMapsSets.kt

____________________________________________________________

DAY 06
____________________________________________________________

	A6.1 Read And Experiment Code Examples [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial5
		    |-- KotlinNotes
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A6.2 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial5
		    |-- KotlinCodes
		    |   |-- KotlinClasses.kt
		    |   |-- KotlinClassesAndInterfaces.kt
		    |   |-- KotlinClassesMore.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinLambdas.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt


	A6.3 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial5
			    |-- KotlinNotes
			        |-- KotlinNotes11.Shared.pdf
			        |-- KotlinNotes12.Shared.pdf
			        |-- KotlinNotes13.Shared.pdf
			        `-- KotlinNotes14.Shared.pdf

			|-- KotlinStudyMaterial5
			    |-- KotlinCodes
			    |   |-- Hello.kt
			    |   |-- KotlinArraysLists.kt
			    |   |-- KotlinBasics.kt
			    |   |-- KotlinBasicsExperiment.kt
			    |   |-- KotlinBasicsMore.kt
			    |   |-- KotlinFunctions.kt
			    |   |-- KotlinFunctionsMore.kt
			    |   |-- KotlinLambdas.kt
			    |   |-- KotlinMapsSets.kt
			    |   |-- KotlinNullability.kt
			    |   |-- KotlinNullabilityMore.kt


	A6.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
		
		Chapter 19 : java.util Part 1: The Collections Framework


____________________________________________________________

DAY 07
____________________________________________________________

	A7.1 READ AND REVISE KOTLIN NOTES [ MUST MUST ] 

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        |-- KotlinNotes14.Shared.pdf
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A7.2 SOLVE ALL EXERCISES And CHALLENGES In FOLLOWING NOTES [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        |-- KotlinNotes14.Shared.pdf
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A7.3 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial6
		    |-- KotlinCodes
		    |   |-- KotlinClasses.kt
		    |   |-- KotlinClassesAndInterfaces.kt
		    |   |-- KotlinClassesMore.kt


	A7.4 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
		
			|-- KotlinStudyMaterial6
			    |-- KotlinCodes
			    |   |-- Hello.kt
			    |   |-- KotlinArraysLists.kt
			    |   |-- KotlinBasics.kt
			    |   |-- KotlinBasicsExperiment.kt
			    |   |-- KotlinBasicsMore.kt
			    |   |-- KotlinFunctions.kt
			    |   |-- KotlinFunctionsMore.kt
			    |   |-- KotlinLambdas.kt
			    |   |-- KotlinMapsSets.kt
			    |   |-- KotlinNullability.kt
			    |   |-- KotlinNullabilityMore.kt


____________________________________________________________

DAY 08
____________________________________________________________


	A8.1 SOLVE ALL EXERCISES And CHALLENGES In FOLLOWING NOTES [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A8.2 REVISE KOTLIN NOTES [ MUST MUST ] 

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf


	A8.3 READ KOTLIN NOTES [ MUST MUST ] 

		|-- KotlinStudyMaterial7
		    |-- KotlinNotes
		        |-- KotlinNotes18.Shared.pdf
		        |-- KotlinNotes20.Shared.pdf
		        |-- KotlinNotes22.Shared.pdf


	A8.4 Kotlin Code [ MUST MUST ]
		 Practice and Revise Kotlin Code Done Till Now
		
		|-- KotlinStudyMaterial7
		    |-- KotlinCode
		    |   |-- KotlinClasses.kt
		    |   |-- KotlinClassesMore.kt
		    |   |-- KotlinClassesAndInterfaces.kt
		    |   |-- KotlinClassesAndInterfacesMore.kt
		    |   |-- KotlinOperatorOverloading.kt
    		|   |-- KotlinDownloader.kt
		

	A8.5 REVISON ASSIGNMENT [ MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
	
		|-- KotlinStudyMaterial7
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- Kotlin
		    |   |-- KotlinArraysLists.kt
		    |   |-- KotlinBasics.kt
		    |   |-- KotlinBasicsExperiment.kt
		    |   |-- KotlinBasicsMore.kt
		    |   |-- KotlinClasses.kt
		    |   |-- KotlinClassesAndInterfaces.kt
		    |   |-- KotlinClassesAndInterfacesMore.kt
		    |   |-- KotlinClassesMore.kt
		    |   |-- KotlinDownloader.kt
		    |   |-- KotlinFunctions.kt
		    |   |-- KotlinFunctionsMore.kt
		    |   |-- KotlinLambdas.kt
		    |   |-- KotlinMapsSets.kt
		    |   |-- KotlinNullability.kt
		    |   |-- KotlinNullabilityMore.kt
		    |   |-- KotlinOperatorOverloading.kt

					
		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        |-- KotlinNotes14.Shared.pdf
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

____________________________________________________________

DAY 09
____________________________________________________________

	A9.0 : REVISE KOTLIN NOTES AND CODE EXAMPLES THROUGHLY

	A9.1 READ KOTLIN NOTES [ MUST MUST ] 

		|-- KotlinStudyMaterial7
		    |-- KotlinNotes
		        |-- KotlinNotes18.Shared.pdf
		        |-- KotlinNotes20.Shared.pdf
		        |-- KotlinNotes22.Shared.pdf

	A9.2 SOLVE ALL EXERCISES And CHALLENGES In FOLLOWING NOTES [ MUST MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        |-- KotlinNotes14.Shared.pdf
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf
		        |-- KotlinNotes18.Shared.pdf
		        |-- KotlinNotes20.Shared.pdf
		        |-- KotlinNotes22.Shared.pdf


	A9.3 REVISON ASSIGNMENT [ MUST MUST ]

		KOTLIN NOTES STUDY AND CODE PRACTICE
	
		|-- KotlinStudyMaterial8
		    |-- KotlinCode
			    |-- Hello.kt
			    |-- Kotlin
			    |-- KotlinArraysLists.kt
			    |-- KotlinBasics.kt
			    |-- KotlinBasicsExperiment.kt
			    |-- KotlinBasicsMore.kt
			    |-- KotlinClasses.kt
			    |-- KotlinClassesAndInterfaces.kt
			    |-- KotlinClassesAndInterfacesMore.kt
			    |-- KotlinClassesMore.kt
			    |-- KotlinDownloader.kt
			    |-- KotlinFunctions.kt
			    |-- KotlinFunctionsMore.kt
			    |-- KotlinLambdas.kt
			    |-- KotlinMapsSets.kt
			    |-- KotlinNullability.kt
			    |-- KotlinNullabilityMore.kt
			    |-- KotlinOperatorOverloading.kt
			    `-- KotlinOperatorOverloadingMore.kt

		|-- KotlinStudyMaterial6
		    |-- KotlinNotes
		        |-- KotlinNotes02-06.Shared.pdf
		        |-- KotlinNotes07.Shared.pdf
		        |-- KotlinNotes08.Shared.pdf
		        |-- KotlinNotes09.Shared.pdf
		        |-- KotlinNotes10.Shared.pdf
		        |-- KotlinNotes11.Shared.pdf
		        |-- KotlinNotes12.Shared.pdf
		        |-- KotlinNotes13.Shared.pdf
		        |-- KotlinNotes14.Shared.pdf
		        |-- KotlinNotes15.Shared.pdf
		        |-- KotlinNotes16.Shared.pdf
		        |-- KotlinNotes17.Shared.pdf

	A9.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
		
		Chapter 19 : java.util Part 1: The Collections Framework
		
		Chapter 06 : Introducing Classes
		Chapter 07 : Closer Look At Methods And Classes
		
		Chapter 08 : Inheritance
		Chapter 09 : Packages And Interfaces

____________________________________________________________

DAY 10
____________________________________________________________


	A10.1  STUDY ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidNotes
		|   |   |-- AndroidNotes4.1-2.pdf
		|   |   |-- AndroidNotes4.3.pdf


	A10.2  STUDY ANRROID PRESENTATIONS [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidPresentations
		|       |-- 01.0 Introduction to Android.pdf
		|       |-- 01.1 Your first Android app.pdf
		|       |-- 01.2 Layouts and resources for the UI.pdf
		|       |-- 01.3 Text and scrolling views.pdf


	A10.3  STUDY ANRROID REFERENCE MATERIAL [ MUST ]

		Android Study Links 
			https://developer.android.com/guide/platform


	A10.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
		
		Chapter 08 : Inheritance
		Chapter 09 : Packages And Interfaces
	
		Chapter 11: Exception Handling


____________________________________________________________

DAY 11
____________________________________________________________


	A10.1  STUDY ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidNotes
		|   |   |-- AndroidNotes4.1-2.pdf
		|   |   |-- AndroidNotes4.3.pdf


	A10.2  STUDY ANRROID PRESENTATIONS [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidPresentations
		|       |-- 01.0 Introduction to Android.pdf
		|       |-- 01.1 Your first Android app.pdf
		|       |-- 01.2 Layouts and resources for the UI.pdf
		|       |-- 01.3 Text and scrolling views.pdf


	A10.3  STUDY ANRROID REFERENCE MATERIAL [ MUST ]

		Android Study Links 
			https://developer.android.com/guide/platform


	A10.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
			
		Chapter 11: Exception Handling


	A10.5 REVISION ASSIGNMENT [ MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidNotes
		|   |   |-- AndroidNotes4.1-2.pdf
		|   |   |-- AndroidNotes4.3.pdf


		|-- AndroidStudyMaterial1.2
		|   |-- AndroidPresentations
		|       |-- 01.0 Introduction to Android.pdf
		|       |-- 01.1 Your first Android app.pdf
		|       |-- 01.2 Layouts and resources for the UI.pdf
		|       |-- 01.3 Text and scrolling views.pdf


____________________________________________________________

DAY 10
____________________________________________________________


	A10.1  STUDY ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidNotes
		|   |   |-- AndroidNotes4.1-2.pdf
		|   |   |-- AndroidNotes4.3.pdf


	A10.2  STUDY ANRROID PRESENTATIONS [ MUST MUST ]

		|-- AndroidStudyMaterial1.2
		|   |-- AndroidPresentations
		|       |-- 01.0 Introduction to Android.pdf
		|       |-- 01.1 Your first Android app.pdf
		|       |-- 01.2 Layouts and resources for the UI.pdf
		|       |-- 01.3 Text and scrolling views.pdf


	A10.3  STUDY ANRROID REFERENCE MATERIAL [ MUST ]

		Android Study Links 
			https://developer.android.com/guide/platform


	A10.4 Study Java And Experiment [ COMPLETE IT ]
		Java The Complete Reference, 11th Edition
		
		Chapter 08 : Inheritance
		Chapter 09 : Packages And Interfaces
	
		Chapter 11: Exception Handling


____________________________________________________________

DAY 11
____________________________________________________________


	A11.1  REVISE ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial2.1
		|   |-- AndroidNotes
		|   |   |-- AndroidNotes1-5.Shared.pdf

			Chapter 1: Setting Up Android Studio
			Chapter 2: Layouts
			Chapter 3: Activities
			Chapter 4: Debugging
			Chapter 5: Prettifying the App

		|-- AndroidStudyMaterial2.2
		|   `-- AndroidCodes
		|       `-- 01-TimeFighterApp
		|           |-- 01-getting-set-up-with-android-studio
		|           |-- 02-layouts
		|           |-- 03-activities
		|           |-- 04-debugging
		|           `-- 05-prettyifying-the-app


	A11.2  REVISE ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial2.3
		|   `-- AndroidDetailedNotes
		|       `-- AndroidDetailNotes1.pdf


	A11.3  STUDY ANRROID PRESENTATIONS [ MUST MUST ]

		|-- AndroidStudyMaterial2.4
		|   |-- AndroidPresentations
		|       |-- 01.0 Introduction to Android.pdf
		|       |-- 01.1 Your first Android app.pdf
		|       |-- 01.2 Layouts and resources for the UI.pdf
		|       |-- 01.3 Text and scrolling views.pdf
				|-- 01.4 Resources to help you learn.pdf
				|-- 02.1 Activities and Intents.pdf
				|-- 02.2 Activity lifecycle and state.pdf

	A11.4  STUDY ANRROID REFERENCE MATERIAL [ MUST ]

		Android Study Links 

			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative

			https://developer.android.com/training/constraint-layout
			https://developer.android.com/guide/components/activities/intro-activities

____________________________________________________________

DAY 12
____________________________________________________________


	A12.1  STUDY ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		|-- AndroidStudyMaterial3.3
		|   `-- AndroidNotes
		|       |-- AndroidDetailNotes1.pdf
		|       |-- AndroidDetailNotes2.pdf
		|       |-- AndroidDetailNotes3.pdf


	A12.2  STUDY ANRROID PRESENTATIONS [ MUST MUST ]

		|-- AndroidStudyMaterial2.4
		|   |-- AndroidPresentations
				|-- 01.4 Resources to help you learn.pdf
				|-- 02.1 Activities and Intents.pdf
				|-- 02.2 Activity lifecycle and state.pdf

	A12.3  STUDY ANRROID REFERENCE MATERIAL [ MUST ]

		Android Study Links 
			https://developer.android.com/training/constraint-layout
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle


	A12.4  REVISION REFERENCE MATERIAL [ MUST ]
		Android Study Links 
			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative

____________________________________________________________

DAY 13
____________________________________________________________


	A13.1  STUDY ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidNotes
			|   `-- Android.Notes2.Shared.pdf

		PRACTICE AND CODE ALL THE EXAMPLES FROM ABOVE NOTES



	A13.2  STUDY ANRROID REFERENCE MATERIAL [ MUST MUST ]

		Android Study Links 

			https://developer.android.com/guide/topics/ui/declaring-layout
			https://developer.android.com/guide/topics/ui/layout/linear
			https://developer.android.com/guide/topics/ui/layout/relative
			https://developer.android.com/training/constraint-layout

			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			https://developer.android.com/guide/components/intents-filters
			

	A13.3  STUDY AND REVISE ANDROID PRESENTATIONS MATERIAL [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidPresentations
				02.1 Activities and Intents.pdf
				02.2 Activity lifecycle and state.pdf
				02.3 Implicit Intents.pdf
				03.1 The Android Studio debugger.pdf
				03.2 App testing.pdf
				03.3 The Android Support Library.pdf
				04.1 Buttons and clickable images.pdf
				04.2 Input controls.pdf
				04.3 Menus and pickers.pdf
				04.4 User navigation.pdf
				04.5 RecyclerView.pdf
				05.1 Drawables, styles, and themes.pdf
				05.2 Material Design.pdf

	A13.4 : REVISE AND EXPERIMENT KOTLIN AND JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.0.zip


		Explore Following Code Example, Understand, Run and Reason It!!!

		EXPLORATION I
		
			AndroidStudyMaterial4.0
				|-- AndroidJavaCode
				|   |-- Project.03.01.ManifestAndResources
				|   |-- Project.03.04.Activities
				|   |-- Project.03.03.ConfigChanges

		EXPLORATION II
	
			AndroidStudyMaterial4.0
				|-- AndroidKotlinCode
				|   |-- ManifestAndResourses
				|   |-- Activities
				|   |-- ConfigChanges


	A13.5 : REVISE AND EXPERIMENT KOTLIN AND JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial5.0.zip


		Explore Following Code Example, Understand, Run and Reason It!!!

		EXPLORATION III
		Explore Following Code Example, Run It

		AndroidStudyMaterial5.0
			|-- AndroidJavaCode
			|   |-- Project.04.01.Layouts
			|   |-- Project.04.03.Views
			|   |-- Project.04.04.Adapters
		
		AndroidStudyMaterial5.0
			|-- AndroidKotlinCode
			|   |-- Layouts
			|   |-- Views
			|   |-- Adapters


____________________________________________________________

DAY 14
____________________________________________________________


	A14.1  REVISION ANDROID NOTES AND PRACTICE CODE IN NOTES [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidNotes
			|   `-- Android.Notes2.Shared.pdf

			
			REVISE CODE
					Chapter 6: Creating a New Project
					Chapter 7: RecyclerViews
					Chapter 8: SharedPreferences
					Chapter 9: Communicating Between Activities

		PRACTICE AND CODE ALL THE EXAMPLES FROM ABOVE NOTES


	A14.2  READING AND CODING ASSIGNMENT [ MUST MUST ]

		PRACTICE CODE EXAMPLES FROM THIS ARCTICLE

		https://guides.codepath.com/android/using-the-recyclerview#recyclerview-adapter


	A14.3  STUDY AND REVISE ANDROID PRESENTATIONS MATERIAL [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidPresentations
				04.4 User navigation.pdf
				04.5 RecyclerView.pdf
				05.1 Drawables, styles, and themes.pdf
				05.2 Material Design.pdf


	A14.4  REVISION ANRROID REFERENCE MATERIAL [ MUST MUST ]

		Android Study Links 
			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			https://developer.android.com/guide/components/intents-filters
			
		Android Study Links 
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094


____________________________________________________________

DAY 15
____________________________________________________________


	A15.1  REVISION ANRROID REFERENCE MATERIAL [ MUST MUST ]

		Android Study Links 
			https://developer.android.com/guide/components/fundamentals
			https://developer.android.com/guide/components/activities/intro-activities
			https://developer.android.com/guide/components/activities/activity-lifecycle
			https://developer.android.com/guide/components/activities/state-changes
			https://developer.android.com/guide/components/intents-filters
			https://developer.android.com/guide/components/intents-filters
			
		Android Study Links 
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094

			https://guides.codepath.com/android/using-the-recyclerview#recyclerview-adapter


	A15.2  STUDY AND REVISE ANDROID PRESENTATIONS MATERIAL [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial6.1.zip

		|-- AndroidStudyMaterial6.1
			|-- AndroidPresentations
			|	04.4 User navigation.pdf
			|	04.5 RecyclerView.pdf
			|	05.1 Drawables, styles, and themes.pdf
			|	05.2 Material Design.pdf
		    |-- 05.1 Drawables, styles, and themes.pdf
		    |-- 05.2 Material Design.pdf
		    |-- 05.3 Resources for adaptive layouts.pdf
		    |-- 06.1 UI testing.pdf
		    |-- 07.1 AsyncTask and AsyncTaskLoader.pdf
		    |-- 07.2 Internet connection.pdf
		    |-- 07.3 Broadcasts.pdf
		    `-- 07.4 Services.pdf


	A15.3 : REVISION FOLLOWING KOTLIN AND JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidNotes
			|   |-- Android.Notes2.Shared.pdf
					Chapter 06: Creating a New Project
					Chapter 07: RecyclerViews
					Chapter 08: SharedPreferences
					Chapter 09: Communicating Between Activities		
					Chapter 10: Completing the Detail View
		
		PRACTICE AND CODE ALL THE EXAMPLES FROM ABOVE NOTES


	A15.4 : EXPLORE FOLLOWING KOTLIN AND JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial6.1.zip

		Explore Following Code Example, Understand, Run and Reason It!!!
		Explore Following Code Example, Run It

		AndroidStudyMaterial6.1
			|-- AndroidJavaCode
			|   |-- Project.05.01.Intents
			|   |-- Project.05.03.BroadcastIntents
			
			|-- AndroidKotlinCode
			    |-- Intents
    			|-- BroadcastIntent
			


____________________________________________________________

DAY 16
____________________________________________________________


	A16.1  STUDY AND REVISE ANDROID PRESENTATIONS MATERIAL [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial6.1.zip

		|-- AndroidStudyMaterial6.1
			|-- AndroidPresentations
				|-- 04.5 RecyclerView.pdf
				|-- 05.1 Drawables, styles, and themes.pdf
				|-- 05.2 Material Design.pdf
				|-- 05.3 Resources for adaptive layouts.pdf
				|-- 07.1 AsyncTask and AsyncTaskLoader.pdf
				|-- 07.2 Internet connection.pdf
				|-- 07.3 Broadcasts.pdf
				|-- 07.4 Services.pdf
				|-- 08.1 Notifications.pdf
				|-- 08.2 Alarms.pdf
				|-- 08.3 Efficient data transfer and JobScheduler.pdf
				|-- 09.0 Data Storage.pdf
				|-- 09.1 Shared Preferences.pdf
				|-- 09.2 App settings.pdf
				|-- 10.0 SQLite Primer.pdf
				|-- 10.1_ Room, LiveData, and ViewModel.pdf

	A16.2  STUDY ANRROID REFERENCE MATERIAL [ MUST MUST ]

		Android Study Links 
		
			https://developer.android.com/guide/fragments
			https://developer.android.com/guide/fragments/create
			https://developer.android.com/guide/fragments/fragmentmanager
			https://developer.android.com/guide/fragments/transactions
			https://developer.android.com/guide/fragments/lifecycle

			https://developer.android.com/guide/components/broadcasts
			https://developer.android.com/guide/topics/providers/content-providers
			https://developer.android.com/guide/topics/providers/content-provider-basics


	A16.3 : UPDATE KOTLIN CODE IN LINE WITH CORRESPONDING JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial7.0.zip

		CODING ASSIGNMENT I		
			IMPLEMENT Select Gun Functionality In  KOTLIN CODE EXAMPLE
			IMPLEMENT Select Person From Contacts List Functionality In KOTLIN CODE EXAMPLE

			AndroidStudyMaterial7.0
				|-- AndroidJavaCode
					|-- Project.05.01.Intents
					|-- Project.05.03.BroadcastIntents

				|-- AndroidKotlinCode
				    |-- Intents
	    			|-- BroadcastIntent


		CODING ASSIGNMENT II
			IMPLEMENT FOLLOWING ANDROID JAVA CODE IN ANDROID KOLTIN 

			AndroidStudyMaterial7.0
				|-- AndroidJavaCode
					|-- AndroidIntroduction


____________________________________________________________

DAY 17
____________________________________________________________


	A17.1  STUDY ANRROID REFERENCE MATERIAL [ MUST MUST ]

		Android Study Links 
		
			https://developer.android.com/guide/fragments
			https://developer.android.com/guide/fragments/create
			https://developer.android.com/guide/fragments/fragmentmanager
			https://developer.android.com/guide/fragments/transactions
			https://developer.android.com/guide/fragments/lifecycle

			https://developer.android.com/guide/components/fundamentals

			https://developer.android.com/guide/components/broadcasts
			https://developer.android.com/guide/topics/providers/content-providers
			https://developer.android.com/guide/topics/providers/content-provider-basics

			https://developer.android.com/guide/components/services
			https://developer.android.com/guide/components/foreground-services
			https://developer.android.com/guide/components/bound-services


		REVISE Android Study Links 

			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-i-single-activities-e49fd3d202ab
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-ii-multiple-activities-a411fd139f24
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iii-fragments-afc87d4f37fd
			https://medium.com/androiddevelopers/the-android-lifecycle-cheat-sheet-part-iv-49946659b094


	A17.2 : UPDATE KOTLIN CODE IN LINE WITH CORRESPONDING JAVA CODE EXAMPLES [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial7.0.zip

		CODING ASSIGNMENT II
			IMPLEMENT FOLLOWING ANDROID JAVA CODE IN ANDROID KOLTIN 

			AndroidStudyMaterial7.0
				|-- AndroidJavaCode
					|-- AndroidIntroduction


	A17.3  REVISE ANDROID PRESENTATIONS MATERIAL [ MUST MUST ]

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial6.1.zip

		|-- AndroidStudyMaterial6.1
			|-- AndroidPresentations
				|-- 04.5 RecyclerView.pdf
				|-- 05.1 Drawables, styles, and themes.pdf
				|-- 05.2 Material Design.pdf
				|-- 05.3 Resources for adaptive layouts.pdf
				|-- 07.1 AsyncTask and AsyncTaskLoader.pdf
				|-- 07.2 Internet connection.pdf
				|-- 07.3 Broadcasts.pdf
				|-- 07.4 Services.pdf
				|-- 08.1 Notifications.pdf
				|-- 08.2 Alarms.pdf
				|-- 08.3 Efficient data transfer and JobScheduler.pdf
				|-- 09.0 Data Storage.pdf
				|-- 09.1 Shared Preferences.pdf
				|-- 09.2 App settings.pdf
				|-- 10.0 SQLite Primer.pdf
				|-- 10.1_ Room, LiveData, and ViewModel.pdf


	A17.4 : REVISION FOLLOWING KOTLIN AND JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial4.1.zip

		|-- AndroidStudyMaterial4.1
			|-- AndroidNotes
			|   |-- Android.Notes2.Shared.pdf
					Chapter 06: Creating a New Project
					Chapter 07: RecyclerViews
					Chapter 08: SharedPreferences
					Chapter 09: Communicating Between Activities		
					Chapter 10: Completing the Detail View
		
		PRACTICE AND CODE ALL THE EXAMPLES FROM ABOVE NOTES


	A17.5 : REVISE AND UPDATE KOTLIN CODE IN LINE WITH CORRESPONDING JAVA CODE EXAMPLES

		Download Link :  https://github.com/techhue/IBM.Android.December2021
		Download File :  AndroidStudyMaterial8.0.zip

			AndroidStudyMaterial8.0
				|-- AndroidJavaCode
				    |-- AndroidFragmentFundamentals
				    |-- AndroidFragmentPizza

____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________

