/*
1. Save File As KotlinBasics.kt In KotlinCode Directory

2. Compile Code With Following Command
		kotlinc KotlinBasics.kt -include-runtime -d basics.jar

3. Run Code With Following Command 
		java -jar basics.jar
*/

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

package learnKotlin

// Function
// 		Doesn't take any argument
//		and Returns Unit Value of Unit Type
//		By Default Return Type Is Unit
fun helloWorld()  {
	println("Hello World!!!")
}

// _______________________________________________
// MOMENT DONE FOLLOWING CODE, RAISE YOUR HANDS!!!

// Function
// 		Doesn't Take Two Int Type Arguments
//		and Returns Int Type Value

fun max( a: Int, b: Int ) : Int {
	return if (a > b) a else b
}

fun playWithMax() {
	var result = max(100, 200)
	println("Result : $result")

	result = max( -900, 300 )
	println("Result : $result")
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>>.RAISE HAND!

fun playWithVariableAndConstants() {
	// val Creates Constant Values i.e. Immutable Identifiers
	val number: Int = 100
	val pi: Double = 3.14159

	println(number)
	println(pi)

	// Uncomment and Compile Following 2 Lines 
	// number = 8888 		s// error: val cannot be reassigned
	// println(number)

	// var Creates Variable Values i.e. Mutable Values
	var variableNumber: Int = 100
	println(variableNumber)
	variableNumber = 999
	println(variableNumber)

	// _ Used To Improve Reading Will Be Removed By Compiler
	variableNumber = 1_000_000 
	println(variableNumber)
	
	var counter: Int = 1
	counter += 1
	counter += 1
	println(counter)
	
	counter = 10
	counter *= 3
	counter /= 2
	println(counter)	
}

// Function : playWithVariableAndConstants
// 100
// 3.14159
// 100
// 999
// 1000000
// 3
// 15

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypes() {
	// Annotating Variable With Type Explicitly
	var integerValue: Int = 100 	// It's Of Int Type 
	println(integerValue)

	var decimalValue: Double = 12.5 // It's Of Double Type
	println(decimalValue)

	// Converting Double Type Value to Int Type Value
	integerValue = decimalValue.toInt() // Truncation After Point 
	println(integerValue)

	// Annotating Variable With Type Explicitly
	val hourlyRate: Double = 20.20
	val hoursWorked: Int = 10
	val totalCost: Double = hourlyRate * hoursWorked 
	println(totalCost)

	// Type Is Implicitly Imferred From RHS Value And Binded With LHS

	// Expressions Is
	// LHS Identifier = RHS Value
	// 1. Compiler Will Inference Type From RHS Value
	// 2. Inferenced Type Will Be Binded With LHS Indentifier
	
	// Compiler Interred Type of 42 Value Is Int
	// Inferred Type Int Will Be Binded With something Identifier
	// Hence something Identifier Type Will Become Int 
	
	val something = 42 
	println(something)

	// Compiler Interred Type of 3.14159 Value Is Double
	// Inferred Type Double Will Be Binded With somethingAgain Identifier
	// Hence SomethingAgain Identifier Type Will Become Double 
	
	val somethingAgain = 3.14159
	println(somethingAgain)

	val someValue = 3 // 3 of Type Int, Hence someValue will Be Int Type	
	println(someValue)

	// Coverting Int Type Value To Double Value
	val doubleValue = someValue.toDouble()
	println(doubleValue)
}

// Function : playWithDataTypes
// 100
// 12.5
// 12
// 202.0
// 42
// 3.14159
// 3
// 3.0


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithCharAndStringDataTypes() {
	
	// Char and Kotlin.Char are same and both are Character Data Type
	val upperA: Char = 'A' // Inside Single Quotes is Kotlin Character
	val lowerA: kotlin.Char = 'a'

	println(upperA)
	println(lowerA)

	// Data Type of stringValue Indenfier will be String
	// Following 2 lines of code same
	// Explicit Type Annotation
	val stringValue0: String = "Hello World!!!" // Double "" String Value
	println(stringValue0)
	
	// What Is The Data Type Of Identifier stringValue1 ????

	// Implicitly Type Is Inferred and Inferred Type Is String
	// Inside Double Quotes "" String Value

	// error: type mismatch: inferred type is String but Int was expected
	// inferred type is String Means
	//		From RHS Value Type Inferred Is String
	//but Int was expected
	//		But On LHS Identifier Defined Of Int Type
	// error: type mismatch
		// Hence RHS Type Not Equal To LHS Type
	// val stringValue1: Int = "Hello World!!!" 

	/// Following Two Lines Of Code Are Doing Same Thing
	// val stringValue1: String = "Hello World!!!" 
	val stringValue1 = "Hello World!!!" 
	
	println(stringValue1)

	// What Is The Data Type Of Identifier messaage And name ???

	var message = "Hello, " + "My name is "
	val name = "Alice Carol"
	message += name // String Concatenation
	println(message)

	val exclamationMark: Char = '!'
	message += exclamationMark // Can also Concatinate Char With String
	println(message)

	// String Interpolation
	//		Sustituting Values Of Identifiers Inside String
	//		and Forming New String After Substition
	// Identifier name Value Is Substituted
	// To Access Value of Identifier Inside "" Double Quotes Use $
	val interpolatedString = "Hello, my name is $name!!!"
	println(interpolatedString)

	// Following Two Lines Are Same
	val oneThird: Double = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	
	// What Is The Type Of oneThirdAgain???
	// 		oneThirdAgain Binded To Double Type Inferred From RHS
	val oneThirdAgain = 1.0 / 3.0 // Here By Default Type Is Double, Not Float
	
	println(oneThird)
	println(oneThirdAgain)

	// Explicitly Annoating With Float Type
	//  error: type mismatch: inferred type is Double 
	//  	but Float was expected
	// 1.0 and 3.0 Type is Double and Double / Double is Double
	// RHS Value is Double and LHS Indentifier is Float
	// Hence Error...
	// val oneThirdOnceAgain: Float = 1.0 / 3.0 // Error

	val oneThirdOnceAgain: Float = (1.0 / 3.0).toFloat()
	println(oneThirdOnceAgain)

	// String Interpolation
	//		Substituting Identifier oneThird Value
	val oneThirdString = "One third is $oneThird is Double Type"	 
	println(oneThirdString)

	// String Interpolation
	//		Substituting Expression 1.0 / 3.0 Value After Evaluation
	val oneThirdStringAgain = "One third is ${ 1.0/ 3.0 } is Double Type"	 
	println(oneThirdStringAgain)

	// Multiple Lines String i.e. Paragraph
	//		Are Stored Inside Triple Quotes """ """
	val bigString = """
			|You can have a stringValue
			|that contains multiple
			|lines
			|using triple quotes
	"""

	println(bigString)

	// Remvoing White Space Characters From Before and After
	println(bigString.trimMargin())
}


// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithTupleDataTypes() {
	// Following Three Lines Of Code Are Same

	// Making Tuple Using Pair Type
	//		Tuple Is Ordered Data

	// Explicitly Annotating LHS with Type	
	val coordinates: Pair<Int, Int> = Pair(2, 3)
	
	// Implicitly Inferrred Type From RHS
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>
	val coordinatesInferred = Pair(2, 3)

	// Implicitly Inferrred Type From RHS
	// Shortcut Syntax Using Infix Notation
	// Type of LHS Is Inferred From RHS Value i.e. Pair<Int, Int>	
	val coordinatesWithTo = 2 to 3

	// What Is Type Of x1 and y1???
	// 		x1 And y1 Type Inferred From RHS 
	// 		i.e. From coordinates.first And coordinate.second
	// 		coordinates.first And coordinate.second Both Of Type Int
	val x1 = coordinates.first
	val y1 = coordinates.second
	println(x1)
	println(y1)

	val x2 = coordinatesWithTo.first
	val y2 = coordinatesWithTo.second
	println(x2)
	println(y2)

	// Unpacking or Decluttering 
	val (x3, y3) = coordinates
	println(x3)
	println(y3)
	// val (x3, y3) Line Of Code WIll Be Similar To Following
	// val x3 = coordinates.first
	// val y3 = coordinates.second

	println(coordinatesInferred.first)
	println(coordinatesInferred.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Double>
	val coordinatesDoubles = Pair(2.22, 3.30)
	println(coordinatesDoubles.first)
	println(coordinatesDoubles.second)

	// LHS Type WIll Be Inferrenced From RHS i.e. Pair<Double, Int>
	val coordinatesMixed = Pair(2.22, 33)
	println(coordinatesMixed.first)
	println(coordinatesMixed.second)

	// error: type mismatch: inferred type is Triple<Int, Int, Int> but Int was expected
	// val coordinates3D: Int = Triple(2, 3, 1)

	// LHS Type WIll Be Inferrenced From RHS i.e. Triple<Int, Int, Int>
	val coordinates3D = Triple(2, 3, 1)
	println(coordinates3D.first)
	println(coordinates3D.second)
	println(coordinates3D.third)

	// Unpacking or Decluttering 
	val (x4, y4, z4) = coordinates3D
	println(x4)
	println(y4)
	println(z4)

	val (x5, y5, _) = coordinates3D
	println(x5)
	println(y5)

	val (x6, _, y6) = coordinates3D
	println(x6)
	println(y6)
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithDataTypesAgain() {
	// Implicitly Inferred Type From RHS
	//		12 Have Default Type Int
	val aa  = 12 
	println(aa)

	val a: Short = 12
	val b: Byte = 120
	val c: Int = -100000

	val d = 999 // By Default Type Will Be Int
	println(d)

	// LHS Type Will Be Inferred From RHS Expression/Value
	// Typecast to Upper Type i.e. Short and Byte Will Become Int
	// 		a + b + c result will become Int
	//		Hence LHS answer Type Will Be Int
	val answer = a + b + c 
	println(answer)

	// Any Type Can Store Any Type Of Data
	//	Storing Int Type Data In Any Type
	val anyNumber: Any = 42
	println(anyNumber)

	//	Storing String Type Data In Any Type
	val anyString: Any = "Any String Value..."
	println(anyString)	
	
	//	Storing Double Type Data In Any Type	
	val anyDouble: Any = 46.90
	println(anyDouble)

	// error: type mismatch: inferred type is String but Int was expected
	// val something0: Int = "Any String Value..."
	// val something1: String = 42
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithKotlinExpressions() {	
    val yes = true
    println(yes)
    val no = false
    println(no)

    val doesOneEqualTwo = (1 == 2)
    println(doesOneEqualTwo)

    val doesOneNotEqualTwo = (1 != 2)
    println(doesOneNotEqualTwo)

    val alsoTrue = !(1 == 2)
    println(alsoTrue)

    val isOneGreaterThanTwo = (1 > 2)
    println(isOneGreaterThanTwo)

    val isOneLessThanTwo = (1 < 2)
    println(isOneLessThanTwo)

    val and = true && true
    println(and)

    val or = true || false
    println(or)

    val andTrue = 1 < 2 && 4 > 3
    println(andTrue)

    val andFalse = 1 < 2 && 3 > 4
    println(andFalse)

    val orTrue = 1 < 2 || 3 > 4
    println(orTrue)

    val orFalse = 1 == 2 || 3 == 4
    println(orFalse)

    val andOr = (1 < 2 && 3 > 4) || 1 < 4	
    println(andOr)

    val guess = "dog"
    println(guess)

    val dogEqualsCat = guess == "cat"
    println(dogEqualsCat)

    val order = "cat" < "dog"
    println("ORDER = " + order)
}

// _____________________________________________________
// Experiment Following Code, Moment Done >>> RAISE HAND!

fun playWithIfElseConstructs() {
	// if ( Expression ) 
	// Expression Can Be Any Logical Expression i.e. Resutling Into true/false
    if (2 > 1) {
        println("Yes, 2 is greater than 1.")
    }

    val animal = "Fox"
    if (animal == "Cat" || animal == "Dog") {
        println("Animal is a house pet.")
    } else {
        println("Animal is not a house pet.")
    }

    val a = 5
    val b = 10
    // Terneary Operator
    // if (Expression) Exp1 else Expr2
    // 		If Expression is true Then if-else Expression Value Will Be Expr1
    //		otherwise it will be Expr2
  
    // if-else Construct is Expression In Kotlin
    // Expression Have Always Return Value
    val min = if (a < b) a else b
    val max = if (a > b) a else b
    println(min)
    println(max)

    val hourOfDay = 12
    val timeOfDay = if (hourOfDay < 6) {
        "Early morning"
    } else if (hourOfDay < 12) {
        "Morning"
    } else if (hourOfDay < 17) {
        "Afternoon"
    } else if (hourOfDay < 20) {
        "Evening"
    } else if (hourOfDay < 24) {
        "Late evening"
    } else {
        "INVALID HOUR!"
    }
    println(timeOfDay)


    val name = "Dicken Lucas"

    if (1 > 2 && name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }

    if (1 < 2 || name == "Dicken Lucas") {
        println("Haaaa Haaaaa")
    } else {
        println("Hoooo Hooooo")    	
    }


    // Predict Output...
    var hoursWorked = 45
    var price = 0
    if (hoursWorked > 40) {
    	// hoursOver40 Scope Is if-else Block
        val hoursOver40 = hoursWorked - 40
        price += hoursOver40 * 50
        hoursWorked -= hoursOver40
    }
    price += hoursWorked * 25
    println(price)
    // println(hoursOver40) // error: unresolved reference: hoursOver40
}

// _____________________________________________________


fun playWithLoops() {
	// Predict The Output
    var sum = 1
    while (sum < 1000) {
        sum = sum + (sum + 1)
    }
    println(sum)

    sum = 1
    do {
        sum = sum + (sum + 1)
    } while (sum < 1000)
    println(sum)

    sum = 1
    while (true) {
        sum = sum + (sum + 1)
        if (sum >= 1000) {
            break
        }
    }
    println(sum)
}

// _____________________________________________________

fun playWithForLoop() {
	// .. is Range Operator
    val closedRange = 0..5 // Closed Interval [0, 5] i.e. Both 0 and 5 inclusive
	println(closedRange)

    val halfOpenRange = 0 until 5 // Half Open [0, 5) i.e. 0 inclusive and 5 excluded
	println(halfOpenRange)

    val decreasingRange = 5 downTo 0 // Closed Interval [5, 0]
    for (i in decreasingRange) {
        println(i)
    }

    val count = 10
    var sum = 0
    // i Values : 1, 2, 3, 4,...
    for (i in 1..count) { // Default step is 1
        sum += i
    }
    println(sum)

    sum = 1
    var lastSum = 0
    repeat(10) {
        val temp = sum
        sum += lastSum
        lastSum = temp
    }
    println(sum)

    sum = 0
    // i Values : 1, 3, 5....
    for (i in 1..count step 2) {
        sum += i
    }
    println(sum)

    sum = 0
    for (i in count downTo 1 step 2) {
        sum += i
    }
    println(sum)

	// Following For Loops Are Equivalent
    sum = 0
    for (row in 0 until 8) {
        if (row % 2 == 0) {
            continue
        }

        for (column in 0 until 8) {
            sum += row * column
        }
    }
    println(sum)

    sum = 0
    // Labels
    rowLoop@ for (row in 0 until 8) {
        columnLoop@ for (column in 0 until 8) {
            if (row == column) {
                continue@rowLoop
            }
            sum += row * column
        }
    }
    println(sum)
}

// _______________________________________________
// _______________________________________________
// _______________________________________________


fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithVariableAndConstants")
	playWithVariableAndConstants()
	
	println("\nFunction : playWithDataTypes")
	playWithDataTypes()
	
	println("\nFunction : playWithCharAndStringDataTypes")
	playWithCharAndStringDataTypes()

	println("\nFunction : playWithTupleDataTypes")
	playWithTupleDataTypes()

	println("\nFunction : playWithDataTypesAgain")
	playWithDataTypesAgain()

	println("\nFunction : playWithKotlinExpressions")
	playWithKotlinExpressions()

	println("\nFunction : playWithIfElseConstructs")
	playWithIfElseConstructs()

	println("\nFunction : playWithLoops")
	playWithLoops()

	println("\nFunction : playWithForLoop")
	playWithForLoop()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

