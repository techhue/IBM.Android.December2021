
DAY 01
____________________________________________________________

	A1.1 Kotlin Code [ MUST ]
		 Practice and Revise Kotlin Code Done Till Nwo

		|-- KotlinStudyMaterial0
		    |-- KotlinCode
		    |   |-- Hello.kt
		    |   |-- KotlinBasics.kt
		    |   `-- KotlinBasicsExperiment.kt

	A1.2 Kotlin Study Notes [ MUST ]

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

	A1.3 Type And Experiment Code Examples [ MUST ] 
		From Following KotlinNotes 

		|-- KotlinStudyMaterial0
	    	|-- KotlinNotes
	        	|-- KotlinNotes2-6.Shared.pdf

DAY 02
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
