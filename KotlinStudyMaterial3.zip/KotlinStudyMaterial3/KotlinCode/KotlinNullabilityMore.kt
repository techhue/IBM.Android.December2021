/*
kotlinc KotlinNullabilityMore.kt -include-runtime -d nullability.jar
java -jar nullability.jar
*/

package learnKotlin


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


fun playWithCollectionNullability() {
    // Nullability and Collection Types

    var nullableList: List<Int>? = listOf(1, 2, 3, 4)
    nullableList = null

    var listOfNullables: List<Int?> = listOf(1, 2, null, 4)
    // listOfNullables = null // Error: Null can not be a value of a non-null type

    var nullableListOfNullables: List<Int?>? = listOf(1, 2, null, 4)
    nullableListOfNullables = null
}


// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Employee(val name: String, val manager: Employee?)

fun getManagerName(employee: Employee) : String? {
	//  error: only safe (?.) or non-null asserted (!!.) 
	//  calls are allowed on a nullable receiver of type Employee?
	
 	// error: type mismatch: inferred type is String? but String was expected
	
	// If Any Part In Expression Become null Then Whole Expression Becomes null
	return employee.manager?.name 
}

fun plaWithEmployeeManager() {
	val ceo 		= Employee("Da Boss", null)
	val ashwaraya 	= Employee("Ashwaraya", ceo)

	println( getManagerName(ashwaraya) )
	println( getManagerName(ceo) )
}

// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Address(
	val streetName: String,
	val zipCode: Int,
	val city: String,
	val country: String
)

class Company( val name: String, val address: Address? )

class Person( val name: String, val company: Company? )

fun getCountryNameOfPersonCompany(person: Person) : String  {
	val country: String? = person.company?.address?.country

	return if (country != null) country else "Unknown"
}

fun playWithPersonCountry() {
	val alice = Person("Alice", null)
	println( getCountryNameOfPersonCompany(alice) )

	val bobCompany = Company("IBM", null)
	val bob = Person("Bob", bobCompany)
	println( getCountryNameOfPersonCompany(bob) )

	val intelAddress = Address("Outer Ring Road", 560103, "Bangalore", "India")
	val rameshCompany = Company("Intel", intelAddress)
	val rammesh = Person("Bob", rameshCompany)
	println( getCountryNameOfPersonCompany(rammesh) )
}

// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

fun main() {

	println("Function : playWithCollectionNullability")
	playWithCollectionNullability()
	
	println("Function : plaWithEmployeeManager")
	plaWithEmployeeManager()

	println("Function : playWithPersonCountry")
	playWithPersonCountry()
	

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
