
/*
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

package learnKotlin

import java.util.Comparator
import java.io.File

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// Compiler Will Generate Following Things
// 1. Generate Memberwise Constructor Person(firstName, lastName)
// 2. Generate 3 Member Variables To Store Data
//		Corresponding To firstName, lastName, fullName Properties
// 3. Generate Getters and Setters
//		firstName and lastName Properties Both Getters and Setters Will Generated
//	    fullName Property Only Getter is Define

class Person(var firstName: String, var lastName: String) {
	var fullName: String = ""
		get() {  			// Custom Getter Function
			println("fullName Getter Called...")
			return "$firstName $lastName"
		}
		set(value) {  		// Custom Setter Function
			println("fullName Setter Called...")
			field = value
		}
}	

fun playWithPerson() {
	val alice = Person(firstName = "Alice", lastName = "Carols")
	println( alice.firstName )  	// alice.getFirstName()
	println( alice.lastName )   	// alice.getLastName()
	println( alice.fullName )		// alice.getFullName()

	alice.firstName = "Alisa"		// alice.setFirstName("Alisa")
	alice.lastName = "Carolina"		// alice.setLastName("Carolina")
	alice.fullName = "Alisa Carolina" // error: val cannot be reassigned

	println( alice.firstName )
	println( alice.lastName )
	println( alice.fullName )
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class SimplePerson(var name: String)

fun playWithObjectEquality() {
	val simplePerson = SimplePerson(name = "John")
	//println(simplePerson.name)

	// Reference/Address/Pointer Assignment
	val simplePersonDuplicate = simplePerson

	//println(simplePersonDuplicate.name)
	simplePersonDuplicate.name = "John Mcmillan"
	
	println(simplePerson.name)
	println(simplePersonDuplicate.name)

	// Function : playWithObjectEquality
	// John Mcmillan
	// John Mcmillan

	val simplePerson1 = SimplePerson(name = "John")

	val simplePerson2 = SimplePerson(name = "Johnny")

	// Reference/Address/Pointer Comparision
	// By Default Comparing References Not Actual Objects
	println( simplePerson == simplePersonDuplicate ) // true
	println( simplePerson == simplePerson1 ) 		 //	false
	println( simplePerson == simplePerson2 ) 		 //	false

	// Following Will Be Comparing References Not Actual Objects
	println( simplePerson === simplePersonDuplicate ) 
	println( simplePerson === simplePerson1 ) 		 
	println( simplePerson === simplePerson2 ) 		 
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Grade(val letter: String, val points: Double, val credits: Double)

class Student(
	val firstName: String, 
	val lastName: String, 
	// Assigning Default Value As Empty Mutable List
	val grades: MutableList<Grade> = mutableListOf(), 
	var credits: Double = 0.0 // Assigning Default Value 
) {
	val gpa: Double
		get() { // Custom Getter
			var totalPoints = 0.0
			for (grade in grades) {
				totalPoints = totalPoints + grade.points
			}
			return totalPoints / credits
		}
	
	fun recordGrade(grade: Grade) {
		grades.add(grade)
		credits = credits + grade.credits
	}
}

fun playWithStudentGrades() {
	val alice 	= Student(firstName = "Alice", lastName = "Carol")
	val history = Grade(letter = "B", points = 8.0, credits = 3.0 )
	val maths 	= Grade(letter = "C", points = 7.0, credits = 4.0 )
	val english = Grade(letter = "A", points = 9.0, credits = 4.0 )

	alice.recordGrade(history)
	alice.recordGrade(maths)
	alice.recordGrade(english)

	println(alice.gpa)
	println(alice.firstName)
	println(alice.lastName)
	println(alice.grades)
	println(alice.credits)

	// alice.firstName = "Alisa"
	// alice.lastName = "Chaanaaa"
//	alice.grades = mutableListOf(history, maths)
	alice.credits = 10.10

	println(alice.firstName)
	println(alice.lastName)
	println(alice.grades)
	println(alice.credits)


	println(alice.gpa)
	val science = Grade(letter = "A", points = 20.0, credits = 5.0 )
	alice.recordGrade(science)
	println(alice.gpa)

}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

class Student1(var firstName: String, var lastName: String, var id: Int) {	
	// By Default equals compares Only References
	// Don't Want To Compare Object References
	// Want To Compare Objects With There Members
	//		Override equals Method and Write Your Equality Logic
	override fun equals(other: Any?): Boolean {
		println("Method Called... : equals")
		if (other == null || other !is Student1 ) return false
		// return (firstName == other.firstName && lastName == other.lastName)
		return (firstName == other.firstName && lastName == other.lastName && id == other.id)
	}
	// Override hashCode Function Also Along With equals Method
	override fun hashCode() : Int {
		val startingPrimeNumber = 31
		var result: Int = 1

		result = startingPrimeNumber * result + firstName.hashCode()
		result = startingPrimeNumber * result + id
		result = startingPrimeNumber * result + lastName.hashCode()
		
		return result
	}
	// Another Simpler Implemenation of hashCode
	// override fun hashCode() : Int {
	// 	var result: Int = 0

	// 	result = firstName.hashCode()
	// 	result = result + id
	// 	result = result + lastName.hashCode()
		
	// 	return (result % 10000)
	// }

	override fun toString() : String {
		println("Student 1 Method Called... : toString")
		return "Student1(firstName=$firstName, lastName=$lastName, id=$id)"
	}

	// Member Of Student1 Class
	fun copy(firstName: String = this.firstName, 
		lastName: String = this.lastName, 
		id: Int = this.id) : Student1 {
		return Student1(firstName, lastName, id)
	}
}

fun playWithStudent1Copying() {
	val alice1 = Student1(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = alice1

	val alice3 = alice1.copy()

	val someone = alice1.copy( lastName = "Someone", id = 200)
	val someoneElse = alice1.copy( lastName = "SomeoneElse", id = 300)
	val someoneElseAgain = alice1.copy( firstName = "Alisha", lastName = "SomeoneElseAgain", id = 400)

	alice2.firstName = "Alonza"
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(alice3)
	println(someone)
	println(someoneElse)
	println(someoneElseAgain)

	// Compiler Will Geneate alice1.equals( alice2 ) For Expression alice1 == alice2
	println( alice1 == alice2 )  
	println( alice1 === alice2 ) // Equality of References 
	
	println( alice1 == alice3 ) 
	println( alice1 === alice3 ) // Equality of References

	println( alice1 == someone )
	println( alice1 === someone ) // Equality of References
	
	println( alice1 == someoneElse ) // alice1.equals( someoneElse )
	println( alice1 === someoneElse ) // Equality of References
}

// from SABYASACHI DAS (IBM) to Everyone:
// 	alice 1 and alice 2 are true since both of them contains the same address(reference) of the student1 object, alice3 is a copy of alice1 but that doesnt mean alice 3 has the same reference to the student1 object that alice1 and alice2 has... this is the reason why alice3.firstname didn't change to "alonzo" when we changed it in line 206... and on comparing alice3 with alice1 the result is false similarly we are creating someone someoneElse and someoneElseAgain by copy method but we are also chaging the class properties explicitly... so the comparison result is false

fun playWithStudent1Equality() {
	val alice1 = Student1(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = Student1(firstName = "Alice", lastName = "Carols", id = 100)

	val johnny = Student1(firstName = "Jonny", lastName = "Jaamil", id = 999)

	// println(alice1.firstName)
	// println(alice1.lastName)
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(johnny) // Compiler Will Convert To println( johnny.toString() )

	// Compiler Will Geneate alice1.equals( alice2 ) For Expression alice1 == alice2
	println( alice1 == alice2 ) 
	// Compiler Will Geneate alice1.equals( johnny ) For Expression alice1 == johnny
	println( alice1 == johnny )
	// Compiler Will Geneate alice2.equals( johnny ) For Expression alice2 == johnny
	println( alice2 == johnny )
}

// _____________________________________________________

// Data Classes
// Compiler Will Generate Following Methods
//		1. Will Generate toString Method With All The Properties In Contructor
//		2. Will Generate equals Method, Comparing All The Properties In Constructor
//		3. Will Generate hashCode Method Also
//		4. Will Generate copy Method To Coyy All The Properties In Constructor

data class Student2(var firstName: String, var lastName: String, var id: Int) {
	// var fullName: String
	// 		get() {
	// 			return "$lastName, $firstName"
	// 		}

	// Following Is Getter Body After Assignment Statement
	// And It's Equivalent To Above Code
	val fullName = "$lastName, $firstName"

	// Overriding toString Method, Hence will be Not Be Generated
	override fun toString() : String {
		println("Student 2 Method Called... : toString")
		return "Student1(firstName=$firstName, lastName=$lastName, id=$id)"
	}
}

fun playWithStudent2Equality() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = Student2(firstName = "Alice", lastName = "Carols", id = 100)

	val johnny = Student2(firstName = "Jonny", lastName = "Jaamil", id = 999)

	println(alice1.fullName)
	println(alice1.toString() ) 
	println(alice2.fullName)
	println(alice2.toString() ) 
	println(johnny.fullName)
	println(johnny.toString()) 

	println( alice1 === alice2 ) 
	println( alice1 == alice2 ) 
	println( alice1 == johnny )
	println( alice2 == johnny )	

}

fun playWithStudent2Copying() {
	val alice1 = Student2(firstName = "Alice", lastName = "Carols", id = 100)
	val alice2 = alice1

	val alice3 = alice1.copy()

	val someone = alice1.copy( lastName = "Someone", id = 200)
	val someoneElse = alice1.copy( lastName = "SomeoneElse", id = 300)
	val someoneElseAgain = alice1.copy( firstName = "Alisha", lastName = "SomeoneElseAgain", id = 400)

	alice2.firstName = "Alonza"
	println(alice1) // Compiler Will Convert To println( alice1.toString() )
	println(alice2) // Compiler Will Convert To println( alice2.toString() )
	println(alice3)
	println(someone)
	println(someoneElse)
	println(someoneElseAgain)

	println( alice1 == alice2 )  
	println( alice1 === alice2 ) // Equality of References 
	println( alice1 == alice3 ) 
	println( alice1 === alice3 ) // Equality of References
	println( alice1 == someone )
	println( alice1 === someone ) // Equality of References
	println( alice1 == someoneElse ) // alice1.equals( someoneElse )
	println( alice1 === someoneElse ) // Equality of References
}

// Student2(firstName=Alice, lastName=Carols, id=100)

// Function : playWithStudent2
// Carols, Alice
// learnKotlin.Student2@65b54208
// Carols, Alice
// learnKotlin.Student2@1be6f5c3
// Jaamil, Jonny
// learnKotlin.Student2@6b884d57
// false
// false
// false

// _____________________________________________________


// Singleton Design Pattern

// Singleton Classes Can Have At The Most One Instance
// class Singleton {
// 	// static variable single_instance of type Singleton
// 	private static Singleton single_instance = null;

// 	// variable of type String
// 	public String s;

// 	// private constructor restricted to this class itself
// 	private Singleton() {
// 		s = "Hello I am a string part of Singleton class";
// 	}

// 	// static method to create instance of Singleton class
// 	public static Singleton getInstance() {
// 		if (single_instance == null)
// 			single_instance = new Singleton();

// 		return single_instance;
// 	}
// }

// Object Classes
// Singleton Design Pattern
// Singleton Classes Can Have At The Most One Instance
// object Classes Are Singleton Classes
// 		Will Define Singleton Named Class
//		Create One Unique Instance of It.
//		You Can Access Unique Instance With Class Name.


object Singleton {
	// variable of type String
	var s: String = "Unknown Value"
}

object X {
	var x = 0
}

fun playWithSingleton() {
	val value: String = Singleton.s 

	println("Value Stored In Singleton Member s : $value")
	println(X.x)

	Singleton.s = "Ding Dong"
	X.x = 9000

	println("Value Stored In Singleton Member s : $value")
	println(X.x)	
}


// Need Only One Instance
// class India {
// 	// variable of type String
// 	public String s;

// 	India() {
// 		s = "India";
// 	}
// }

// // Everyone Has There Own India
// // With There Own Data
// India india = new India();
// India bharat = new Bharat();
// India myIndia = new India();
// India yourIndia = new India();
// Inida tamiliansIndia = nwe India();
// tamiliansIndia.s = "TamlianIndia"
// India gujratisIndia = new India();


// Singleton Design Patterns
// Singleton Class
// class India {
// 	// static variable single_instance of type Singleton
// 	private static Singleton unique_instance = null;

// 	// variable of type String
// 	public String s;

// 	// private constructor restricted to this class itself
// 	private India() {
// 		s = "India";
// 	}

// 	// static method to create instance of Singleton class
// 	public static India getInstance() {
// 		if (unique_instance == null)
// 			unique_instance = new India();

// 		return unique_instance;
// 	}

// 	public Array<String> getStates() {

// 	}
// }
// Following is NOT POSSIBLE
// India india = new India();
// India bharat = new Bharat();
// India myIndia = new India();
// India yourIndia = new India();
// Inida tamiliansIndia = nwe India();
// tamiliansIndia.s = "TamlianIndia"
// India gujratisIndia = new India();
// India india = India.getInstance();
// India bharat = India.getInstance();
// India myIndia = India.getInstance();
// India yourIndia = India.getInstance();
// Inida tamiliansIndia = India.getInstance();
// tamiliansIndia.s = "TamlianIndia"
// India gujratisIndia = India.getInstance();


// _____________________________________________________
// Implement India Singleton Class In Kotlin

// Singleton Class With Unique Object and Object Is Accessed Using Class Name
object India {
	var name : String = "India"

	fun getStates() : List<String> {
		return listOf("Karnatka", "Jammu & Kashmir", "Punjab", "Gujrat", "Tamilnadu",
			"Bihar", "Uttar Pradesh", "Maharastra", "Kerala")		
	}

	fun decoratedName() : String {
		return "Country Name : $name"
	}
}

fun playWithIndia() {
	println(India.name)
	
	India.name = "Bharat"
	println(India.name)

	India.name = "Hindustan!"
	println(India.name)

	println(India.getStates())
	println(India.decoratedName())	
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

data class Student3(val id: Int, val firstName: String, val lastName: String) {
	val fullName = "$lastName, $firstName"
}

// Singleton Class
object StudentRegistry {
	val allStudents = mutableListOf<Student3>()

	fun addStudent(student: Student3) {
		allStudents.add(student)
	}

	fun removeStudent(student: Student3) {
		allStudents.remove(student)
	}

	fun listAllStudents() {
		allStudents.forEach( { println(it.fullName) } )
	}
}

fun playWithStudentRegistry() {
	val marie = Student3(100, "Marie", "Curie")
	val albert = Student3(101, "Albert", "Einsein")
	val alice = Student3(102, "Alice", "Carol")

	StudentRegistry.addStudent(marie)
	StudentRegistry.addStudent(albert)
	StudentRegistry.addStudent(alice)

	StudentRegistry.listAllStudents()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// Class/Type Members In Java
// class TypeMember {
// 	public static void doMagic() {
// 		System.out.println("Class/Type Member Called... Doing Magic");
// 	}
// }

// public class TypeMemberDemo {
// 	public static void playWithCompanionObjects() {
// 		TypeMember.doMagic();
// 	}

// 	public static void main(String[] args) {
// 		playWithCompanionObjects();
// 	}
// }

// Class/Type Members In Kotlin

// Companions Objects
//		Companions Objects Members Can Be Accessed Using Enclosing Class/Type

class TypeMember1 {
	// Companion Object Class Name Optional
	//		Companion Will Be Default Class For Companion Object
	companion object {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

class TypeMember2 {
	// Companion Object Class Name Mentioned
	companion object Magician {
		fun doMagic() {
			println("Companion Object Member Called... Doing Magic")
		}
	}
} 

fun playWithCompanionObjects() {
	TypeMember1.doMagic()
	TypeMember1.Companion.doMagic()

	TypeMember1.doMagic()
	TypeMember1.Companion.doMagic()
	TypeMember2.Magician.doMagic()
}


// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!


// import java.util.Comparator
// import java.io.File

object CaseInsensitiveFileComparator : Comparator<File> {
    override fun compare(file1: File, file2: File): Int {
        return file1.path.compareTo(file2.path,
                ignoreCase = true)
    }
}

fun objectClassesDeclarations() {
    println(CaseInsensitiveFileComparator.compare(
        File("/User"), File("/user")))
    val files = listOf(File("/home/Sagar/Documents"), 
    	File("/home/Sagar/Music"), 
    	File("/home/Ashwarya/Downloads"), 
    	File("/home/Ashwarya/Documents"), 
    	File("/home/Sagar/Downloads"))
    println(files.sortedWith(CaseInsensitiveFileComparator))
}

// ______________________________________________________
// Experiment Folloiwng Code, Moment Done >>> RAISE HAND!

// import java.util.Comparator

data class Person1(val name: String) {
    object NameComparator : Comparator<Person1> {
        override fun compare(p1: Person1, p2: Person1): Int =
            p1.name.compareTo(p2.name)
    }
}

fun objectClassesDeclarations1() {
    val persons = listOf(Person1("Bob"), Person1("Alice"))
    println(persons.sortedWith(Person1.NameComparator))
}


// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________
// _____________________________________________________


fun main( ) {
	println("Function : playWithPerson")
	playWithPerson()

	println("Function : playWithObjectEquality")
	playWithObjectEquality()

	println("Function : playWithStudentGrades")
	playWithStudentGrades()

	println("Function : playWithStudent1Equality")
	playWithStudent1Equality()

	println("Function : playWithStudent1Copying")
	playWithStudent1Copying()

	println("Function : playWithStudent2Equality")
	playWithStudent2Equality()

	println("Function : playWithStudent2Copying")
	playWithStudent2Copying()

	println("Function : playWithSingleton")
	playWithSingleton()

	println("Function : playWIthIndia")
	playWithIndia()

	println("Function : playWithStudentRegistry")
	playWithStudentRegistry()

	println("Function : playWithCompanionObjects")
	playWithCompanionObjects()

	println("Function : objectClassesDeclarations")
	objectClassesDeclarations()

	println("Function : objectClassesDeclarations1")
	objectClassesDeclarations1()
	
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}
