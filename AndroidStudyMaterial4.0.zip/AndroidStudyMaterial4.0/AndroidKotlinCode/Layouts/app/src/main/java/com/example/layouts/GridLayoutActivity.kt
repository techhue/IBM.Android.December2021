package com.example.layouts

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class GridLayoutActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.grid_layout)
    }
}