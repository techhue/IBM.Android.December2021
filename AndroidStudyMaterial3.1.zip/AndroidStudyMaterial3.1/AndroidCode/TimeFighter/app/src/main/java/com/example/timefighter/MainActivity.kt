package com.example.timefighter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

// Activity Definition
//      MainActivity
class MainActivity : AppCompatActivity() {

    private lateinit var gameScoreTextView: TextView
    private lateinit var timeLeftTextView: TextView
    private lateinit var tapMeButton: Button

    private  lateinit var countDownTimer: CountDownTimer
    private var gameStarted = false


    private val initialCountDownValue: Long = 30000
    private val countDownInterval: Long = 1000
    private val initialTimeLeft = initialCountDownValue / 1000

    private var secondsLeft: Long = initialTimeLeft

    private var score: Int = 0

    // onCreate Will Be First First Function To Get Called
    //      After Activity Launches
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Creating Screen Full UI
        // To Create Screen Full UI
        //      Call setContentView Method and Pass Layout File As Argument
        //      e.g.  For UI Layout File res/layout/activity_main.xml
        //              pass R.layout.activity_main Argument
        //      setContentView() Function Will Construct View Hierarchy i.e. View Tree
        setContentView(R.layout.activity_main)

        // Search Views In View Tree Using View ID
        //     It Will Return View Type Object
        gameScoreTextView = findViewById(R.id.game_score_text_view)
        timeLeftTextView = findViewById(R.id.time_left_text_view)
        tapMeButton = findViewById(R.id.tap_me_button)

        resetGame()
        tapMeButton.setOnClickListener {
            Log.d("MainActivity","Tap Me Button Clicked!!!")
            incrementScore()
        }
    }

    private fun incrementScore() {
        Log.d("MainActivity","Function Called: incrementScore")
        if ( !gameStarted ) startGame()

        score++
        val gameScoreString = getString(R.string.game_score_string, score)
        gameScoreTextView.text = gameScoreString
        Log.d("MainActivity","Game Score : $gameScoreString")
    }

    private fun startGame() {
        Log.d("MainActivity","Function Called: startGame")
        countDownTimer.start()
        gameStarted = true
    }

    private fun resetGame() {
        gameStarted = false
        score = 0
        val initialScore = getString(R.string.game_score_string, score )
        gameScoreTextView.text = initialScore

        val initialTimeLeftString = getString(R.string.time_left_string, initialTimeLeft)
        timeLeftTextView.text = initialTimeLeftString

        countDownTimer = object : CountDownTimer(initialCountDownValue, countDownInterval) {
            override fun onTick(millisUntilFinished: Long) {
                // millisUntilFinished Will Return Result In Milli Seconds
                //      Divide By 1000 To Convert To Seconds
                secondsLeft = millisUntilFinished / 1000

                val secondLeftString = getString(R.string.time_left_string, secondsLeft)
                timeLeftTextView.text = secondLeftString
            }

            override fun onFinish() {
                if ( gameStarted ) {
                    endGame()
                    resetGame()
                }
            }
        }.start()
    }

    private fun endGame() {
        Log.d("MainActivity","Function Called: endGame")
        gameStarted = false
        val gameOverMessage = getString(R.string.game_over_string, score)
        val gameOverToast = Toast.makeText(this, gameOverMessage, Toast.LENGTH_LONG)
        gameOverToast.show()
    }
}
